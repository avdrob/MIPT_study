
                    README zur Version 4.0 von PRINTER.BGI
                    --------------------------------------

Falls Sie PKZIP zum auspacken verwenden, sollten Sie auf der Kommandozeile "-d"
angeben, damit die orginale Verzeichnis-Struktur wieder hergestellt wird. Also
z.B.:

        pkunzip -d prn400a


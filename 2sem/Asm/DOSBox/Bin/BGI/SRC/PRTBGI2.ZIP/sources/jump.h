/*****************************************************************************/
/*                                                                           */
/*                                   JUMP.H                                  */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: jump.h 1.1 1995/04/28 16:19:22 Uz Exp $
//
// $Log: jump.h $
// Revision 1.1  1995/04/28 16:19:22  Uz
// Initial revision
//
//
//



#ifndef _JUMP_H
#define _JUMP_H



/*****************************************************************************/
/*                                  Typen                                    */
/*****************************************************************************/



// Typ eines Sprunglabels
typedef unsigned JumpBuf [5];



/*****************************************************************************/
/*                                   Code                                    */
/*****************************************************************************/



int pascal SetJump (JumpBuf _ds &Buf);
// Setzt ein Sprunglabel.

void pascal LongJump (JumpBuf _ds &Buf, int RetVal);
// Springt ein zuvor gesichertes Sprunglabel an und liefert RetVal zur�ck



// Ende von JUMP.H

#endif

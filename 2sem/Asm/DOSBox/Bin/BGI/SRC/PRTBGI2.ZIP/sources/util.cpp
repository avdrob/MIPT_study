/****************************************************************************/
/*                                                                          */
/*             Allgemeine Hilfs-Prozeduren f�r BGI-Druckertreiber           */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: util.cpp 2.8 1995/04/28 16:21:24 Uz Exp $
//
// $Log: util.cpp $
// Revision 2.8  1995/04/28 16:21:24  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.7  95/04/22  17:33:51  Uz
// Kosmetik.
//
// Revision 2.6  95/02/20  13:42:09  Uz
// Fehler aus QSort behoben: Pointer-Arithmetik war fehlerhaft
//
// Revision 2.5  94/03/28  16:28:47  Uz
// Neue Funktion Round.
//
// Revision 2.4  94/03/19  16:17:38  Uz
// Wegfall von #pragma rvl
//
// Revision 2.3  93/08/01  20:53:16  Uz
// Neues Format mit DPMI-Support
//
//
//



#include "const.h"





DWORD pascal LongMul (WORD A, WORD B)
/* Multipliziert zwei WORD-Werte. Das Ergebnis hat 32-Bit */
{
    asm    mov     ax, WORD PTR [A]
    asm    mul     WORD PTR [B]
    return MK_DWORD (_DX, _AX);
}





WORD pascal LongDiv (DWORD A, WORD B)
/* Dividiert A durch B und liefert das Ergebnis zur�ck */
{
    asm    mov     ax, WORD PTR [A]
    asm    mov     dx, WORD PTR [A+2]
    asm    div     WORD PTR [B]
    return _AX;
}




DWORD pascal Round (DWORD A, WORD B)
// Rundet A auf vielfache von B auf
{
    asm mov     ax, WORD PTR [A]
    asm mov     dx, WORD PTR [A+2]
    asm mov     bx, [B]
    asm dec     bx
    asm add     ax, bx
    asm adc     dx, 0
    asm inc     bx
    asm div     bx
    asm mul     bx
    return MK_DWORD (_DX, _AX);
}



/****************************************************************************/
/* Wandeln eines WORD-Wertes nach ASCII und ablegen in einem String. Es     */
/* wird am Schlu� ein 0-Byte angef�gt. Die �bergebene Zahl wird als vor-    */
/* zeichenloser 16-Bit Wert behandelt, die L�nge des Strings betr�gt        */
/* maximal 6 Zeichen (5 + 0-Byte).                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   W          Die Zahl wie oben beschrieben                               */
/*   S          Der Puffer in dem der ASCII-String abgelegt wird.           */
/*                                                                          */
/* Ergebnis:                                                                */
/*   S                                                                      */
/*                                                                          */
/****************************************************************************/


char far * pascal Num (WORD W, char far *S)
{
    asm    mov     ax, WORD PTR [W]
    asm    mov     bx, 10                       // Divisor
    asm    xor     cx, cx
    asm    push    cx                           // Sentinel

// Zahl fortgesetzt teilen und die jew. Reste auf den Stack

L1: asm    xor     dx, dx                       // High-Word = 0
    asm    div     bx
    asm    add     dl, '0'                      // Rest nach ASCII wandeln
    asm    push    dx                           // Und verstauen
    asm    or      ax, ax                       // Noch was da ?
    asm    jnz     L1                           // Ja: Weiter

// Zeiger holen und den String abspeichern

    asm    les     di, [S]                      // Ziel in es:di
    asm    cld
L2: asm    pop     ax                           // Wert vom Stack
    asm    stosb                                // Und speichern
    asm    or      ax, ax                       // War es die 0 ?
    asm    jnz     L2                           // Nein: Weiter

// Ende, S r�ckliefern

    return S;
}



/***************************************************************************/
/* Eigener Quicksort, da der Standard-Sort aufgrund der �bergebenen NEAR-  */
/* Zeiger leider nicht funktioniert.                                       */
/***************************************************************************/



static void pascal QSort (int far *Left, int far *Right)
// Funktion die die eigentliche Arbeit macht.
//
// ACHTUNG: An zwei Stelle dieser Funktion wird die normale C Pointer-Arithmetik
// umgangen da der Compiler (seltsamerweise) einen extrem aufwendigen Code
// daf�r produziert. Alle Berechnungen erfolgen als _long_ inclusive Aufruf
// der 32-Bit Division f�r die Division durch sizeof (int).
//
{
    int far *I, far *J, far *X;

Again:
    I = Left; J = Right;
    // Der vom Compiler hier erzeugte Code ist aufwendig und ben�tigt
    // (unn�tigerweise) eine 32-Bit Division.
    // Alter Code:
    // X = Left + ( ((unsigned int) (Right-Left)) / 2);
    //
    // Aus diesem Grund erfolgt der Umweg �ber direkte Pointer-Arithmetik
    asm mov     ax, WORD PTR [Right]
    asm sub     ax, WORD PTR [Left]
    asm shr     ax, 1                   // / 2
    asm and     ax, 0FFFEh              // Zeigt auf einen INT
    asm add     ax, WORD PTR [Left]
    asm mov     dx, WORD PTR [Left+2]   // Segment
    X = (int far*) MK_FP (_DX, _AX);
//  X = (int far *) MK_FP (FP_SEG (Right), (FP_OFF (Right) - FP_OFF (Left)) / 2);
    do  {
        while (*I < *X) {
            I++;
        }
        while (*J > *X) {
            J--;
        }
        if (I < J) {
            asm     les     bx, [J]
            asm     mov     ax, WORD PTR es:[bx]
            asm     les     bx, [I]
            asm     xchg    ax, WORD PTR es:[bx]
            asm     les     bx, [J]
            asm     mov     WORD PTR es:[bx], ax

            if (X == I) {
                X = J;
            } else if (X == J) {
                X = I;
            }
        }
        if (I <= J) {
            I++;
            if (J > Left) {
                J--;
            }
        }
    } while (I <= J);

    // Hier nochmals dasselbe:
    // Statt
    //   if ((J - Left) < (Right - I)) {
    // Schreibe:
    if ( (FP_OFF (J) - FP_OFF (Left)) < (FP_OFF (Right) - FP_OFF (I))) {
        if (Left < J) {
            QSort (Left, J);
        }
        if (I < Right) {
            Left = I;
            goto Again;         // QSort (I, Right)
        }
    } else {
        if (I < Right) {
            QSort (I, Right);
        }
        if (Left < J) {
            Right = J;          // QSort (Left, J)
            goto Again;
        }
    }
}


void pascal QuickSort (int far *Base, WORD Num)
// Quicksort, pr�ft die Parameter und ruft die Routine auf, die die
// eigentliche Arbeit macht.
{
    if (Num > 1) {
        QSort (Base, Base + (Num - 1));
    }
}




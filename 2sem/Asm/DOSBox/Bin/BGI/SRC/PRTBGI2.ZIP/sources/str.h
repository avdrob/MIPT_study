/******************************************************************************/
/*                                                                            */
/*                                   STR.H                                    */
/*                                                                            */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// (C) 1994 Ullrich von Bassewitz
//
// $Id: str.h 1.3 1995/04/28 16:20:27 Uz Exp $
//
// $Log: str.h $
// Revision 1.3  1995/04/28 16:20:27  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 1.2  95/04/22  17:27:57  Uz
// Neue Funktion memcpy.
//
// Revision 1.1  94/03/29  18:32:27  Uz
// Initial revision
//
//


#ifndef __STR_H
#define __STR_H



char far * pascal strcpy (char far * Dest, char far * Src);
// Kopiert Src nach Dest, liefert Dest zur�ck

char far * pascal strcat (char far *Dest, char far *Src);
// Kopiert Src an das Ende von Dest, liefert Dest zur�ck

unsigned pascal strlen (char far *S);
// Liefert die L�nge des Strings S zur�ck

void pascal memcpy (void far * Dest, void far * Src, unsigned Count);
// Kopiert Count Bytes von Src nach Dest, liefert Dest zur�ck



// End of STR.H

#endif


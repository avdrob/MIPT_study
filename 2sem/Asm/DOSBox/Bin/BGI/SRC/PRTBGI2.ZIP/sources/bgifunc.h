/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Enth�lt alle BGI-Funktionen, die nur auf PutPixel/GetPixel beruhen und   */
/* deshalb immer gleich bleiben.                                            */
/*                                                                          */
/****************************************************************************/



//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: bgifunc.h 2.8 1995/04/28 16:19:24 Uz Exp $
//
// $Log: bgifunc.h $
// Revision 2.8  1995/04/28 16:19:24  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.7  95/04/22  17:27:15  Uz
// Neue Funktion palette(). Diverse kleinere �nderungen zur Anpassung an
// die neue Version des Treibers mit DeskJet 1200C Support.
//
// Revision 2.6  94/09/08  14:15:20  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.5  94/09/08  09:34:04  Uz
// Anpassung an extra modedata Modul.
//
// Revision 2.4  94/03/19  16:16:20  Uz
// Cleanup und Kosmetik.
//
// Revision 2.3  93/08/01  20:53:27  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _BGIFUNC_H
#define _BGIFUNC_H


#include "const.h"


extern WORD MaxX;                       // X-Aufl�sung
extern WORD MaxY;                       // Y-Aufl�sung
extern int ClipX1;                      // Clip-Fenster X1
extern int ClipY1;                      // Clip-Fenster Y1
extern int ClipX2;                      // Clip-Fenster X2
extern int ClipY2;                      // Clip-Fenster Y2

// Die Farbtabelle wird (da nicht verwendet) als M�glichkeit zur Einstellung
// von diversen Daten von au�en benutzt. Sie hei�t daher nicht ColorTable
// (wie im SVGA-Treiber), sondern Settings (f�r die aktuelle Tabelle) und
// DefaultSettings (f�r die Default-Einstellungen).

extern BYTE DefaultSettings [];
extern BYTE Settings [];

// Defines zum Zugriff auf die Elemente von Settings und DefaultSettings
#define   djDefQuality      (DefaultSettings [2])
#define   djDefShingling    (DefaultSettings [3])
#define   djDefDepletion    (DefaultSettings [4])
#define   djDefMediaType    (DefaultSettings [5])
#define   djQuality         (Settings [2])
#define   djShingling       (Settings [3])
#define   djDepletion       (Settings [4])
#define   djMediaType       (Settings [5])


// RGB Palette.
struct RGBEntry {
    BYTE R, G, B;
};
extern RGBEntry RGBPal [256];



// Variable die nur in der neuen (bimodalen) Version definiert sind:
#ifdef Ver3
#define DataSeg 10h                     /* ACHTUNG: CS-relativ ! */
extern WORD     SegF000;                // Selektor f�r Segment F000
extern void far *Int1F;                 // Interruptvektor 1F
extern BOOLEAN  ProtMode;               // != 0 wenn Protected Mode
#endif




// Status-Record der an das Grafik-Kernel zur�ckgegeben wird (bzw. ein
// Zeiger darauf):

struct _stat {

  BYTE        Stat;             // Current device status.
  BYTE        DevType;          // Device Type Identifier.
  WORD        XRes;             // Device Full Resolution in X
  WORD        YRes;             // Device Full Resolution in Y
  WORD        XEfRes;           // Device Effective X Resolution
  WORD        YEfRes;           // Device Effective Y Resolution
  WORD        XInch;            // Device X Size in inches*1000
  WORD        YInch;            // Device Y Size in inches*1000
  WORD        Aspec;            // Aspect Ratio * 10000
  BYTE        ChSizX;           // Standard char size X
  BYTE        ChSizY;           // Standard char size Y
  BYTE        FColors;          // Number of foreground colors
  BYTE        BColors;          // Number of background colors

};

extern struct _stat Status;

/****************************************************************************/
/*                   Konstante f�r das Flags Byte von _DST                  */
/****************************************************************************/



const BYTE pfIsEpson        = 0x01;     // Epson-Modus

// Nadeldrucker-Flags
const BYTE pfReverse        = 0x02;     // Nadelnummerierung umdrehen (EPSON)

// Deskjet-Flags
const BYTE pfSeparateBlack  = 0x02;     // Separate Schwarz-Plane (Deskjet)
const BYTE pfDoCompression  = 0x04;     // TIFF Pacbits Kompression durchf�hren
const BYTE pfHasPalette     = 0x08;     // RGB Palette ja/nein



/****************************************************************************/
/*                  Grund-Deskriptor f�r einen Druckermodus                 */
/****************************************************************************/

// Die folgende struct enth�lt die Grund-Werte bzw. Funktionen, die sich
// nie �ndern. Jeder Treiber kann spezielle Funktionen am Ende hinzuf�gen.

struct _DST {

    WORD        XDPI;           // Aufl�sung in X-Richtung
    WORD        YDPI;           // Aufl�sung in Y-Richtung
    WORD        XInch;          // Gr��e X in Inch * 1000
    WORD        YInch;          // Gr��e Y in Inch * 1000

    WORD        ColorCount;     // Anzahl Farben des Modus
    BYTE        ColorBits;      // Anzahl Bit in denen ein Pixel codiert ist
    BYTE        Flags;          // Diverse bitmapped Flags

    char        *Name;          // Name des Modes

    void pascal (near *Print) (); /* Druck-Routine */
    void pascal (near *PutPixel) (WORD X, WORD Y, BYTE Color, BYTE WriteMode);
    BYTE pascal (near *GetPixel) (WORD X, WORD Y);


    // Member functions, die obige Flags auswerten, alle inline!
    BOOLEAN IsEpson () const        { return Flags & pfIsEpson; }
    BOOLEAN Reverse () const        { return Flags & pfReverse; }
    BOOLEAN SeparateBlack () const  { return Flags & pfSeparateBlack; }
    BOOLEAN DoCompression () const  { return Flags & pfDoCompression; }
    BOOLEAN HasPalette () const     { return Flags & pfHasPalette; }

};

// Der Zeiger auf die aktuelle DST
extern _DST near* DSTPtr;

/****************************************************************************/
/*                                                                          */
/* Clip pr�ft eine Koordinate gegen das Clip-Fenster und liefert TRUE       */
/* wenn der Punkt au�erhalb liegt, FALSE wenn er ok ist.                    */
/*                                                                          */
/****************************************************************************/

BOOLEAN _fastcall Clip (int X, int Y);



/*****************************************************************************/
/* Initialisierungsfunktion, ruft die Initialisierungen der Module der Reihe */
/* nach auf.                                                                 */
/*****************************************************************************/

void InitBGI ();



#endif

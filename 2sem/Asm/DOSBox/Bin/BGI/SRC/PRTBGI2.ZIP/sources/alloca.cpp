/*****************************************************************************/
/*                                                                           */
/*                                ALLOCA.CPP                                 */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: alloca.cpp 1.1 1995/04/28 16:21:19 Uz Exp $
//
// $Log: alloca.cpp $
// Revision 1.1  1995/04/28 16:21:19  Uz
// Initial revision
//
//
//



#include "const.h"



/*****************************************************************************/
/*                                   Code                                    */
/*****************************************************************************/



#pragma warn -rvl
BYTE _ss * pascal alloca (unsigned Size)
// Setzt ein Sprunglabel.
// Stack:
//      bp + 4  --> Size
//      bp + 2  --> R�cksprungadresse
//      bp + 0  --> Alter BP
{
    asm lea     ax, [bp+6]              // Frame des Aufrufers
    asm mov     bx, [Size]
    asm inc     bx
    asm and     bl, 0FEh                // Immer Worte vom Stack
    asm sub     ax, bx                  // Neuer SP
    asm mov     bx, [bp+2]              // R�cksprungadresse
    asm mov     bp, [bp+0]              // BP des Aufrufers
    asm mov     sp, ax
    asm jmp     bx                      // Zur�ck zum Aufrufer
}




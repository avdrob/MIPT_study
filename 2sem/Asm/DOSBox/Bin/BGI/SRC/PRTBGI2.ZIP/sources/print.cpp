/****************************************************************************/
/*                                                                          */
/*              Modul f�r BGI-Treiber zum Ansprechen des Druckers           */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: print.cpp 2.6 1995/04/28 16:21:14 Uz Exp $
//
// $Log: print.cpp $
// Revision 2.6  1995/04/28 16:21:14  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.5  95/04/22  17:34:02  Uz
// Neue Funktionen f�r den Ausdruck, PrintZString, PrintData, kleinere
// �nderungen bei existierenden Funktionen.
//
// Revision 2.4  94/09/08  14:14:51  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.3  93/08/01  20:53:10  Uz
// Neues Format mit DPMI-Support
//
//
//



#include <stddef.h>
#include "const.h"
#include "str.h"
#include "file.h"
#include "print.h"



/****************************************************************************/
/*                                                                          */
/*                               Variable                                   */
/*                                                                          */
/****************************************************************************/


// Ausgabepuffer und Deklarationen dazu
static BYTE _ss *OutputBuf;                     // Der Puffer
static WORD      OutputBufFill = 0;             // Anzahl Zeichen im Puffer

// Handle auf das geschrieben wird
static WORD     OutputHandle = 4;

// Merker f�r die Flags des Printer-Devices
WORD          PrinterFlags;

// Sprunglabel, das bei Fehlern bei der Ausgabe angesprungen wird.
JumpBuf PrintAbortLabel;



/****************************************************************************/
/*                                  Code                                    */
/****************************************************************************/



BOOLEAN pascal InitPrinter (BYTE _ss * Buf, int Handle)
// Stellt das Ausgabeger�t auf "binary" um und pr�ft gleichzeitig, ob das
// Handle 4 ok (offen) ist. Der aktuelle Zustand wird gemerkt und bei Post
// wiederhergestellt. Buf wird als Puffer f�r die Ausgabe verwendet und mu�
// PrintBufSize Bytes gro� sein. ACHTUNG: Buf mu� bis zum Aufruf von
// ResetPrinter g�ltig sein!
{
    // Puffer und Handle �bernehmen
    OutputBuf = Buf;
    OutputHandle = Handle;

    // Ger�t auf binary umstellen
    asm mov     ax, 4400h               // Get device data
    asm mov     bx, [OutputHandle]      // Drucker-Handle
    asm int     21h                     // IOCTL-Aufruf
    asm jnc     L1
    asm xor     bx, bx                  // Handle ist ung�ltig
    asm jmp     L3
L1: asm mov     ah, 0                   // Obere 8 Bits m�ssen 0 sein
    asm mov     [PrinterFlags], ax      // merken
    asm test    al, 80h                 // Bit 7 = 0 ?
    asm jz      L2                      // Springe wenn File-Handle
    asm or      al, 20h                 // "raw data" bit setzen
    asm mov     bx, [OutputHandle]      // Drucker-Handle
    asm xchg    ax, dx                  // device data nach dx
    asm mov     ax, 4401h               // Set device data
    asm int     21h                     // IOCTL-Aufruf
L2: asm mov     bl, 1                   // Ergebnis = TRUE
L3: asm xchg    ax, bx                  // Ergebnis nach ax
    return _AL;
}



void pascal ResetPrinter ()
// Stellt den orginalen Zustand des Ausgabeger�ts wieder her.
{
    asm mov     dx, [PrinterFlags]      // Orginale Flags holen
    asm test    dl, 80h                 // File-Handle ?
    asm jz      L1                      // Springe wenn ja
    asm mov     ax, 4401h               // Set device data
    asm mov     bx, [OutputHandle]      // Druckerhandle
    asm int     21h                     // IOCTL Data
L1:
}



void pascal Flush ()
// Schreibt den Ausgabepuffer leer. Mu� am Ende eines Ausdrucks aufgerufen
// werden. Springt PrintAbortLabel an bei Fehlern.
{
    if (OutputBufFill > 0) {
        if (write (OutputHandle, OutputBuf, OutputBufFill) != 0) {
            // Fehler beim Schreiben, Fehleraussprung
            LongJump (PrintAbortLabel, 1);
        }
        // Puffer ist wieder leer
        OutputBufFill = 0;
    }
}



void pascal PrintByte (BYTE B)
// Gibt ein Byte auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.
{
    // Pr�fen ob noch Platz im Puffer ist, wenn Nein Puffer leeren
    if (OutputBufFill == PrintBufSize) {
        // Puffer ist voll, leeren
        Flush ();
    }

    // Neues Byte in den Puffer schreiben
    OutputBuf [OutputBufFill++] = B;
}



void PrintData (BYTE far *Data, unsigned Size)
// Gibt Daten auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.
{
    asm les     si, [Data]
    asm test    si, si                  // Offset == NULL ?
    asm jz      L1                      // Springe wenn ja
    asm mov     di, [Size]              // Anzahl nach di
    asm test    di, di                  // Anzahl == 0 ?
    asm jz      L1                      // Springe wenn ja
    asm cld
L0: asm mov     es, WORD PTR [Data+2]   // es nachladen
    asm mov     al, es:[si]             // Ausgabebyte holen
    asm inc     si                      // Zeiger erh�hen
    PrintByte (_AX);                    // und C++ Aufruf
    asm dec     di                      // Noch Bytes �brig?
    asm jnz     L0
L1: return;
}



void pascal PrintString (char far *S)
// Gibt einen Pascal-String auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.
{
    if (FP_OFF (S) != 0) {
        PrintData (&S [1], *S);
    }
}



void pascal PrintZString (char far *S)
// Gibt einen nullterminierten String auf den Drucker (bzw. in den
// Ausgabepuffer) aus. Springt PrintAbortLabel an bei Fehlern.
{
    PrintData (S, strlen (S));
}




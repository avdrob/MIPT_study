/************************************************************************/
/*                                                                      */
/*    Fixed-Point Sinus/Cosinus-Routinen f�r den Plotter-BGI-Treiber    */
/*                                                                      */
/*               Ullrich von Bassewitz am 21.10.1992                    */
/*                                                                      */
/************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: sincos.cpp 2.4 1994/09/08 14:14:55 Uz Exp $
//
// $Log: sincos.cpp $
// Revision 2.4  1994/09/08 14:14:55  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.3  93/08/01  20:53:14  Uz
// Neues Format mit DPMI-Support
//
//
//


// Sinustabelle von 0 - 90�, skaliert mit 32768 (2^15). Der einzige Wert, der
// etwas angepa�t wurde ist +1 (bei 90�). Aus 8000h wurden hier 7FFFh gemacht.

static int SinTab [91] = {

    0x0000, 0x023C, 0x0478, 0x06B3, 0x08EE, 0x0B28,     //  0 -   5
    0x0D61, 0x0F99, 0x11D0, 0x1406, 0x163A, 0x186C,     //  6 -  11
    0x1A9D, 0x1CCB, 0x1EF7, 0x2121, 0x2348, 0x256C,     // 12 -  17
    0x278E, 0x29AC, 0x2BC7, 0x2DDF, 0x2FF3, 0x3203,     // 18 -  23
    0x3410, 0x3618, 0x381D, 0x3A1C, 0x3C18, 0x3E0E,     // 24 -  29
    0x4000, 0x41ED, 0x43D4, 0x45B7, 0x4794, 0x496B,     // 30 -  35
    0x4B3D, 0x4D08, 0x4ECE, 0x508E, 0x5247, 0x53FA,     // 36 -  41
    0x55A6, 0x574C, 0x58EB, 0x5A82, 0x5C13, 0x5D9D,     // 42 -  47
    0x5F1F, 0x609A, 0x620E, 0x637A, 0x64DE, 0x663A,     // 48 -  53
    0x678E, 0x68DA, 0x6A1E, 0x6B5A, 0x6C8D, 0x6DB8,     // 54 -  59
    0x6EDA, 0x6FF4, 0x7104, 0x720D, 0x730C, 0x7402,     // 60 -  65
    0x74EF, 0x75D3, 0x76AE, 0x7780, 0x7848, 0x7907,     // 66 -  71
    0x79BC, 0x7A68, 0x7B0B, 0x7BA3, 0x7C33, 0x7CB8,     // 72 -  77
    0x7D34, 0x7DA6, 0x7E0E, 0x7E6D, 0x7EC1, 0x7F0C,     // 78 -  83
    0x7F4C, 0x7F83, 0x7FB0, 0x7FD3, 0x7FEC, 0x7FFB,     // 84 -  89
    0x7FFF                                              // 90
};



void pascal NormAngle (int _ss& Angle)
// Bringt den �bergebenen Winkel in den Bereich 0..359
{
    asm     mov     bx, [Angle]
    asm     mov     ax, ss:[bx]
    asm     or      ax, ax
    asm     jmp     L2
L1: asm     add     ax, 360
L2: asm     js      L1
    asm     jmp     L4
L3: asm     sub     ax, 360
L4: asm     cmp     ax, 360
    asm     jge     L3
    asm     mov     ss:[bx], ax
}





int pascal SinMul (int Angle, int Mult)
// Liefert Sin (Angle) * Mult zur�ck.
{
    // Winkel in den Bereich 0..359 bringen
    NormAngle (Angle);

    if (Angle <= 90) {
        Angle = SinTab [Angle];
    } else if (Angle <= 180) {
        Angle = SinTab [180 - Angle];
    } else if (Angle <= 270) {
        Angle = -SinTab [Angle - 180];
    } else {
        Angle = -SinTab [360 - Angle];
    }

    // In Angle steht jetzt der skaliert Sinuswert. Die Multiplikation
    // ausf�hren, das (unskalierte) Ergebnis nach ax
    asm     mov     ax, [Angle]         // Sinuswert, skaliert
    asm     imul    [Mult]
    asm     add     ax, 4000h           // runden
    asm     adc     dx, 0
    asm     shl     ax, 1
    asm     rcl     dx, 1
    asm     xchg    ax, dx

    // Ergebnis steht jetzt in ax
    return _AX;

}



int pascal CosMul (int Angle, int Mult)
// Liefert Cos (Angle) * Mult zur�ck
{
    return SinMul (Angle + 90, Mult);
}






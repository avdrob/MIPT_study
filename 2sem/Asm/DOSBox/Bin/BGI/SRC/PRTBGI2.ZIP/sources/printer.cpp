//
//  BGI-Treiber f�r Drucker.
//
//  Ullrich von Bassewitz am 08.09.1991
//
//
//


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: printer.cpp 2.16 1995/04/28 16:21:35 Uz Exp $
//
// $Log: printer.cpp $
// Revision 2.16  1995/04/28 16:21:35  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.15  95/04/22  17:31:29  Uz
// Anpassungen an neue Version mit DeskJet 1200C Support.
//
// Revision 2.14  95/03/29  15:37:27  Uz
// Blattgr��e f�r den Status-Record wird nicht mehr aus den DST's �bernommen,
// sondern zur Umgehung eines Fehlers im Grafik-Kernel auf den maximal
// m�glichen Wert gesetzt.
//
// Revision 2.13  95/03/20  14:56:52  Uz
// Aufl�sung im Status-Record der an den Kernel geht auf max. 179
// begrenzt.
//
// Revision 2.12  94/09/08  09:33:08  Uz
// Neues Modul f�r Druckerdaten: modedata. 3 benutzerdefinierte Modi, kleinere
// �nderungen.
//
// Revision 2.11  94/03/29  20:45:01  Uz
// str.h anstelle von string.h verwendet
//
// Revision 2.10  94/03/28  16:40:58  Uz
// Name des Modus NEC P6 360*360 DPI Farbe war falsch.
//
// Revision 2.9  94/03/19  16:19:52  Uz
// Cleanup und Kosmetik.
//
// Revision 2.8  94/03/03  18:01:41  Uz
// Korrektur von r2.5: SearchBGIPath enthielt leider mehrere PUSH CS/POP ES
// Sequenzen, die im Protected-Mode nat�rlich nicht mehr tun. Das f�hrte zu
// Fehlern beim Laden von benutzerdefinierten Drucker-Beschreibungsdateien.
//
// Revision 2.7  94/02/25  14:13:59  Uz
// Fehler aus Init beseitigt: Anstelle des AspectRatios wurde der
// Kehrwert berechnet, was bei Modi mit ungleichen X/Y-Aufl�sungen
// zu "verbogenen" Kreisen gef�hrt hat.
//
// Revision 2.6  94/01/13  11:32:14  Uz
// Neue Modi f�r DeskJet 550C mit Schwarzabtrennung.
//
// Revision 2.5  93/11/07  20:14:24  Uz
// SearchBGIPath kann auch im Protected-Mode sicher aufgerufen werden,
// da die entsprechenden DOS-Funktionen bzw. Speicherstellen unter
// DPMI tats�chlich Selektoren und keine Segmentwerte liefern (war
// leider nirgendwo dokumentiert).
//
// Revision 2.4  93/10/24  17:56:46  Uz
// Neue Modi f�r IBM Proprinter X24, benutzerdefinierte Modi ge�ndert,
// Fehler bei der bedingten Compilierung f�r altes Format entfernt.
//
// Revision 2.3  93/08/01  20:53:11  Uz
// Neues Format mit DPMI-Support
//
//
//



#include    <dir.h>
#include    "str.h"             // String-Funktionen
#include    "const.h"
#include    "util.h"            // Allgemeine Hilfsroutinen
#include    "file.h"
#include    "memory.h"          // Speicherverwaltung
#include    "print.h"
#include    "lj.h"
#include    "np.h"
#include    "prndata.h"
#include    "bgifunc.h"



/****************************************************************************/
/*                                 Prototypen                               */
/****************************************************************************/



// Hier stehen alle Funktionen deren Namen nicht "gemangelt" werden sollen,
// weil sie im Assembler-Teil verwendet werden.

extern "C" {

  void cdecl install    ();
  void cdecl allpalette ();

}



/****************************************************************************/
/*                         Statische Daten des Treibers                     */
/****************************************************************************/



// Konstanten f�r die benutzerdefinierten Nadeldruckermodi
static const UserMode1  = 13;
static const UserMode2  = 14;
static const UserMode3  = 15;



/****************************************************************************/
/*               Laden der benutzerdefinierten Drucker-Daten                */
/****************************************************************************/



static void pascal SearchBGIPath (char _ss *EXEPath, char _ss *BGIPath)
/* Durchsucht das Environment nach dem Eintrag "BGIPATH=" und bildet (falls
 * gefunden) aus dem dort stehenden String und dem �bergebenen Filenamen
 * einen kompletten Pfad der in BGIPath gespeichert wird. Falls eine DOS-
 * Version nach 3.0 vorliegt, wird au�erdem in EXEPath der komplette Pfad
 * der EXE-Datei zur�ckgeliefert.
 */

{
    BYTE DosVersion;                        // DOS-Version
    WORD PSPSeg;                            // PSP des Hauptprogramms
    static char PathCode[] = "BGIPATH=";    // Danach suchen wir


    asm    mov     ah, 30h
    asm    int     21h                      // get dos version
    asm    mov     [DosVersion], al
    asm    mov     ax, 5100h                // Get PSP < DOS 3
    asm    cmp     Byte Ptr [DosVersion], 03h     // Version 3.XX ?
    asm    jb      L1
    asm    mov     ax, 6200h                // Get PSP >= DOS 3.0
L1: asm    int     21h                      // Get PSP
    asm    mov     [PSPSeg], bx             // PSP merken
    asm    mov     dx, ds                   // Datensegemnt retten
    asm    mov     ds, bx                   // ds = PSPSeg
    asm    mov     ds, WORD PTR [ds:2ch]    // ds = Environment
    asm    xor     si, si                   // Startoffset = 0
    asm    cld                              // raufw�rts z�hlen
L2: asm    lea     di, PathCode
    asm    push    cs
    asm    pop     es                       // es:di = "BGIPATH="
    asm    mov     cx, 8                    // Stringl�nge
    asm    repz    cmpsb                    // Eintrag gefunden ?
    asm    jz      L5                       // Eintrag gefunden !
    asm    dec     si                       // Ein Zeichen zur�ck sonst
L3: asm    lodsb                            // Und nach Endezeichen suchen
    asm    or      al, al                   // 0 (= Ende) ?
    asm    jnz     L3                       // Nein, weitersuchen
    asm    cmp     al, Byte Ptr [si]        // Zweite 0 (Tabellenende) ?
    asm    jne     L2                       // Nein, weitersuchen

// Eintrag "BGIPATH=" nicht gefunden, BGIPath ist leer

L4: asm    push    ss
    asm    pop     es
    asm    mov     di, [BGIPath]            // Ziel nach es:di
    asm    stosb                            // 0 speichern (= Leerstring)
    asm    jmp     L9                       // Weiter, EXE-Pfad suchen

// Eintrag "BGIPath=" gefunden, String kopieren

L5: asm    push    ss
    asm    pop     es
    asm    mov     di, [BGIPath]            // Ziel nach es:di
    asm    mov     al, 0
    asm    cmp     Byte Ptr [si], al        // Kein String *?
    asm    jz      L8                       // Kein String !
L6: asm    mov     ah, al                   // Letztes Zeichen merken
    asm    lodsb                            // Zeichen holen
    asm    or      al, al                   // Endezeichen ?
    asm    jz      L7                       // Springe wenn ja
    asm    stosb                            // Zeichen speichern
    asm    jmp     L6                       // N�chstes Zeichen

// Pfadende, pr�fen ob '\' letztes Zeichen ist. Anf�gen wenn nicht

L7: asm    mov     al, '\'
    asm    cmp     ah, al
    asm    jz      L8                       // H�ngt schon dran
    asm    stosb                            // Sonst anh�ngen
L8: asm    mov     Byte Ptr [es:di], 0      // Und Ende markieren

// "BGIPath=" wurde komplett behandelt. Nach dem Start des EXE-Namens
// suchen. Einsprung hier mit si als Zeiger auf das Byte nach der
// abschliessenden 0 eines normalen Eintrags.

L9: asm    push    ss
    asm    pop     es
    asm    mov     di, [EXEPath]            // Neues Ziel
    asm    cmp     Byte Ptr [DosVersion], 03h     // Nur ab Version 3.0 verf�gbar
    asm    jae     M2                       // Ok, start ...
    asm    mov     Byte Ptr es:[di], 00h    // EXEPath ist leer
    asm    jmp     M7                       // Sorry ...

M1: asm    lodsb                            // N�chstes Zeichen holen
    asm    or      al, al                   // = 0 ?
    asm    jnz     M1                       // Suche nach 0
M2: asm    lodsb                            // Ende pr�fen
    asm    or      al, al
    asm    jnz     M1

// N�chste zwei Bytes �berspringen

    asm    inc     si
    asm    inc     si

// si zeigt auf den Start des EXE-Namens

M4: asm    mov     bx, di                   // Adresse letztes '\' merken
M5: asm    lodsb                            // Zeichen holen
    asm    stosb                            // Zeichen speichern
    asm    or      al, al                   // Ende ?
    asm    jz      M6                       // Springe wenn ja
    asm    cmp     al, '\'                  // Pfad-Trenner
    asm    jz      M4                       // Position merken und weiter
    asm    jmp     M5                       // weiter

// Ende des Kopierens. bx zeigt auf das letzte '\'

M6: asm    mov     Byte Ptr [es:bx], 00h    // Ende markieren

// Fertig, Datensegment r�cksetzen und Ende

M7: asm    mov     ds, dx

}





static void * pascal _LoadUserFile (char far *FileName)
// Versucht die Datei mit dem �bergebenen Namen in den Puffer zu laden.
// Das Ergebnis der Routine ist ein Zeiger auf den Puffer in den die Datei
// geladen wurde, oder NULL, wenn das Laden mi�lang

{
    int  Handle;
    long Length;
    static BYTE _PRNData [256];
    EpsonDST near *PRNData = NULL;

    // Datei �ffnen
    Handle = open (FileName, fmRead);
    if (Handle < 0) {
        // Fehler beim �ffnen
        goto ExitPoint;
    }

    // Dateil�nge holen, mu� <= 256 sein
    Length = filelength (Handle);
    if (Length > 256L) {
        // Datei zu gro� --> Schlie�en und Ende
        goto ExitWithClose;
    }

    // Daten in den Puffer lesen
    if (read (Handle, _PRNData, (WORD) Length) != 0) {
        // Fehler beim Lesen
        goto ExitWithClose;
    }

    // Zeiger setzen
    PRNData = (EpsonDST near*) _PRNData;

    // Strings relozieren
    PRNData->DST.Name     += (WORD) _PRNData;
    PRNData->LineFeed1    += (WORD) _PRNData;
    PRNData->LineFeed2    += (WORD) _PRNData;
    PRNData->GraphicsOn   += (WORD) _PRNData;
    PRNData->GraphicsOff  += (WORD) _PRNData;
    PRNData->PreBytes     += (WORD) _PRNData;
    PRNData->PostBytes    += (WORD) _PRNData;

    /* Druckroutine eintragen */
    PRNData->DST.Print     = EpsonPrint;

    // PutPixel/GetPixel-Routinen eintragen
    PRNData->DST.PutPixel  = EpsonPutPixel;
    PRNData->DST.GetPixel  = EpsonGetPixel;

ExitWithClose:
    // Datei schlie�en
    close (Handle);

ExitPoint:
    // Zeiger auf den Mode-Deskriptor zur�ckgeben
    return PRNData;
}




static void pascal LoadUserFile (char far *FileName, unsigned Mode)
// Versucht die Datei mit dem Namen FileName zuerst im aktuellen, dann im
// Verzeichnis EXEPath und zuletzt im Verzeichnis BGIPath zu finden und zu
// laden.
// EXEPath und BGIPath m�ssen dabei zwei Pfade sein, die mit einem Backslash
// enden.
// Bei Erfolg der Aktion wird die Adresse des Puffers in die Tabelle der
// DST's eingetragen, bei Mi�erfolg passiert nix.
{
    void *Buffer;                 // Zeiger auf Puffer f�r Modus-Daten

    // Zuerst im aktuellen Verzeichnis versuchen
    if ((Buffer = _LoadUserFile (FileName)) != NULL) {
        // Eintragen und Ende
        DSTTable [Mode] = (_DST *) Buffer;
        return;
    }

    // EXE und BGI-Verzeichnis aus dem Environment suchen
    char EXEPath [80];
    char BGIPath [80];
    SearchBGIPath (EXEPath, BGIPath);

    // Datei im EXE-Verzeichnis suchen
    if (*EXEPath != 0x00) {
        /* Ende des Pfades merken */
        char _ss *PathEnd = EXEPath + strlen (EXEPath);
        strcpy (PathEnd, FileName);
        if ((Buffer = _LoadUserFile (EXEPath)) != NULL) {
            // Pfad wieder r�cksetzen
            *PathEnd = 0x00;
            // Eintragen und Ende
            DSTTable [Mode] = (_DST *) Buffer;
            return;
        }
        /* Pfad wieder r�cksetzen */
        *PathEnd = 0x00;
    }

    // Datei im BGI-Verzeichnis suchen
    if (*BGIPath != 0x00) {
        /* Ende des Pfades merken */
        char _ss *PathEnd = BGIPath + strlen (BGIPath);
        strcpy (PathEnd, FileName);
        if ((Buffer = _LoadUserFile (BGIPath)) != NULL) {
            // Pfad wieder r�cksetzen
            *PathEnd = 0x00;
            // Eintragen und Ende
            DSTTable [Mode] = (_DST *) Buffer;
            return;
        }
        /* Pfad wieder r�cksetzen */
        *PathEnd = 0x00;
    }

}



/* ----------------------------- INSTALL ------------------------------- */
/*                                                                       */
/*      The Install function is used to prepare the driver to use.       */
/*      The calls to this function allow the kernal to inquire the       */
/*      mode information, and allow the kernal to install the mode       */
/*      infomation.                                                      */
/*                                                                       */


static void pascal InvalidMode (void)
// Setzt den DSTPtr auf die erste DST und tr�gt einen Fehler ein
{
  DSTPtr = DSTTable [0];
  Status.Stat = grInvalidMode;
}





void cdecl install ()
{
    BYTE Mode, Cmd;
    DWORD MemSize;              // Ben�tigte Speichergr��e
    WORD Tmp;                   // Anzahl Nadeln


    // Modus steht in cl, Kommando in al
    Cmd  = _AL;
    Mode = _CL;

    // Kommando unterscheiden
    switch (Cmd) {

        // Install device
        case 0:
            // Variablen des Treibers korrekt setzen
            InitBGI ();

            // Benutzerdefinierte Modi gesondert behandeln
            if (Mode == UserMode1 || Mode == UserMode2 || Mode == UserMode3) {

                // Je nach Modus versuchen die entsprechende Datei zu laden
                char* DefName;
                switch (Mode) {
                    case UserMode1:     DefName = "PRINTER1.PDF"; break;
                    case UserMode2:     DefName = "PRINTER2.PDF"; break;
                    case UserMode3:     DefName = "PRINTER3.PDF"; break;
                }
                LoadUserFile (DefName, Mode);

            }

            // Pr�fen, ob der Modus zul�ssig ist
            if ((Mode >= MaxModes) || (DSTTable [Mode] == NULL)) {
                // Ung�ltige Modusnummer oder kein Parametersatz
                InvalidMode ();
            } else {
                // Den Zeiger auf die richtige DST setzen
                DSTPtr = DSTTable [Mode];
            }

            // Aus den in der DST gespeicherten Werten den Status-Record
            // zusammenbauen, der sp�ter an das Kernel zur�ckgeht.
            asm     mov     bx, [DSTPtr]
            asm     mov     cx, 1000
            asm     mov     ax, [bx].XDPI
            asm     mul     WORD PTR [bx]. (_DST) XInch
            asm     div     cx
            asm     and     ax, 0FFF8h                  // durch 8 teilbar machen
            asm     dec     ax
            asm     mov     WORD PTR [Status.XRes], ax
            asm     mov     WORD PTR [Status.XEfRes], ax
            asm     mov     ax, [bx].YDPI
            asm     mul     WORD PTR [bx]. (_DST) YInch
            asm     div     cx
            asm     and     ax, 0FFF8h                  // durch 8 teilbar machen
            asm     dec     ax
            asm     mov     WORD PTR [Status.YRes], ax
            asm     mov     WORD PTR [Status.YEfRes], ax
            asm     mov     ax, 10000
            asm     mul     WORD PTR [bx].YDPI
            asm     div     WORD PTR [bx].XDPI
            asm     mov     WORD PTR [Status.Aspec], ax

            // Berechnen wieviel Speicher notwendig ist. Da Nadeldrucker die Anzahl
            // Nadeln immer untereinander drucken, in diesem Fall die X-Aufl�sung
            // so erweitern, das beim Bildende auf den unteren Nadeln kein Mist
            // kommt (d.h. f�r die Berechnung die X-Koordinate aufrunden).
            if (DSTPtr->IsEpson ()) {
                // Ausrechnen wieviele X-Einheiten immer zusammengeh�ren
                Tmp = ((WORD) ((EpsonDST *) DSTPtr)->ColBytes *
                       (WORD) ((EpsonDST *) DSTPtr)->PassCount) * 8;

                // Den X-Wert auf das n�chste vielfache dieses Wertes aufrunden
                Tmp = ((Status.XEfRes + Tmp) / Tmp) * Tmp;

                // Den f�r eine Farb-Plane ben�tigten Wert berechnen und diesen
                // f�r sp�tere Ausgaben merken
                ColorPlaneSize = LongMul (Tmp, Status.YEfRes + 1) / 8;

                // Gesamten ben�tigten Speicher berechnen
                MemSize = ColorPlaneSize * DSTPtr->ColorBits;
            } else {
                MemSize = (LongMul (Status.XEfRes + 1, Status.YEfRes + 1) *
                           (DWORD) DSTPtr->ColorBits) / 8;
            }

            // Speicher initialisieren
            InitMemory (MemSize);

            // Bei Fehlern das Statusbyte setzen
            if (Result != 0) {

                // Keine M�glichkeit zur Speicherung gefunden --> Fehler
                Status.Stat = grIOError;

            }

            // Zeiger auf DST in es:bx r�ckliefern
            _BX = (WORD) &Status;
            _ES = _DS;

            // Fertig
            break;


      case 1:
          // Mode-Query
          _CX = MaxModes;
          break;


      case 2:
          // Mode-Name
          if (Mode >= MaxModes) {
              Mode = 0;
          } else if (DSTTable [Mode] == NULL) {
              Mode = 0;
          }
          _BX = (WORD) DSTTable [Mode]->Name;
          _ES = _DS;
          break;

    }
}


/* ----------------------------- ALLPALETTE ---------------------------- */
/*                                                                       */
/*      The all palette command is used to load an entire palette in     */
/*      a single output command. The current BGI limits the size of      */
/*      the allpalette command to be the first 16 colors.                */
/*                                                                       */

void cdecl allpalette ()
{
    // Zeiger auf neue Palette holen
    BYTE far *NewPal;
    asm     mov     WORD PTR [NewPal], bx
    asm     mov     WORD PTR [NewPal+2], es

    // Neue Palette �bernehmen (ab 1. Element), dann auf G�ltigkeit pr�fen
    memcpy (&Settings [1], NewPal, 8);

    // G�ltigkeit der wichtigen Eintr�ge pr�fen
    if (djQuality > 2) {
        // Default nehmen
        djQuality = djDefQuality;
    }
    if (djShingling > 2) {
        // Default nehmen
        djShingling = djDefShingling;
    }
    if (djDepletion > 2) {
        // Default nehmen
        djDepletion = djDefDepletion;
    }
    if (djMediaType > 4) {
        // Default nehmen
        djMediaType = djDefMediaType;
    }
}







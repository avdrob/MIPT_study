//
//  BGI-Treiber f�r PCX-Dateien.
//
//  Ullrich von Bassewitz am 28.04.1995
//
//
//


//
// (C) 1990-1995 Ullrich von Bassewitz
//
// $Id: pcxmain.cpp 1.1 1995/04/28 16:21:39 Uz Exp $
//
// $Log: pcxmain.cpp $
// Revision 1.1  1995/04/28 16:21:39  Uz
// Initial revision
//
//
//



#include "const.h"
#include "str.h"             // String-Funktionen
#include "util.h"
#include "memory.h"          // Speicherverwaltung
#include "pcxdata.h"
#include "bgifunc.h"



/****************************************************************************/
/*                                 Prototypen                               */
/****************************************************************************/



// Hier stehen alle Funktionen deren Namen nicht "gemangelt" werden sollen,
// weil sie im Assembler-Teil verwendet werden.

extern "C" {

  void cdecl install    ();
  void cdecl allpalette ();

}



/****************************************************************************/
/*                                  Structs                                 */
/****************************************************************************/



struct UserData {

    unsigned    Magic1;         // DWORD Magic als 2 WORDS
    unsigned    Magic2;

    unsigned    MaxX;
    unsigned    MaxY;

};



/****************************************************************************/
/*          Suchen nach den Daten f�r den benutzerdefinierten Modus         */
/****************************************************************************/



static UserData far* GetVec (unsigned Num)
// Holt einen Interrupt-Vektor
{
    // Vektornummer nach bx
    asm mov     bx, [Num]

#ifdef Ver3
    asm cmp     [ProtMode], 0           // L�uft der Treiber im PM?
    asm jz      L1                      // Springe wenn Nein

// Vektor im PM holen

    asm mov     ax, 0204h               // Get protected mode vector
    asm int     31h
    asm xchg    dx, ax                  // Offset nach ax
    asm mov     dx, cx                  // Selektor nach dx
    asm jmp     L2                      // Und Ende...
#endif

// Vektor im Real-Mode holen

L1: asm sub     ax, ax
    asm mov     es, ax
    asm shl     bx, 1
    asm shl     bx, 1
    asm mov     ax, es:[bx]
    asm mov     dx, es:[bx+2]
L2: return (UserData far*) MK_FP (_DX, _AX);
}



static void InstallUserMode ()
// Sucht nach den Daten f�r den benutzerdefinierten Modus.
{
    const unsigned MagicCode1 = 0x6E41;
    const unsigned MagicCode2 = 0x616E;
    const unsigned FirstVec   = 0x60;
    const unsigned LastVec    = 0x6F;

    for (unsigned I = FirstVec; I <= LastVec; I++) {

        // Vektor holen
        UserData far* P = GetVec (I);

        // Nach dem Magic schauen
        if (P && P->Magic1 == MagicCode1 && P->Magic2 == MagicCode2) {
            // Gefunden, Daten �bernehmen und Ende
            _DST near* DST = DSTTable [UserMode];
            DST->XInch = P->MaxX;
            DST->YInch = P->MaxY;
            return;
        }
    }
}



/* ----------------------------- INSTALL ------------------------------- */
/*                                                                       */
/*      The Install function is used to prepare the driver to use.       */
/*      The calls to this function allow the kernal to inquire the       */
/*      mode information, and allow the kernal to install the mode       */
/*      infomation.                                                      */
/*                                                                       */


static void pascal InvalidMode (void)
// Setzt den DSTPtr auf die erste DST und tr�gt einen Fehler ein
{
  DSTPtr = DSTTable [0];
  Status.Stat = grInvalidMode;
}





void cdecl install ()
{
    DWORD MemSize;              // Ben�tigte Speichergr��e


    // Modus steht in cl, Kommando in al
    BYTE Cmd  = _AL;
    BYTE Mode = _CL;

    // Kommando unterscheiden
    switch (Cmd) {

        // Install device
        case 0:
            // Variablen des Treibers korrekt setzen
            InitBGI ();

            // Benutzermodus installieren
            InstallUserMode ();

            // Pr�fen, ob der Modus zul�ssig ist
            if ((Mode >= MaxModes) || (DSTTable [Mode] == NULL)) {
                // Ung�ltige Modusnummer oder kein Parametersatz
                InvalidMode ();
            } else {
                // Den Zeiger auf die richtige DST setzen
                DSTPtr = DSTTable [Mode];
            }

            // Aus den in der DST gespeicherten Werten den Status-Record
            // zusammenbauen, der sp�ter an das Kernel zur�ckgeht.
            Status.XRes = Status.XEfRes = DSTPtr->XInch - 1;
            Status.YRes = Status.YEfRes = DSTPtr->YInch - 1;
            Status.Aspec = LongDiv (LongMul (DSTPtr->YDPI, 10000), DSTPtr->XDPI);

            // Berechnen wieviel Speicher notwendig ist.
            MemSize = (LongMul (Status.XEfRes + 1, Status.YEfRes + 1) *
                       (DWORD) DSTPtr->ColorBits) / 8;

            // Speicher initialisieren
            InitMemory (MemSize);

            // Bei Fehlern das Statusbyte setzen
            if (Result != 0) {

                // Keine M�glichkeit zur Speicherung gefunden --> Fehler
                Status.Stat = grIOError;

            }

            // Zeiger auf DST in es:bx r�ckliefern
            _BX = (WORD) &Status;
            _ES = _DS;

            // Fertig
            break;


      case 1:
          // Mode-Query
          _CX = MaxModes;
          break;


      case 2:
          // Mode-Name
          if (Mode >= MaxModes) {
              Mode = 0;
          } else if (DSTTable [Mode] == NULL) {
              Mode = 0;
          }
          _BX = (WORD) DSTTable [Mode]->Name;
          _ES = _DS;
          break;

    }
}


/* ----------------------------- ALLPALETTE ---------------------------- */
/*                                                                       */
/*      The all palette command is used to load an entire palette in     */
/*      a single output command. The current BGI limits the size of      */
/*      the allpalette command to be the first 16 colors.                */
/*                                                                       */

void cdecl allpalette ()
{
    // Funktion wird im PCX-Treiber ignoriert.
}







/******************************************************************************/
/*                                                                            */
/*                                PCXDATA.CPP                                 */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// (C) 1995 Ullrich von Bassewitz
//
// $Id: pcxdata.cpp 1.1 1995/04/28 16:21:45 Uz Exp $
//
// $Log: pcxdata.cpp $
// Revision 1.1  1995/04/28 16:21:45  Uz
// Initial revision
//
//
//



#include "pcxdata.h"
#include "pcx.h"



/****************************************************************************/
/*                         PCX, 320*200, 256 Farben                         */
/****************************************************************************/

static _DST PCX320x200 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    320, 200,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 320*200*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 320*240, 256 Farben                         */
/****************************************************************************/

static _DST PCX320x240 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    320, 240,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 320*240*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 640*350, 256 Farben                         */
/****************************************************************************/

static _DST PCX640x350 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    640, 350,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 640*350*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 640*400, 256 Farben                         */
/****************************************************************************/

static _DST PCX640x400 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    640, 400,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 640*400*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 640*480, 256 Farben                         */
/****************************************************************************/

static _DST PCX640x480 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    640, 480,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 640*480*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 800*600, 256 Farben                         */
/****************************************************************************/

static _DST PCX800x600 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    800, 600,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x0F""PCX 800*600*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 1024*768, 256 Farben                        */
/****************************************************************************/

static _DST PCX1024x768 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    1024, 768,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x10""PCX 1024*768*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         PCX, 1152*910, 256 Farben                        */
/****************************************************************************/

static _DST PCX1152x910 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    1152, 910,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x10""PCX 1152*910*256",            // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                        PCX, 1280*1024, 256 Farben                        */
/****************************************************************************/

static _DST PCX1280x1024 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    1280, 1024,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x11""PCX 1280*1024*256",           // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                         Benutzerdefinierter Modus                        */
/****************************************************************************/

static _DST PCXUserDef = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    640, 480,

    // Anzahl Farben und Bits pro Pixel
    256, 8,

    // Flags
    pfHasPalette,

    // Name des Modus
    "\x15""PCX User defined size",              // Name des Modus

    /* Druckeroutine */
    PCXPrint,

    // Put- und GetPixel
    PCXPutPixel,
    PCXGetPixel

};



/****************************************************************************/
/*                      Das Array Zeigern auf die DST's                     */
/****************************************************************************/

_DST near* DSTTable [MaxModes] = {

    &PCX320x200,                        // 0
    &PCX320x240,                        // 1
    &PCX640x350,                        // 2
    &PCX640x400,                        // 3
    &PCX640x480,                        // 4
    &PCX800x600,                        // 5
    &PCX1024x768,                       // 6
    &PCX1152x910,                       // 7
    &PCX1280x1024,                      // 8
    &PCXUserDef,                        // 9

};




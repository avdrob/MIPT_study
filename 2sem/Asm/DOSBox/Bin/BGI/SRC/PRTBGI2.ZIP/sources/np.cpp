/******************************************************************************/
/*                                                                            */
/*                                  NP.CPP                                    */
/*                                                                            */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



#include "const.h"
#include "util.h"               // Allgemeine Hilfsroutinen
#include "memory.h"             // Speicherverwaltung
#include "print.h"              // Ausgabe auf Drucker
#include "np.h"                 // Eigene Deklarationen
#include "bgifunc.h"            // Grundlegende BGI-Funktionen
#include "jump.h"               // SetJump/LongJump
#include "alloca.h"             // alloca



//
// Anmerkung zur Speicheraufteilung: Die urspr�ngliche Speicheraufteilung
// wurde so ge�ndert, da� sich alle Bytes einer Druckerspalte (also bis
// zu 3 bei einem 24-Nadler) linear hintereinander im Speicher befinden.
// Dadurch ergibt sich ein wesentlich schnellerer Ausdruck, da eine komplette
// Zeile mit Druckdaten am St�ck im Speicher steht.
//
// Die Berechnung f�r Adresse und Pixel erfolgt nach folgenden Formeln:
//
// Pixelmaske im Byte:
//
//      PixelMask = 0x01 << (7 - (X % 8));
//
// bzw. (bei Reverse)
//
//      PixelMask = 0x01 << (X % 8);
//
//
// Lineare Adresse des Bytes in dem das Pixel steht (Achtung: die Formel kann
// _nicht_ vereinfacht werden, d.h. es darf nichts weggek�rzt werden, da
// es sich um Ganzzahlarithmetik handelt).
//
//
// Abs =
//
//        X                                                        X % (8 * ColBytes)
// -------------- * MaxY * ColBytes + (MaxY - Y - 1) * ColBytes + --------------------
//  8 * ColBytes                                                           8
//
//



// Statische Variablen f�r absolute Adresse, Pixelmaske und Pixelshift
static BYTE PixelMask;
static BYTE PixelShift;
static DWORD Abs;

// Statische Variable die die Gr��e einer (Farb-) Bitplane bestimmt
// (nur wichtig f�r Farbmodi). Diese Variable wird von install gesetzt,
// da sie dort als Nebenprodukt der Berechnung des Speicherbedarfs anf�llt.
DWORD ColorPlaneSize;


/****************************************************************************/
/*                   Berechnung der Adresse und Pixelmaske                  */
/****************************************************************************/

static void near pascal CalcAdr (WORD X, WORD Y)
// L�dt ColorBits, PixelMask und Abs mit den korrekten Werten
// ACHTUNG: Funktioniert nur f�r g�ltige Werte von X/Y - vorher unbedingt
// Clip aufrufen
{
    // Berechnen der absoluten Adresse nach obiger Formel
    asm mov     bx, [DSTPtr]
    asm mov     cl, [bx]. (EpsonDST) ColBytes
    asm mov     ch, 0
    asm mov     bx, cx
    asm shl     bx, 1
    asm shl     bx, 1
    asm shl     bx, 1
    asm mov     ax, [X]
    asm sub     dx, dx          // X in dx:ax
    asm div     bx              // Ergebnis in ax, Rest in dx
    asm shr     dx, 1
    asm shr     dx, 1
    asm shr     dx, 1           // (X % (8 * ColorBits)) / 8
    asm mov     di, dx          // Gesamtergebnis in si:di
    asm mov     bx, ax          // X / (8 * ColorBits) in bx
    asm mov     ax, [MaxY]
    asm mul     cx              // ax = MaxY * ColorBits (16 Bit !)
    asm mul     bx              // * (X / (8 * ColorBits))
    asm mov     si, dx
    asm add     di, ax
    asm adc     si, 0
    asm mov     ax, [MaxY]
    asm sub     ax, [Y]
    asm dec     ax
    asm mul     cx
    asm add     ax, di
    asm adc     dx, si
L0: asm mov     word ptr [Abs], ax
    asm mov     word ptr [Abs+2], dx

    // Berechnen der Pixelmaske
    asm mov     ax, [X]
    asm mov     cx, 0107h
    asm and     al, cl
    asm mov     bx, [DSTPtr]
    asm test    byte ptr [bx]. (_DST) Flags, pfReverse
    asm jne     L1
    asm sub     cl, al
    asm db      0BBh                    // mov bx, Immed16
//  asm jmp     L2
L1: asm mov     cl, al
L2: asm shl     ch, cl
    asm mov     [PixelShift], cl
    asm mov     [PixelMask], ch

    // Ende
}



/****************************************************************************/
/*                            Zeichen-Prozeduren                            */
/****************************************************************************/


void pascal EpsonPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode)
// Eigene Funktion PutPixel die XORMode ber�cksichtigt
{

    register WORD Bits;

    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return;
    }

    // Berechnen der absoluten Adresse und der Pixelmaske.
    CalcAdr (X, Y);

    // Anzahl Farbbits holen
    Bits = DSTPtr->ColorBits;

    // Pixel setzen/l�schen
    switch (WriteMode) {

        case COPY_PUT:
            // F�r alle Farb-Bits
            while (Bits) {
                if (Color & 0x01) {
                    // Pixel setzen
                    *Map (Abs) |= PixelMask;
                } else {
                    // Pixel l�schen
                    *Map (Abs) &= ~PixelMask;
                }
                // Buffer ist ver�ndert
                Dirty = TRUE;
                // N�chstes Farb-Bit, n�chste Plane
                Bits--;
                Abs += ColorPlaneSize;
                Color >>= 1;
            }
            break;

        case XOR_PUT:
            // F�r alle Farb-Bits
            while (Bits) {
                if (Color & 0x01) {
                    *Map (Abs) ^= PixelMask;
                    // Buffer ist ver�ndert
                    Dirty = TRUE;
                }
                // N�chstes Farb-Bit, n�chste Plane
                Bits--;
                Abs += ColorPlaneSize;
                Color >>= 1;
            }
            break;

        case OR_PUT:
            // F�r alle Farb-Bits
            while (Bits) {
                if (Color & 0x01) {
                    *Map (Abs) |= PixelMask;
                    // Buffer ist ver�ndert
                    Dirty = TRUE;
                }
                // N�chstes Farb-Bit, n�chste Plane
                Bits--;
                Abs += ColorPlaneSize;
                Color >>= 1;
            }
            break;

        case AND_PUT:
            // F�r alle Farb-Bits
            while (Bits) {
                // AND-Operation, keine Wirkung wenn Farbe 1, L�schen wenn Farbe 0
                if ((Color & 0x01) == 0x00) {
                    *Map (Abs) &= ~PixelMask;
                    // Buffer ist ver�ndert
                    Dirty = TRUE;
                }
                // N�chstes Farb-Bit, n�chste Plane
                Bits--;
                Abs += ColorPlaneSize;
                Color >>= 1;
            }
            break;

        case NOT_PUT:
            // F�r alle Farb-Bits
            while (Bits) {
                if (Color & 0x01) {
                    // Pixel setzen
                    *Map (Abs) &= ~PixelMask;
                } else {
                    // Pixel l�schen
                    *Map (Abs) |= PixelMask;
                }
                // Buffer ist ver�ndert
                Dirty = TRUE;
                // N�chstes Farb-Bit, n�chste Plane
                Bits--;
                Abs += ColorPlaneSize;
                Color >>= 1;
            }
            break;

        default:
            break;
    }

}





BYTE pascal EpsonGetPixel (WORD X, WORD Y)
// Liefert die Farbe f�r den �bergebenen Punkt zur�ck
{
    register WORD Bits;
    BYTE Color;

    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return (0);
    }

    // Berechnen der absoluten Adresse und der Pixelmaske.
    CalcAdr (X, Y);

    // Anzahl Farbbits holen
    Bits = DSTPtr->ColorBits;

    // Farbe zusammensetzen
    Color = 0;
    while (Bits--) {
        if (*Map (Abs) & PixelMask) {
            Color |= 0x01 << Bits;
        }
        // N�chste Farbebene
        Abs += ColorPlaneSize;
    }

    // Farbe zur�ckgeben
    return Color;

}






/****************************************************************************/
/*                           Drucker-Ausgaberoutinen                        */
/****************************************************************************/



void pascal EpsonPrint ()
// Universelle Drucker-Routine f�r Nadeldrucker

{
    // Steuerstrings f�r EPSON/NEC P6 Farbe. Diese sind bisher fest eincodiert,
    // da die Drucker alle dieselben Steuerstrings haben.
    // ACHTUNG: Zwei der Bit-Ebenen sind vertauscht um eine dem DeskJet
    // �hnliche Farb-Verteilung zu erhalten.
    // Alle Steuerstrings enthalten zus�tzlich zuerst einen Wagenr�cklauf.
    static char *ColorSel [4] = {
        "\x04\r\x1Br\x02",              // Bit 0 = Cyan
        "\x04\r\x1Br\x01",              // Bit 1 = Magenta
        "\x04\r\x1Br\x04",              // Bit 2 = Gelb
        "\x04\r\x1Br\x00"               // Bit 3 = Schwarz
    };

    WORD X, Y, EndX;
    BYTE Bytes, Pass, PassCount, ColBytes, ColorBits, Bits;
    DWORD Abs, A;
    BYTE Buf [6];         // Maximale Gr��e: ColBytes(max) * PassCount(max)
    BYTE PrintBuf [3];    // Maximale Gr��e: ColBytes(max)
    BYTE OrVal;           // Alle Bytes einer Spalte zusammengeodert.

    // Handle auf "raw data" umstellen. Direkt Ende wenn Handle nicht Ok
    BYTE _ss *OutputBuf = alloca (PrintBufSize);
    if (InitPrinter (OutputBuf, PRNHandle) == FALSE) {
        return;
    }

    // Vor Beginn der Druck-Ausgabe jetzt das Sprunglabel f�r Druckerfehler
    // setzen.
    if (SetJump (PrintAbortLabel) != 0) {
        // Fehler!
        return;
    }

    // "Vor"-String ausgeben
    PrintString (((EpsonDST *) DSTPtr)->GraphicsOn);

    // Variablen-Init
    Abs          = 0L;
    PassCount    = ((EpsonDST *) DSTPtr)->PassCount;
    ColBytes     = ((EpsonDST *) DSTPtr)->ColBytes;
    ColorBits    = DSTPtr->ColorBits;
    Bytes        = ColBytes * PassCount;
    EndX         = MaxX / (ColBytes * 8);

    X = 0;
    while (X < EndX) {

        for (Pass = 0; Pass < PassCount; Pass++) {

            for (Bits = 0; Bits < ColorBits; Bits++) {

                // Falls mehr als eine Farbe existiert, jetzt Farbe umschalten
                if (ColorBits > 1) {
                    PrintString (ColorSel [Bits]);
                }

                // Grafik einleiten
                PrintString (((EpsonDST *) DSTPtr)->PreBytes);

                for (Y = 0; Y < MaxY; Y++) {

                    //
                    // Passende Zahl Bytes aus dem Puffer holen
                    //
                    // Urspr�ngliche C-Quelle:
                    //
                    //  // Passende Anzahl Bytes aus dem Puffer holen
                    //  I = 0;
                    //  A = Abs + Y * ColBytes;
                    //  for (J = 0; J < PassCount; J++) {
                    //      for (K = 0; K < ColBytes; K++) {
                    //          Buf [I] = *Map (A++);
                    //          OrVal |= Buf [I];
                    //          I++;
                    //      }
                    //      A += (MaxY - 1) * ColBytes;
                    //  }
                    //
                    // Direkt beim Holen aller notwendigen Bytes werden die Werte
                    // miteinander verodert und gemerkt. Ist der resultierende
                    // Wert 0, dann sind alle daraus resultierenden Ausgabewerte
                    // auch 0. Die Schleife weiter unten kann also enorm verk�rzt
                    // werden.

                    OrVal = 0;

                    asm     lea     si, Buf
                    asm     mov     cl, [ColBytes]
                    asm     mov     ch, 0
                    asm     mov     ax, [MaxY]
                    asm     dec     ax
                    asm     mul     cx
                    asm     mov     di, ax          // di = (MaxY - 1) * ColBytes
                    asm     mov     ax, cx
                    asm     mul     [Y]
                    asm     add     ax, word ptr [Abs]
                    asm     adc     dx, word ptr [Abs+2]
                    asm     mov     word ptr [A], ax
                    asm     mov     word ptr [A+2], dx
                    asm     mov     ch, [PassCount]
L0:                 asm     mov     cl, [ColBytes]
L3:                 asm     push    cx
                    (void)  Map (A);
                    asm     pop     cx
                    asm     mov     es, dx
                    asm     mov     bx, ax
                    asm     add     word ptr [A], 1
                    asm     adc     word ptr [A+2], 0
                    asm     mov     al, byte ptr es:[bx]
                    asm     or      [OrVal], al
                    asm     mov     byte ptr ss:[si], al
                    asm     inc     si
                    asm     dec     cl
                    asm     jnz     L3
                    asm     add     word ptr [A], di
                    asm     adc     word ptr [A+2], 0
                    asm     dec     ch
                    asm     jnz     L0

                    // Falls OrVal 0 ist, dann einfach 0-Bytes ausgeben,
                    // ansonsten die Bytes aus dem Puffer zusammensetzen.
                    if (OrVal == 0) {
                        // Vereinfachte Version
                        asm     mov     al, [ColBytes]
                        asm     mov     ah, 0
                        asm     xchg    di, ax              // ColBytes nach di
L5:                     PrintByte (0);
                        asm     dec     di
                        asm     jnz     L5

                        // Und direkt weiter
                        continue;
                    }

                    // Falls PassCount == 1 ist, dann ist keine Verschachtelung
                    // der Bits notwendig, der Puffer kann direkt ausgegeben
                    // werden
                    if (PassCount == 1) {
                        PrintData (Buf, ColBytes);

                        // Und direkt weiter
                        continue;
                    }

                    // Bytes m�ssen einzeln zusammengesetzt und ausgegeben werden.
                    //
                    // Registerbelegung f�r die folgende Schleife:
                    //
                    //   bl   = Ausgabebyte
                    //   bh   = Bytez�hler (z�hlt die ColBytes)
                    //   cl   = Shift f�r Pixelposition
                    //   ch   = Bitz�hler
                    //   dx   = I
                    //
                    //   di   = Zeiger auf PrintBuf
                    //
                    // Initialisierung f�r die folgende Schleife durchf�hren
                    //

                    asm     mov     cl, [Pass]
                    asm     mov     ch, 0
                    asm     mov     dx, cx                  // I = Pass;
                    asm     neg     cx
                    asm     add     cl, 7                   // cl = Shift = 7 - Pass;

                    asm     lea     di, PrintBuf            // Adresse des Ausgabepuffers
                    asm     mov     bh, [ColBytes]          // Byte-Z�hler

                    //
                    // Ein Byte zusammenstellen und ausgeben. Der Z�hler f�r die 8 Bits
                    // steht dabei in ch, in bl wird das Ausgabe-Byte zusammengestellt.
                    //
L1:                 asm     mov     ch, 8                   // Schleife f�r 8 Bits
L2:                 asm     mov     si, dx
                    asm     shr     si, 1
                    asm     shr     si, 1
                    asm     shr     si, 1                   // (I / 8) in si
                    asm     mov     al, Byte PTR [Buf+si]
                    asm     shr     al, cl
                    asm     shr     al, 1
                    asm     rcl     bl, 1                   // Ausgabebyte steht in bl
                    asm     mov     al, [PassCount]
                    asm     sub     cl, al
                    asm     and     cl, 7                   // Shift = (Shift - PassCount) & 0x07
                    asm     mov     ah, 0
                    asm     add     dx, ax
                    asm     dec     ch                      // N�chstes Bit
                    asm     jnz     L2

                    // Das Byte in bl speichern

                    asm     mov     Byte Ptr ss:[di], bl
                    asm     inc     di

                    // Und n�chstes Byte

                    asm     dec     bh
                    asm     jnz     L1

                    //
                    // Die Bytes im Puffer jetzt ausgeben
                    //
                    PrintData (PrintBuf, ColBytes);

                }

                PrintString (((EpsonDST *) DSTPtr)->PostBytes);

                // N�chste Farbebene
                Abs += ColorPlaneSize;

            }

            if (Pass == (PassCount - 1)) {
                PrintString (((EpsonDST *) DSTPtr)->LineFeed1);
            } else {
                PrintString (((EpsonDST *) DSTPtr)->LineFeed2);
            }

            // Absolute Adresse r�cksetzen, n�chste Zeile
            Abs -= ColorBits * ColorPlaneSize;
            X++;

        }

        // Neue absolute Adresse rechnen
        Abs += LongMul (Bytes, MaxY);

    }

    // Ende-String auf den Drucker ausgeben
    PrintString (((EpsonDST *) DSTPtr)->GraphicsOff);

    // Grafik beenden, Puffer leeren
    Flush ();
    ResetPrinter ();

}







//
//  BGI-Treiber f�r HPDJ500C
//
//  Ullrich von Bassewitz am 08.09.1991
//
//
//


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: hpdj500c.cpp 2.3 1993/08/01 20:53:03 Uz Rel $
//
// $Log: hpdj500c.cpp $
// Revision 2.3  1993/08/01 20:53:03  Uz
// Neues Format mit DPMI-Support
//
//
//



#include    <dir.h>
#include    <string.h>
#include    "const.h"
#include    "util.h"
#include    "heap.h"
#include    "file.h"
#include    "memory.h"
#include    "print.h"
#include    "lj.h"
#include    "bgifunc.h"






/****************************************************************************/
/*                                 Prototypen                               */
/****************************************************************************/

// Druck-Routinen

void pascal EpsonPrint ();
void pascal LaserPrint ();


// PutPixel/GetPixel-Routinen

void pascal EpsonPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode);
BYTE pascal EpsonGetPixel (WORD X, WORD Y);



//
// Hier stehen alle Funktionen deren Namen nicht "gemangelt" werden sollen,
// weil sie im Assembler-Teil verwendet werden.
//

extern "C" {

  void cdecl install    ();
  void cdecl allpalette ();

}






/****************************************************************************/
/*                         Statische Daten des Treibers                     */
/****************************************************************************/


// Die Farbtabelle wird (da nicht verwendet) als M�glichkeit zur Einstellung
// von diversen Daten von au�en benutzt. Sie hei�t daher nicht ColorTable
// (wie im SVGA-Treiber), sondern Settings (f�r die aktuelle Tabelle) und
// DefaultSettings (f�r die Default-Einstellungen).

BYTE DefaultSettings [9] = {
    8,                             // Anzahl folgender Bytes
    0,                             // Reserved
    0,                             // Output quality, 0 --> keypad setting
                                   //                 1 --> draft
                                   //                 2 --> high
    0,                             // Shingling,      0 --> normal
                                   //                 1 --> 25% (2 pass)
                                   //                 2 --> 50% (4 pass)
    1,                             // Depletion       0 --> none
                                   //                 1 --> 25%
                                   //                 2 --> 50%
    0, 0, 0, 0                     // Reserved
};



// Die folgenden Farbtabelle wird als Einstellungstabelle "mi�braucht"
BYTE Settings [9] = {
    8,                             // Anzahl folgender Bytes
    0,                             // Reserved
    0,                             // Output quality, 0 --> keypad setting
                                   //                 1 --> draft
                                   //                 2 --> high
    0,                             // Shingling,      0 --> normal
                                   //                 1 --> 25% (2 pass)
                                   //                 2 --> 50% (4 pass)
    1,                             // Depletion       0 --> none
                                   //                 1 --> 25%
                                   //                 2 --> 50%
    0, 0, 0, 0                     // Reserved
};


// Defines zum Zugriff auf die Elemente von Settings und DefaultSettings
#define   djDefQuality      (DefaultSettings [2])
#define   djDefShingling    (DefaultSettings [3])
#define   djDefDepletion    (DefaultSettings [4])
#define   djQuality         (Settings [2])
#define   djShingling       (Settings [3])
#define   djDepletion       (Settings [4])


/****************************************************************************/
/*                                                                          */
/*    Die folgende Struktur enth�lt einen Device-Status-Block. Die ersten   */
/*  Werte m�ssen immer dieselben sein, da sie vom Grafik-Modul so erwartet  */
/*  werden. Im Anschlu� kommen eigene Variablen, die von Drucker zu Drucker */
/*        bzw. besser von Treiber zu Treiber verschieden sein k�nnen.       */
/*                                                                          */
/****************************************************************************/


struct EpsonDST {

  _DST            DST;              // Orginal-DST

  BYTE            ColBytes;         // Anzahl Bytes / Druckerspalte
  BYTE            PassCount;        // Wie oft �berdrucken

  BYTE            Reverse;          // Nadel-Nummerierung umdrehen
  BYTE            Fill;             // Unbenutzt

  char            *LineFeed1;       // Normaler Linefeed
  char            *LineFeed2;       // Linefeed zwischen �berdrucken

  char            *GraphicsOn;      // Grafik einschalten (mit Init)
  char            *GraphicsOff;     // Grafik ausschalten

  char            *PreBytes;        // String vor Grafik-Daten
  char            *PostBytes;       // String nach Grafik-Daten

};



/****************************************************************************/
/*          Defintionen f�r die verschiedenen Druck-Modi des Treibers       */
/****************************************************************************/


// 8-Nadel Modus 240 * 72 DPI
EpsonDST EPSON240x72 = {

  // DPI in X-und Y-Richtung
  72, 240,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x10""EPSON 240x72 DPI",       // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  1, 1,

  // Nadel-Numerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x04\x1B\x4A\x18\r",           // ESC 'J' 24 cr

  // LineFeed2, d.h. kleinster Linefeed
  NULL,                           // Nicht vorhanden

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x03\x80\x07",     // ESC '*' 03 1920

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden

};



// 8-Nadel Modus 240 * 216 DPI
EpsonDST EPSON240x216 = {

  // DPI in X-und Y-Richtung
  216, 240,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x11""EPSON 240x216 DPI",      // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  1, 3,

  // Nadel-Nummerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x04\x1B\x4A\x16\r",           // ESC 'J' 22 cr

  // LineFeed2, d.h. kleinster Linefeed
  "\x04\x1B\x4A\x01\r",           // ESC 'J' 1 cr

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x03\x80\x07",     // ESC '*' 03 1920

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden

};



// 24-Nadel Modus 180 * 180 DPI
EpsonDST EPSON180x180 = {

  // DPI in X-und Y-Richtung
  180, 180,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x11""EPSON 180x180 DPI",      // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  3, 1,

  // Nadel-Numerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x04\x1B\x4A\x18\r",           // ESC 'J' 24 cr

  // LineFeed2, d.h. kleinster Linefeed
  NULL,                           // Nicht vorhanden

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x27\xA0\x05",     // ESC '*' 39 1440

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden

};



// 24-Nadel Modus 360 * 180 DPI
EpsonDST EPSON360x180 = {

  // DPI in X-und Y-Richtung
  180, 360,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x11""EPSON 360x180 DPI",      // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  3, 1,

  // Nadel-Numerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x04\x1B\x4A\x18\r",           // ESC 'J' 24 cr

  // LineFeed2, d.h. kleinster Linefeed
  NULL,                           // Nicht vorhanden

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x28\x40\x0B",     // ESC '*' 40 2880

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden
};



// 24-Nadel Modus 360 * 360 DPI, EPSON
EpsonDST EPSON360x360 = {

  // DPI in X-und Y-Richtung
  360, 360,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x11""EPSON 360x360 DPI",      // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  3, 2,

  // Nadel-Numerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x05\x1B\x2B\x2F\x0D\x0A",     // ESC '+' 47 cr lf

  // LineFeed2, d.h. kleinster Linefeed
  "\x05\x1B\x2B\x01\x0D\x0A",     // ESC '+' 01 cr lf

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x28\x40\x0B",     // ESC '*' 40 2880

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden
};



// 24-Nadel Modus 360 * 360 DPI, NEC P6
EpsonDST NEC360x360 = {

  // DPI in X-und Y-Richtung
  360, 360,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  11000, 8000,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Epson-Modus
  TRUE,

  // Name des Modus
  "\x12""NEC P6 360x360 DPI",     // Name des Modus

  // Druckeroutine
  EpsonPrint,

  // Put- und GetPixel
  EpsonPutPixel,
  EpsonGetPixel,

  // Bytes pro Druckerspalte und Durchg�nge
  3, 2,

  // Nadel-Numerierung und F�llbyte
  FALSE, 0,

  // Linefeed1, d.h. normaler Linefeed
  "\x05\x1C\x33\x2F\x0D\x0A",     // FS '3' 47 cr lf

  // LineFeed2, d.h. kleinster Linefeed
  "\x05\x1C\x33\x01\x0D\x0A",     // FS '3' 01 cr lf

  // Einschalten der Grafik
  "\x05\x1B\x40\x1B\x4F\r",          // ESC '@' ESC 'O' \r

  // Ausschalten der Grafik
  "\x03\f\x1B\x40",               // \f ESC '@'

  // Code vor den Grafik-Bytes
  "\x05\x1B\x2A\x28\x40\x0B",     // ESC '*' 40 2880

  // Code nach den Grafik-Bytes
  NULL                            // Nicht vorhanden
};



// HP-Laserdrucker 75*75 DPI
LJDST HPLJ75 = {

  // DPI in X-und Y-Richtung
  75, 75,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x0E""HPLJ 75x75 DPI",         // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  TRUE, 0,

  // Festlegen der Grafik
  "\x1B*t75R"                     // ESC * t 75 R

};



// HP-Laserdrucker 100*100 DPI
LJDST HPLJ100 = {

  // DPI in X-und Y-Richtung
  100, 100,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 100x100 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  TRUE, 0,

  // Festlegen der Grafik
  "\x1B*t100R"                    // ESC * t 100 R

};



// HP-Laserdrucker 150*150 DPI
LJDST HPLJ150 = {

  // DPI in X-und Y-Richtung
  150, 150,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 150x150 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  TRUE, 0,

  // Festlegen der Grafik
  "\x1B*t150R"                    // ESC * t 150 R

};



// HP-Laserdrucker 300*300 DPI
LJDST HPLJ300 = {

  // DPI in X-und Y-Richtung
  300, 300,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 300x300 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  TRUE, 0,

  // Festlegen der Grafik
  "\x1B*t300R"                    // ESC * t 300 R

};



// HP-Laserdrucker 75*75 DPI ohne Kompression
LJDST HPLJ75O = {

  // DPI in X-und Y-Richtung
  75, 75,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x0E""HPLJ 75x75 DPI",         // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  FALSE, 0,

  // Festlegen der Grafik
  "\x1B*t75R"                     // ESC * t 75 R

};



// HP-Laserdrucker 100*100 DPI ohne Kompression
LJDST HPLJ100O = {

  // DPI in X-und Y-Richtung
  100, 100,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 100x100 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  FALSE, 0,

  // Festlegen der Grafik
  "\x1B*t100R"                    // ESC * t 100 R

};



// HP-Laserdrucker 150*150 DPI ohne Kompression
LJDST HPLJ150O = {

  // DPI in X-und Y-Richtung
  150, 150,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 150x150 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  FALSE, 0,

  // Festlegen der Grafik
  "\x1B*t150R"                    // ESC * t 150 R

};



// HP-Laserdrucker 300*300 DPI ohne Kompression
LJDST HPLJ300O = {

  // DPI in X-und Y-Richtung
  300, 300,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 300x300 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  FALSE, 0,

  // Festlegen der Grafik
  "\x1B*t300R"                    // ESC * t 300 R

};



// HP-Laserdrucker 600*600 DPI
LJDST HPLJ600 = {

  // DPI in X-und Y-Richtung
  600, 600,

  // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
  10334, 7800,

  // Anzahl Farben und Bits pro Pixel
  2, 1,

  // Kein Epson-Modus
  FALSE,

  // Name des Modus
  "\x10""HPLJ 600x600 DPI",       // Name des Modus

  // Druckeroutine
  LaserPrint,

  // Put- und GetPixel
  LJPutPixel,
  LJGetPixel,

  // Kompression Ja/Nein und ein F�llbyte
  TRUE, 0,

  // Festlegen der Grafik
  "\x1B*t600R"                    // ESC * t 300 R

};



// 75*75 DPI HP-DJ, Farbe
LJDST HPDJ75 = {

    // DPI in X-und Y-Richtung
    75, 75,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    10334, 7800,

    // Anzahl Farben und Bits pro Pixel
    8, 3,

    // Kein Epson-Modus
    FALSE,

    // Name des Modus
    "\x0F""HPDJ500C 75 DPI",        // Name des Modus

    // Druckeroutine
    LaserPrint,

    // Put- und GetPixel
    LJPutPixel,
    LJGetPixel,

    // Kompression Ja/Nein und ein F�llbyte
    TRUE, 0,

    // Einschalten der Grafik
    "\x1B*t75R"                     // ESC * t 75 R

};


// 100*100 DPI HP-DJ, Farbe
LJDST HPDJ100 = {

    // DPI in X-und Y-Richtung
    100, 100,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    10334, 7800,

    // Anzahl Farben und Bits pro Pixel
    8, 3,

    // Kein Epson-Modus
    FALSE,

    // Name des Modus
    "\x10""HPDJ500C 100 DPI",       // Name des Modus

    /* Druckeroutine */
    LaserPrint,

    // Put- und GetPixel
    LJPutPixel,
    LJGetPixel,

    // Kompression Ja/Nein und ein F�llbyte
    TRUE, 0,

    // Einschalten der Grafik
    "\x1B*t100R"                    // ESC * t 100 R

};


// 150*150 DPI HP-DJ, Farbe
LJDST HPDJ150 = {

    // DPI in X-und Y-Richtung
    150, 150,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    10334, 7800,

    // Anzahl Farben und Bits pro Pixel
    8, 3,

    // Kein Epson-Modus
    FALSE,

    // Name des Modus
    "\x10""HPDJ500C 150 DPI",       // Name des Modus

    /* Druckeroutine */
    LaserPrint,

    // Put- und GetPixel
    LJPutPixel,
    LJGetPixel,

    // Kompression Ja/Nein und ein F�llbyte
    TRUE, 0,

    // Einschalten der Grafik
    "\x1B*t150R"                    // ESC * t 150 R

};


// 300*300 DPI HP-DJ, Farbe
LJDST HPDJ300 = {

    // DPI in X-und Y-Richtung
    300, 300,

    // Blattgr��e in X- und Y-Richtung in 1/1000 Inch
    10334, 7800,

    // Anzahl Farben und Bits pro Pixel
    8, 3,

    // Kein Epson-Modus
    FALSE,

    // Name des Modus
    "\x10""HPDJ500C 300 DPI",       // Name des Modus

    /* Druckeroutine */
    LaserPrint,

    // Put- und GetPixel
    LJPutPixel,
    LJGetPixel,

    // Kompression Ja/Nein und ein F�llbyte
    TRUE, 0,

    // Einschalten der Grafik
    "\x1B*t300R"                    // ESC * t 300 R

};







// Hier m�ssen die Anzahl der Modi eingetragen werden
#define                 MaxModes    4


// Das Array Zeigern auf die DST's
_DST near *DSTTable [MaxModes] = {

  (_DST *) &HPDJ75,
  (_DST *) &HPDJ100,
  (_DST *) &HPDJ150,
  (_DST *) &HPDJ300

};


/* Der Zeiger auf die aktuelle DST */
_DST   near *   DSTPtr = (_DST *) &HPDJ75;




/****************************************************************************/
/*                            Zeichen-Prozeduren                            */
/****************************************************************************/


void pascal EpsonPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode)
// Eigene Funktion PutPixel die XORMode ber�cksichtigt

{

    BYTE far *BytePtr;
    BYTE PixelMask;


    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return;
    }

    // Pixel-Adresse berechnen
    // Seite einblenden und Zeiger holen.
    //
    // Alter Code (aus Calc_Adr):
    // BytePtr = Map ( LongMul ((X / 8), MaxY) + (DWORD) (MaxY - Y - 1));
    asm     mov     cl, 3
    asm     mov     ax, WORD PTR [X]
    asm     shr     ax, cl
    asm     mov     bx, WORD PTR [MaxY]
    asm     mul     bx
    asm     sub     bx, WORD PTR [Y]
    asm     dec     bx
    asm     add     ax, bx
    asm     adc     dx, 0
    BytePtr = Map (MK_DWORD (_DX, _AX));

    // Bitmaske f�r Pixel erstellen und nach al
    //
    // Alter Code (aus Calc_Adr):
    // PixelMask = 0x01 << (7 - (X % 8));
    asm     mov     ax, WORD PTR [X]
    asm     mov     cx, 7
    asm     and     ax, cx
    asm     sub     cx, ax
    asm     mov     al, 01
    asm     shl     al, cl
    asm     mov     Byte PTR [PixelMask], al


    /* Pixel setzen/l�schen */
    switch (WriteMode) {

        case COPY_PUT:
            if (Color & 0x01) {
                /* Pixel setzen */
                *BytePtr |= PixelMask;
            } else {
                /* L�schen */
                *BytePtr &= ~PixelMask;
            }
            break;

        case XOR_PUT:
            /* XOR ist angesagt */
            if (Color & 0x01) {
                /* Nur wenn Farbe = 1, sonst ist XOR wirkungslos */
                *BytePtr ^= PixelMask;
            }
            break;

        case OR_PUT:
            /* OR-Operation, nur wirksam wenn Farbe */
            if (Color & 0x01) {
                *BytePtr |= PixelMask;
            }
            break;

        case AND_PUT:
            /* AND-Operation, keine Wirkung wenn Farbe 1, L�schen wenn Farbe 0 */
            if ((Color & 0x01) == 0) {
                *BytePtr &= ~PixelMask;
            }
            break;

        case NOT_PUT:
            /* Farbe invertieren */
            if (Color & 0x01)
                /* L�schen */
                *BytePtr &= ~PixelMask;
            else
                /* Pixel setzen */
                *BytePtr |= PixelMask;
            break;

        default:
            break;
    }

    /* Puffer als Dirty markieren */
    Dirty = TRUE;
}





#pragma warn -rvl
BYTE pascal EpsonGetPixel (WORD X, WORD Y)
/* Liefert die Farbe f�r den �bergebenen Punkt zur�ck */
{
    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return (0);
    }

    // Seite einblenden und Zeiger holen
    // BytePtr = Map ( LongMul ((X / 8), MaxY) + (DWORD) (MaxY - Y - 1));
    asm     mov     cl, 3
    asm     mov     ax, WORD PTR [X]
    asm     shr     ax, cl
    asm     mov     bx, WORD PTR [MaxY]
    asm     mul     bx
    asm     sub     bx, WORD PTR [Y]
    asm     dec     bx
    asm     add     ax, bx
    asm     adc     dx, 0

    (void) Map (MK_DWORD (_DX, _AX));       // Ergebnis nach dx:ax

    // Pixel holen
    asm     mov     di, ax
    asm     mov     es, dx                 // Byte-Zeiger nach es:di

    asm     mov     ax, WORD PTR [X]
    asm     mov     cx, 7
    asm     and     ax, cx
    asm     sub     cx, ax
    asm     mov     al, Byte PTR [es:di]
    asm     shr     al, cl
    asm     and     al, 1
}
#pragma warn +rvl






/****************************************************************************/
/*                           Drucker-Ausgaberoutinen                        */
/****************************************************************************/



void pascal EpsonPrint (void)
// Universelle Drucker-Routine f�r Nadeldrucker

{
    WORD X, Y, I, EndX;
    BYTE Bytes, Pass, PassCount, ColBytes, Reverse;
    DWORD Abs;
    BYTE Buf [6];         // Maximale Gr��e: ColBytes(max) * PassCount(max)
    BYTE PrintBuf [3];    // Maximale Gr��e: ColBytes(max)
    BYTE OrVal;           // Alle Bytes einer Spalte zusammengeodert.

    // Handle auf "raw data" umstellen. Direkt Ende wenn Handle nicht Ok
    if (!InitPrinterHandle ())
      return;

    // "Vor"-String ausgeben
    if (!PrintString (((EpsonDST *) DSTPtr)->GraphicsOn))
      /* Druckerfehler/nicht bereit */
      return;

    // Variablen-Init
    Abs          = 0L;
    PassCount    = ((EpsonDST *) DSTPtr)->PassCount;
    ColBytes     = ((EpsonDST *) DSTPtr)->ColBytes;
    Reverse      = ((EpsonDST *) DSTPtr)->Reverse;
    Bytes        = ColBytes * PassCount;
    EndX         = MaxX / (ColBytes * 8);

    X = 0;
    while (X < EndX) {

        for (Pass = 0; Pass < PassCount; Pass++) {

            if (!PrintString (((EpsonDST *) DSTPtr)->PreBytes)) {
                // Drucker nicht bereit
                return;
            }

            for (Y = 0; Y < MaxY; Y++) {

                //
                // Passende Zahl Bytes aus dem Puffer holen
                //
                // Urspr�ngliche C-Quelle:
                //
                //   /* Passende Anzahl Bytes aus dem Puffer holen */
                //   for (I = 0; I < Bytes; I++) {
                //     Buf [I]  = *Map (Abs + (DWORD) Y + LongMul (I, MaxY));
                //   }
                //
                // Direkt beim holen aller notwendigen Bytes werden die Werte
                // miteinander verodert und gemerkt. Ist der resultierende
                // Wert 0, dann sind alle daraus resultierenden Ausgabewerte
                // auch 0. Die Schleife weiter unten kann also enorm verk�rzt
                // werden.

                OrVal = 0;

                asm     lea     si, Buf
                asm     xor     bx, bx                      // I
        L0:     asm     mov     ax, [MaxY]
                asm     mul     bx                          // (I * MaxY)
                asm     add     ax, [Y]
                asm     adc     dx, 0
                asm     add     ax, Word Ptr [Abs]
                asm     adc     dx, Word Ptr [Abs+2]
                asm     push    bx
                (void) Map (MK_DWORD (_DX, _AX));           // C-Aufruf wegen Mangling
                asm     pop     bx
                asm     mov     es, dx
                asm     mov     di, ax
                asm     mov     al, Byte Ptr [es:di]
                asm     mov     Byte Ptr ss:[si+bx], al
                asm     or      [OrVal], al                 // Alle Bytes verodern
                asm     inc     bx
                asm     cmp     bl, [Bytes]
                asm     jb      L0

                // Falls OrVal 0 ist, dann einfach 0-Bytes ausgeben,
                // ansonsten die Bytes aus dem Puffer zusammensetzen.
                if (OrVal == 0) {
                    // Vereinfachte Version
                    asm     mov     al, [ColBytes]
                    asm     mov     ah, 0
                    asm     xchg    di, ax              // ColBytes nach ax
L5:                 asm     xor     ax, ax              // ax = 0
                    if (!PrintByte (_AL)) {
                        return;
                    }
                    asm     dec     di
                    asm     jnz     L5

                    // Und direkt weiter
                    continue;
                }

                // Bytes m�ssen einzeln zusammengesetzt und ausgegeben werden.
                //
                // Registerbelegung f�r die folgende Schleife:
                //
                //   bl   = Ausgabebyte
                //   bh   = Bytez�hler (z�hlt die ColBytes)
                //   cl   = Shift f�r Pixelposition
                //   ch   = Bitz�hler
                //   dx   = I
                //
                //   di   = Zeiger auf PrintBuf
                //
                // Initialisierung f�r die folgende Schleife durchf�hren
                //

                asm     mov     cl, [Pass]
                asm     mov     ch, 0
                asm     mov     dx, cx                   // I = Pass;
                asm     neg     cx
                asm     add     cl, 7                   // cl = Shift = 7 - Pass;

                asm     lea     di, PrintBuf            // Adresse des Ausgabepuffers
                asm     mov     bh, [ColBytes]          // Byte-Z�hler

                //
                // Ein Byte zusammenstellen und ausgeben. Der Z�hler f�r die 8 Bits
                // steht dabei in ch, in bl wird das Ausgabe-Byte zusammengestellt.
                // Es gibt zwei Schleifen, die sich nur darin unterscheiden, wie die
                // Bits in bl zusammengestellt werden, dies wird je nach Reverse
                // unterschieden.
                //
L1:             asm     mov     ch, 8                   // Schleife f�r 8 Bits
                asm     cmp     [Reverse], FALSE
                asm     jnz     L3

                // Schleife f�r Reverse = FALSE, oberste Nadel nach Bit 7

L2:             asm     mov     si, dx
                asm     shr     si, 1
                asm     shr     si, 1
                asm     shr     si, 1                   // (I / 8) in si
                asm     mov     al, Byte PTR [Buf+si]
                asm     shr     al, cl
                asm     shr     al, 1
                asm     rcl     bl, 1                   // Ausgabebyte steht in bl
                asm     mov     al, [PassCount]
                asm     sub     cl, al
                asm     and     cl, 7                   // Shift = (Shift - PassCount) & 0x07
                asm     mov     ah, 0
                asm     add     dx, ax
                asm     dec     ch                      // N�chstes Bit
                asm     jnz     L2
                asm     jmp     L4                      // Byte speichern und weiter

                // Schleife f�r Reverse = TRUE, oberste Nadel nach Bit 0

L3:             asm     mov     si, dx
                asm     shr     si, 1
                asm     shr     si, 1
                asm     shr     si, 1                   // (I / 8) in si
                asm     mov     al, Byte PTR [Buf+si]
                asm     shr     al, cl
                asm     shr     al, 1
                asm     rcr     bl, 1                   // Ausgabebyte steht in bl
                asm     mov     al, [PassCount]
                asm     sub     cl, al
                asm     and     cl, 7                   // Shift = (Shift - PassCount) & 0x07
                asm     mov     ah, 0
                asm     add     dx, ax
                asm     dec     ch                      // N�chstes Bit
                asm     jnz     L3

                // Das Byte in bl speichern

L4:             asm     mov     Byte Ptr ss:[di], bl
                asm     inc     di

                // Und n�chstes Byte

                asm     dec     bh
                asm     jnz     L1

                //
                // Die Bytes im Puffer jetzt ausgeben
                //
                for (I = 0; I < ColBytes; I++) {
                    if (!PrintByte (PrintBuf [I])) {
                        // Drucker nicht bereit
                        return;
                    }
                }

            }
            X++;

            if (!PrintString (((EpsonDST *) DSTPtr)->PostBytes)) {
                // Drucker nicht bereit
                return;
            }
            if (Pass == (PassCount - 1)) {
                if (!PrintString (((EpsonDST *) DSTPtr)->LineFeed1)) {
                    // Drucker nicht bereit
                    return;
                }
            } else {
                if (!PrintString (((EpsonDST *) DSTPtr)->LineFeed2)) {
                    // Drucker nicht bereit
                    return;
                }
            }
        }
        Abs += LongMul (Bytes, MaxY);
    }
    if (!PrintString (((EpsonDST *) DSTPtr)->GraphicsOff))
      // Drucker nicht bereit
      return;

    // Grafik beenden, Puffer leeren
    Flush ();
    ResetPrinterHandle ();

}






void pascal LaserPrint ()
// Ausgaberoutine f�r LaserJet/DeskJet
{

    // Zeiger auf Zeilenpuffer f�r die Ausgabe
    BYTE *CompBuf;

    // Drucker-Kontrollstrings
    static char InitString [] =
      "\x1B""E"                         // Reset Printer
      "\x1B*rbC"                        // End Raster Graphics
      "\x1B&l26A"                       // Format: DIN A4
      "\x1B&l0o0L";                     // Portrait orientation, perf.-skip off

    static char ColorString [] =
      "\x1B*r-3U";                      // 3 planes, CMY palette


    static char *Quality [3] = {
      "\x1B*r0Q",                       // Use keypad setting
      "\x1B*r1Q",                       // draft
      "\x1B*r2Q"                        // high
    };

    static char *Shingling [3] = {
      "\x1B*o0Q",                       // None
      "\x1B*o1Q",                       // 25% (2 pass)
      "\x1B*o2Q"                        // 50% (4 pass)
    };

    static char *Depletion [3] = {
      "\x1B*o1D",                       // None
      "\x1B*o2D",                       // 25% (default)
      "\x1B*o3D"                        // 50%
    };

    static char StartGraphics [] =
      "\x1B*r0A";                       // Start graphics


    // ---------------------------------------------------------------

    // Belegen eines Speicherbereiches passender Gr��e
    CompBuf = GetDynMem (600);

    // Zusammenbauen des Initialisierungsstrings in CompBuf. Da als erstes
    // Byte f�r die Ausgabe die L�nge stehen mu�, wird der String ab
    // CompBuf [1] zusammengebaut und die L�nge sp�ter nach CompBuf [0]
    // geschrieben.

    strcpy (&CompBuf [1], InitString);
    if (DSTPtr->ColorCount == 8) {
        /* DeskJet Farbe */
        strcat (&CompBuf [1], ColorString);
    }
    strcat (&CompBuf [1], ((LJDST *) DSTPtr)->GraphicsOn);
    strcat (&CompBuf [1], Quality [djQuality]);
    if (DSTPtr->ColorCount == 8) {
        /* DeskJet Farbe */
        strcat (&CompBuf [1], Shingling [djShingling]);
        strcat (&CompBuf [1], Depletion [djDepletion]);
    }
    strcat (&CompBuf [1], StartGraphics);
    CompBuf [0] = strlen (&CompBuf [1]);

    // Und die eigentliche Druck-Routine aufrufen
    LJPrint (CompBuf);

    // Speicher wieder freigeben
    FreeDynMem (600);

}






/****************************************************************************
 *               Laden der benutzerdefinierten Drucker-Daten                *
 ****************************************************************************/

void pascal SearchBGIPath (char *EXEPath, char *BGIPath)
/* Durchsucht das Environment nach dem Eintrag "BGIPATH=" und bildet (falls
 * gefunden) aus dem dort stehenden String und dem �bergebenen Filenamen
 * einen kompletten Pfad der in BGIPath gespeichert wird. Falls eine DOS-
 * Version nach 3.0 vorliegt, wird au�erdem in EXEPath der komplette Pfad
 * der EXE-Datei zur�ckgeliefert.
 */

{
    BYTE DosVersion;                        // DOS-Version
    WORD PSPSeg;                            // PSP des Hauptprogramms
    static char PathCode[] = "BGIPATH=";    // Danach suchen wir


    asm    mov     ah, 30h
    asm    int     21h                      // get dos version
    asm    mov     [DosVersion], al
    asm    mov     ax, 5100h                // Get PSP < DOS 3
    asm    cmp     Byte Ptr [DosVersion], 03h     // Version 3.XX ?
    asm    jb      L1
    asm    mov     ax, 6200h                // Get PSP >= DOS 3.0
L1: asm    int     21h                      // Get PSP
    asm    mov     [PSPSeg], bx             // PSP merken
    asm    mov     dx, ds                   // Datensegemnt retten
    asm    mov     ds, bx                   // ds = PSPSeg
    asm    mov     ds, WORD PTR [ds:2ch]    // ds = Environment
    asm    xor     si, si                   // Startoffset = 0
    asm    cld                              // raufw�rts z�hlen
L2: asm    lea     di, PathCode
    asm    push    cs
    asm    pop     es                       // es:di = "BGIPATH="
    asm    mov     cx, 8                    // Stringl�nge
    asm    repz    cmpsb                    // Eintrag gefunden ?
    asm    jz      L5                       // Eintrag gefunden !
    asm    dec     si                       // Ein Zeichen zur�ck sonst
L3: asm    lodsb                            // Und nach Endezeichen suchen
    asm    or      al, al                   // 0 (= Ende) ?
    asm    jnz     L3                       // Nein, weitersuchen
    asm    cmp     al, Byte Ptr [si]        // Zweite 0 (Tabellenende) ?
    asm    jne     L2                       // Nein, weitersuchen

// Eintrag "BGIPATH=" nicht gefunden, BGIPath ist leer

L4: asm    push    cs
    asm    pop     es
    asm    mov     di, [BGIPath]            // Ziel nach es:di
    asm    stosb                            // 0 speichern (= Leerstring)
    asm    jmp     L9                       // Weiter, EXE-Pfad suchen

// Eintrag "BGIPath=" gefunden, String kopieren

L5: asm    push    cs
    asm    pop     es
    asm    mov     di, [BGIPath]            // Ziel nach es:di
    asm    mov     al, 0
    asm    cmp     Byte Ptr [si], al        // Kein String *?
    asm    jz      L8                       // Kein String !
L6: asm    mov     ah, al                   // Letztes Zeichen merken
    asm    lodsb                            // Zeichen holen
    asm    or      al, al                   // Endezeichen ?
    asm    jz      L7                       // Springe wenn ja
    asm    stosb                            // Zeichen speichern
    asm    jmp     L6                       // N�chstes Zeichen

// Pfadende, pr�fen ob '\' letztes Zeichen ist. Anf�gen wenn nicht

L7: asm    mov     al, '\'
    asm    cmp     ah, al
    asm    jz      L8                       // H�ngt schon dran
    asm    stosb                            // Sonst anh�ngen
L8: asm    mov     Byte Ptr [es:di], 0      // Und Ende markieren

// "BGIPath=" wurde komplett behandelt. Nach dem Start des EXE-Namens
// suchen. Einsprung hier mit si als Zeiger auf das Byte nach der
// abschliessenden 0 eines normalen Eintrags.

L9: asm    push    cs
    asm    pop     es
    asm    mov     di, [EXEPath]            // Neues Ziel
    asm    cmp     Byte Ptr [DosVersion], 03h     // Nur ab Version 3.0 verf�gbar
    asm    jae     M2                       // Ok, start ...
    asm    mov     Byte Ptr [es:di], 00h    // EXEPath ist leer
    asm    jmp     M7                       // Sorry ...

M1: asm    lodsb                            // N�chstes Zeichen holen
    asm    or      al, al                   // = 0 ?
    asm    jnz     M1                       // Suche nach 0
M2: asm    lodsb                            // Ende pr�fen
    asm    or      al, al
    asm    jnz     M1

// N�chste zwei Bytes �berspringen

    asm    inc     si
    asm    inc     si

// si zeigt auf den Start des EXE-Namens

M4: asm    mov     bx, di                   // Adresse letztes '\' merken
M5: asm    lodsb                            // Zeichen holen
    asm    stosb                            // Zeichen speichern
    asm    or      al, al                   // Ende ?
    asm    jz      M6                       // Springe wenn ja
    asm    cmp     al, '\'                  // Pfad-Trenner
    asm    jz      M4                       // Position merken und weiter
    asm    jmp     M5                       // weiter

// Ende des Kopierens. bx zeigt auf das letzte '\'

M6: asm    mov     Byte Ptr [es:bx], 00h    // Ende markieren

// Fertig, Datensegment r�cksetzen und Ende

M7: asm    mov     ds, dx

}





void * pascal _LoadUserFile (char *FileName)
// Versucht die Datei mit dem �bergebenen Namen in den Puffer zu laden.
// Das Ergebnis der Routine ist ein Zeiger auf den Puffer in den die Datei
// geladen wurde, oder NULL, wenn das Laden mi�lang

{
    int  Handle;
    long Length;
    EpsonDST near *PRNData;

    // Datei �ffnen
    if ((Handle = ropen (FileName)) == -1) {
        // Fehler beim �ffnen
        return NULL;
    }

    // Dateil�nge holen, mu� <= 256 sein
    if ((Length = filelength (Handle)) > 256L) {
        // Datei zu gro� --> Schlie�en und Ende
        (void) close (Handle);
        return NULL;
    }

    // Speicher belegen f�r die Datei
    PRNData = (EpsonDST *) GetStatMem ((WORD) Length);

    // Daten in den Puffer lesen
    if (read (Handle, PRNData, (WORD) Length) == 0xFFFF) {
        // Fehler beim Lesen - der statische Speicherbereich kann nicht mehr
        // freigegeben werden und ist deshalb verloren ...
        (void) close (Handle);
        return NULL;
    }

    // Daten sind Ok, Datei schlie�en
    (void) close (Handle);

    // Strings relozieren
    PRNData->DST.Name     += (WORD) PRNData;
    PRNData->LineFeed1    += (WORD) PRNData;
    PRNData->LineFeed2    += (WORD) PRNData;
    PRNData->GraphicsOn   += (WORD) PRNData;
    PRNData->GraphicsOff  += (WORD) PRNData;
    PRNData->PreBytes     += (WORD) PRNData;
    PRNData->PostBytes    += (WORD) PRNData;

    /* Druckroutine eintragen */
    PRNData->DST.Print     = EpsonPrint;

    // PutPixel/GetPixel-Routinen eintragen
    PRNData->DST.PutPixel  = EpsonPutPixel;
    PRNData->DST.GetPixel  = EpsonGetPixel;

    // Vermerken, da� es sich um einen Nadeldrucker-Modus handelt
    PRNData->DST.IsEpson   = TRUE;

    /* Operation war erfolgreich */
    return (PRNData);
}




void pascal LoadUserFile (char *FileName, char *EXEPath, char *BGIPath, int Mode)
//
// Versucht die Datei mit dem Namen FileName zuerst im aktuellen, dann im
// Verzeichnis EXEPath und zuletzt im Verzeichnis BGIPath zu finden und zu
// laden.
// EXEPath und BGIPath m�ssen dabei zwei Pfade sein, die mit einem Backslash
// enden.
// Bei Erfolg der Aktion wird die Adresse des Puffers in die Tabelle der
// DST's eingetragen, bei Mi�erfolg passiert nix.
//

{
    char *PathEnd;                // Zeiger auf Ende des �bergebenen Pfades
    void *Buffer;                 // Zeiger auf Puffer f�r Modus-Daten

    /* Zuerst im aktuellen Verzeichnis versuchen */
    if ((Buffer = _LoadUserFile (FileName)) != NULL) {
        // Eintragen und Ende
        DSTTable [Mode] = (_DST *) Buffer;
        return;
    }

    /* Dann im EXE-Verzeichnis */
    if (*EXEPath != 0x00) {
        /* Ende des Pfades merken */
        PathEnd = EXEPath + strlen (EXEPath);
        strcpy (PathEnd, FileName);
        if ((Buffer = _LoadUserFile (EXEPath)) != NULL) {
            // Pfad wieder r�cksetzen
            *PathEnd = 0x00;
            // Eintragen und Ende
            DSTTable [Mode] = (_DST *) Buffer;
            return;
        }
        /* Pfad wieder r�cksetzen */
        *PathEnd = 0x00;
    }

    /* Und zum Schlu� im BGI-Verzeichnis */
    if (*BGIPath != 0x00) {
        /* Ende des Pfades merken */
        PathEnd = BGIPath + strlen (BGIPath);
        strcpy (PathEnd, FileName);
        if ((Buffer = _LoadUserFile (BGIPath)) != NULL) {
            // Pfad wieder r�cksetzen
            *PathEnd = 0x00;
            // Eintragen und Ende
            DSTTable [Mode] = (_DST *) Buffer;
            return;
        }
        /* Pfad wieder r�cksetzen */
        *PathEnd = 0x00;
    }

}



/* ----------------------------- INSTALL ------------------------------- */
/*                                                                       */
/*      The Install function is used to prepare the driver to use.       */
/*      The calls to this function allow the kernal to inquire the       */
/*      mode information, and allow the kernal to install the mode       */
/*      infomation.                                                      */
/*                                                                       */


void pascal InvalidMode (void)
// Setzt den DSTPtr auf die erste DST und tr�gt einen Fehler ein
{
  DSTPtr = DSTTable [0];
  Status.Stat = grInvalidMode;
}





void cdecl install ()
{

    char *EXEPath, *BGIPath;    // Pfade zum EXE- und BGI-Verzeichnis
    BYTE Mode, Cmd;
    DWORD MemSize;              // Ben�tigte Speichergr��e
    WORD Tmp;                   // Anzahl Nadeln


    // Modus steht in cl, Kommando in al
    Cmd  = _AL;
    Mode = _CL;

    // Kommando unterscheiden
    switch (Cmd) {

        // Install device
        case 0:
            // Variablen des Treibers korrekt setzen
            InitBGI ();

            // Pr�fen, ob der Modus zul�ssig ist
            if ((Mode >= MaxModes) || (DSTTable [Mode] == NULL)) {
                // Ung�ltige Modusnummer oder kein Parametersatz
                InvalidMode ();
            } else {
                // Den Zeiger auf die richtige DST setzen
                DSTPtr = DSTTable [Mode];
            }

            // Aus den in der DST gespeicherten Werten den Status-Record
            // zusammenbauen, der sp�ter an das Kernel zur�ckgeht.
            Status.XInch  = DSTPtr->XInch;
            Status.YInch  = DSTPtr->YInch;
            asm     mov     bx, [DSTPtr]
            asm     mov     cx, 1000
            asm     mov     ax, [bx].XDPI
            asm     mul     WORD PTR [bx]. (_DST) XInch
            asm     div     cx
            asm     and     ax, 0FFF8h                  // durch 8 teilbar machen
            asm     dec     ax
            asm     mov     WORD PTR [Status.XRes], ax
            asm     mov     WORD PTR [Status.XEfRes], ax
            asm     mov     ax, [bx].YDPI
            asm     mul     WORD PTR [bx]. (_DST) YInch
            asm     div     cx
            asm     and     ax, 0FFF8h                  // durch 8 teilbar machen
            asm     dec     ax
            asm     mov     WORD PTR [Status.YRes], ax
            asm     mov     WORD PTR [Status.YEfRes], ax
            asm     mov     ax, 10000
            asm     mul     WORD PTR [bx].XDPI
            asm     div     WORD PTR [bx].YDPI
            asm     mov     WORD PTR [Status.Aspec], ax

            // Berechnen wieviel Speicher notwendig ist. Da Nadeldrucker die Anzahl
            // Nadeln immer untereinander drucken, in diesem Fall die X-Aufl�sung
            // so erweitern, das beim Bildende auf den unteren Nadeln kein Mist
            // kommt (d.h. f�r die Berechnung die X-Koordinate aufrunden).
            if (DSTPtr->IsEpson == TRUE) {
                // Ausrechnen wieviele X-Einheiten immer zusammengeh�ren
                Tmp = ((WORD) ((EpsonDST *) DSTPtr)->ColBytes *
                       (WORD) ((EpsonDST *) DSTPtr)->PassCount) * 8;

                // Den X-Wert auf das n�chste vielfache dieses Wertes aufrunden
                Tmp = ((Status.XEfRes + Tmp) / Tmp) * Tmp;
                MemSize = LongMul (Tmp, Status.YEfRes + 1) / 8;
            } else {
                MemSize = (LongMul (Status.XEfRes + 1, Status.YEfRes + 1) *
                           (DWORD) DSTPtr->ColorBits) / 8;
            }

            // Speicher initialisieren
            InitMemory (MemSize);

            // Bei Fehlern das Statusbyte setzen
            if (Result != 0) {

                // Keine M�glichkeit zur Speicherung gefunden --> Fehler
                Status.Stat = grIOError;

            }

            // Zeiger auf DST in es:bx r�ckliefern
            _BX = (WORD) &Status;
            _ES = _DS;

            // Fertig
            break;


      case 1:
          // Mode-Query
          _CX = MaxModes;
          break;


      case 2:
          // Mode-Name
          if (Mode >= MaxModes) {
              Mode = 0;
          } else if (DSTTable [Mode] == NULL) {
              Mode = 0;
          }
          _BX = (WORD) DSTTable [Mode]->Name;
          _ES = _DS;
          break;

    }
}


/* ----------------------------- ALLPALETTE ---------------------------- */
/*                                                                       */
/*      The all palette command is used to load an entire palette in     */
/*      a single output command. The current BGI limits the size of      */
/*      the allpalette command to be the first 16 colors.                */
/*                                                                       */

void cdecl allpalette ()
{
    BYTE far *NewPalette;
    WORD I;

    // Zeiger auf neue Palette holen
    asm     mov     WORD PTR [NewPalette], bx
    asm     mov     WORD PTR [NewPalette+2], es

    // Neue Palette �bernehmen (ab 1. Element), dann auf G�ltigkeit pr�fen
    for (I = 1; I <= DSTPtr->ColorCount; I++) {
        Settings [I] = *NewPalette++;
    }

    // G�ltigkeit der wichtigen Eintr�ge pr�fen
    if (djQuality > 2) {
        // Default nehmen
        djQuality = djDefQuality;
    }
    if (djShingling > 2) {
        // Default nehmen
        djShingling = djDefShingling;
    }
    if (djDepletion > 2) {
        // Default nehmen
        djDepletion = djDefDepletion;
    }

}


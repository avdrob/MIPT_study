/****************************************************************************/
/*                                                                          */
/*            Virtuelle Speicherverwaltung f�r BGI-Druckertreiber           */
/*                                                                          */
/****************************************************************************/



//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: memory.h 2.4 1995/04/28 16:19:50 Uz Exp $
//
// $Log: memory.h $
// Revision 2.4  1995/04/28 16:19:50  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.3  93/08/01  20:53:25  Uz
// Neues Format mit DPMI-Support
//
//
//



#ifndef _MEMORY_H
#define _MEMORY_H


#include "const.h"




/****************************************************************************/
/*                                 Variable                                 */
/****************************************************************************/


extern BYTE       Result;               // Ergebnis der letzten Operation
extern BOOLEAN    Dirty;                // TRUE wenn Puffer dirty


// Map-Routine
BYTE far * pascal Map (DWORD Abs);      // Mappt das Byte an Positon Abs

/****************************************************************************/
/* Initialisierung des Speichers. Pr�ft nach, ob eines der Speichermedien   */
/* gen�gend Speicher zur Verf�gung stellen kann, belegt aber den Speicher   */
/* nicht.                                                                   */
/*                                                                          */
/* Parameter:                                                               */
/*   MemSize            ben�tigte Speichergr��e in Bytes                    */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn gen�gend Speicher vorhanden ist.        */
/*   Au�erdem werden die Vektoren zum Ansprechen des Speichers korrekt      */
/*   gesetzt. Ist nicht ausreichend Speicher vorhanden, so wird Result auf  */
/*   -1 gesetzt.                                                            */
/*                                                                          */
/****************************************************************************/

void pascal InitMemory (DWORD MemSize);


/****************************************************************************/
/* Belegen des Speichers. Kann nur aufgerufen werden, wenn zuvor            */
/* InitializeMem ohne Fehler durchgef�hrt wurde. Belegt den Speicher der    */
/* InitializeMem als Gr��e �bergeben wurde.                                 */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn der Speicher belegt werden konnte.      */
/*   Ansonsten wird Result auf einen Wert != 0 gesetzt.                     */
/*                                                                          */
/****************************************************************************/

void pascal AllocateMemory ();



/****************************************************************************/
/* Freigeben des Speichers. Kann nur aufgerufen werden, wenn zuvor Speicher */
/* belegt wurde. Gibt den belegten Speicher komplett wieder frei.           */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn der Speicher freigegeben werden konnte. */
/*   Ansonsten wird Result auf einen Wert != 0 gesetzt.                     */
/*                                                                          */
/****************************************************************************/

void pascal DeallocateMemory ();



/****************************************************************************/
/* L�schen des kompletten belegten Speichers.                               */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   keines.                                                                */
/*                                                                          */
/****************************************************************************/

void pascal ClearMemory ();


#endif

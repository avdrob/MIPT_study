/******************************************************************************/
/*                                                                            */
/*                                   NP.H                                     */
/*                                                                            */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// $Id: np.h 1.2 1995/04/22 17:30:16 Uz Exp $
//
// $Log: np.h $
// Revision 1.2  1995/04/22 17:30:16  Uz
// Struct EPSONDST ge�ndert. Ersatz einiger BOOLEANs durch ein bitmapped
// Flags Byte.
//
// Revision 1.1  94/03/19  16:15:45  Uz
// Initial revision
//
//
//



#ifndef _NP_H
#define _NP_H


#include "const.h"
#include "bgifunc.h"



/****************************************************************************/
/*                                                                          */
/*    Die folgende Struktur enth�lt einen Device-Status-Block. Die ersten   */
/*  Werte m�ssen immer dieselben sein, da sie vom Grafik-Modul so erwartet  */
/*  werden. Im Anschlu� kommen eigene Variablen, die von Drucker zu Drucker */
/*        bzw. besser von Treiber zu Treiber verschieden sein k�nnen.       */
/*                                                                          */
/****************************************************************************/


struct EpsonDST {

    _DST            DST;              // Orginal-DST

    BYTE            ColBytes;         // Anzahl Bytes / Druckerspalte
    BYTE            PassCount;        // Wie oft �berdrucken

    char            *LineFeed1;       // Normaler Linefeed
    char            *LineFeed2;       // Linefeed zwischen �berdrucken

    char            *GraphicsOn;      // Grafik einschalten (mit Init)
    char            *GraphicsOff;     // Grafik ausschalten

    char            *PreBytes;        // String vor Grafik-Daten
    char            *PostBytes;       // String nach Grafik-Daten

};


// Statische Variable die die Gr��e einer (Farb-) Bitplane bestimmt
// (nur wichtig f�r Farbmodi). Diese Variable wird von install gesetzt,
// da sie dort als Nebenprodukt der Berechnung des Speicherbedarfs anf�llt.
extern DWORD ColorPlaneSize;



/****************************************************************************/
/*                                                                          */
/* Setzen eines Pixels an den �bergebenen X/Y-Koordinaten, in der           */
/* �bergebenen Farbe und im gew�nschten Schreib-Modus.                      */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*   Color      Farbe                                                       */
/*   WriteMode  Schreibmodus wie in const.h definiert                       */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  (keine)                                                                 */
/*                                                                          */
/****************************************************************************/

void pascal EpsonPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode);
// Eigene Funktion PutPixel die XORMode ber�cksichtigt


/****************************************************************************/
/*                                                                          */
/* Holen eines Pixels von einer �bergebenen X/Y-Koordinate. Zur�ckgegeben   */
/* wird die Farbe.                                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  BYTE        Farbe                                                       */
/*                                                                          */
/****************************************************************************/

BYTE pascal EpsonGetPixel (WORD X, WORD Y);
// Liefert die Farbe f�r den �bergebenen Punkt zur�ck


/****************************************************************************/
/*                                                                          */
/* Universelle Ausgaberoutine f�r Nadeldrucker.                             */
/*                                                                          */
/* Parameter:                                                               */
/*   (keine)                                                                */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  (keine)    bzw. hoffentlich ein Ausdruck...                             */
/*                                                                          */
/****************************************************************************/

void pascal EpsonPrint (void);
// Universelle Drucker-Routine f�r Nadeldrucker




//
// End of NP.H
//

#endif


/*****************************************************************************/
/*                                                                           */
/*                                  PCX.CPP                                  */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: pcx.h 1.1 1995/04/28 16:19:20 Uz Exp $
//
// $Log: pcx.h $
// Revision 1.1  1995/04/28 16:19:20  Uz
// Initial revision
//
//
//



#ifndef _PCX_H
#define _PCX_H



/****************************************************************************/
/*                                   Code                                   */
/****************************************************************************/



void pascal PCXPrint ();
// Ausdruck in das PCX-File

void pascal PCXPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode);
// Eigene Funktion PutPixel f�r PCX, die XORMode ber�cksichtigt

BYTE pascal PCXGetPixel (WORD X, WORD Y);
// Liefert die Farbe f�r den �bergebenen Punkt zur�ck



// Ende von PCX.H

#endif

/****************************************************************************/
/*                                                                          */
/*             Allgemeine Hilfs-Prozeduren f�r BGI-Druckertreiber           */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: util.h 2.7 1995/04/28 16:20:10 Uz Exp $
//
// $Log: util.h $
// Revision 2.7  1995/04/28 16:20:10  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.6  95/04/22  17:29:13  Uz
// Kosmetik.
//
// Revision 2.5  94/03/28  16:29:00  Uz
// Neue Funktion Round.
//
// Revision 2.4  94/03/19  16:15:47  Uz
// Neues Modul, enth�lt alle Funktionen f�r Ausgabe auf Nadeldrucker.
//
// Revision 2.3  93/08/01  20:53:21  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _UTIL_H
#define _UTIL_H


#include "const.h"



/****************************************************************************/
/*                                                                          */
/* Multiplizieren zweier WORD (unsigned) Werte. Das Ergebnis hat 32 Bit.    */
/*                                                                          */
/****************************************************************************/

DWORD pascal LongMul (WORD A, WORD B);




/****************************************************************************/
/*                                                                          */
/* Dividieren eines DWORD (unsigned) 32-Bit Wertes durch einen 16-Bit Wert. */
/* Das Ergebnis hat 16 Bit.                                                 */
/*                                                                          */
/****************************************************************************/

WORD pascal LongDiv (DWORD A, WORD B);




/****************************************************************************/
/*                                                                          */
/* Aufrunden eines DWORD-Wertes auf vielfache eines WORD-Wertes.            */
/* ACHTUNG: A / B mu� einen 16-Bit-Wert ergeben (d.h. B darf nicht zu klein */
/* bzw A nicht zu gro� sein).                                               */
/*                                                                          */
/****************************************************************************/

DWORD pascal Round (DWORD A, WORD B);




/****************************************************************************/
/* Wandeln eines WORD-Wertes nach ASCII und ablegen in einem String. Es     */
/* wird am Schlu� ein 0-Byte angef�gt. Die �bergebene Zahl wird als vor-    */
/* zeichenloser 16-Bit Wert behandelt, die L�nge des Strings betr�gt        */
/* maximal 6 Zeichen (5 + 0-Byte).                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   W          Die Zahl wie oben beschrieben                               */
/*   S          Der Puffer in dem der ASCII-String abgelegt wird.           */
/*                                                                          */
/* Ergebnis:                                                                */
/*   S                                                                      */
/*                                                                          */
/****************************************************************************/

char far * pascal Num (WORD W, char far *S);



/***************************************************************************/
/* Eigener Quicksort, da der Standard-Sort aufgrund der �bergebenen NEAR-  */
/* Zeiger leider nicht funktioniert.                                       */
/***************************************************************************/



void pascal QuickSort (int far *Base, WORD Num);
// Quicksort, pr�ft die Parameter und ruft die Routine auf, die die
// eigentliche Arbeit macht.


#endif


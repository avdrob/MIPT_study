/*****************************************************************************/
/*                                                                           */
/*                                  JUMP.CPP                                 */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: jump.cpp 1.1 1995/04/28 16:20:40 Uz Exp $
//
// $Log: jump.cpp $
// Revision 1.1  1995/04/28 16:20:40  Uz
// Initial revision
//
//
//



#include "jump.h"



/*****************************************************************************/
/*                                   Data                                    */
/*****************************************************************************/



// Konstanten zum Ansprechen des jmp_buf Inhalts
const unsigned jbIP     = 0;
const unsigned jbSP     = 1;
const unsigned jbBP     = 2;
const unsigned jbSI     = 3;
const unsigned jbDI     = 4;



/*****************************************************************************/
/*                                   Code                                    */
/*****************************************************************************/



int pascal SetJump (JumpBuf _ds &Buf)
// Setzt ein Sprunglabel.
// Stack:
//      bp+4    --> Buf
//      bp+2    --> R�cksprungadresse
//      bp+0    --> Alter bp
{
    // Zeiger auf den Puffer holen
    asm mov    bx, [Buf]

    // Registervariablen si und di des Aufrufers speichern
    asm mov     [bx+jbSI*2], si
    asm mov     [bx+jbDI*2], di

    // R�cksprungadresse holen und speichern
    asm mov     ax, [bp+2]
    asm mov     [bx+jbIP*2], ax

    // SP der aufrufenden Routine holen und speichern
    asm lea     ax, [bp+6]
    asm mov     [bx+jbSP*2], ax

    // BP der aufrufenden Routine holen und speichern
    asm mov     ax, [bp+0]
    asm mov     [bx+jbBP*2], ax

    // Ende mit Returncode 0
    return 0;
}



void pascal LongJump (JumpBuf _ds &Buf, int RetVal)
// Springt ein zuvor gesichertes Sprunglabel an und liefert RetVal zur�ck
{
    // Zeiger auf den Puffer holen
    asm mov     bx, [Buf]

    // Alte Registervariablen wiederherstellen
    asm mov     si, [bx+jbSI*2]
    asm mov     di, [bx+jbDI*2]

    // ax mit dem Funktionsergebnis laden (jetzt, weil gleich bp ge�ndert wird)
    asm mov     ax, [RetVal]

    // Altes BP und SP laden
    asm mov     bp, [bx+jbBP*2]
    asm mov     sp, [bx+jbSP*2]

    // Zur�ckspringen zum ehemaligen Aufrufer
    asm mov     bx, [bx+jbIP*2]
    asm jmp     bx
}


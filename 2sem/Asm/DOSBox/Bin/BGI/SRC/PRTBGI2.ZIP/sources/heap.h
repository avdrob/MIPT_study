/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Einfache Speicherverwaltung f�r BGI-Druckertreiber. Erlaubt das          */
/* tempor�re oder dauernde Belegen von Speicher bis hin zu einer bestimmten */
/* Maximalgrenze.                                                           */
/*                                                                          */
/* ACHTUNG: Die hier implementierte Speicherverwaltung ist _sehr_ einfach   */
/* gehalten. Das Ziel war mit wenig Overhead dynamisch Speicher belegen zu  */
/* k�nnen um die Gr��e des Treibers zu verkleinern. Da es um die Verwaltung */
/* von ca. 1KB an Speicher dreht, darf der Code zur Verwaltung nicht mehr   */
/* Overhead verursachen, als die paar Bytes, die eine dynamische Belegung   */
/* spart.                                                                   */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: heap.h 2.6 1995/04/22 17:29:40 Uz Exp $
//
// $Log: heap.h $
// Revision 2.6  1995/04/22 17:29:40  Uz
// Funktion HeapAvail entfernt, GetStatMem ge�ndert, Heap-Gr��e ge�ndert.
//
// Revision 2.5  94/09/08  14:15:16  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.4  94/03/19  16:13:32  Uz
// Neue (bisher unbenutzte) Funktion HeapAvail
//
// Revision 2.3  93/08/01  20:53:24  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _HEAP_H
#define _HEAP_H



#include "const.h"



/****************************************************************************/
/* Belegen von dynamischem Speicher. Die Bl�cke m�ssen in der umgekehrten   */
/* Reihenfolge der Belegung freigegeben werden (Stack-Anordnung).           */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des Speicherbereichs.                              */
/*                                                                          */
/* Ergebnis:                                                                */
/*   BYTE *        Zeiger auf angeforderten Bereich.                        */
/*                                                                          */
/****************************************************************************/

BYTE * _fastcall GetDynMem (WORD Size);


/****************************************************************************/
/* Freigeben von dynamischem Speicher. Die Bl�cke m�ssen in der umgekehrten */
/* Reihenfolge der Belegung freigegeben werden (Stack-Anordnung).           */
/* Es wird eine Gr��e anstatt eines Zeigers �bergeben, dann spielt die      */
/* Reihenfolge der Freigabe zweier (oder mehrerer) Bereiche keine Rolle,    */
/* solange nur immer alle zusammen belegt bzw. freigegeben werden.          */
/*                                                                          */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des freizugebenden Blocks.                         */
/*                                                                          */
/* Ergebnis:                                                                */
/*   (keins)                                                                */
/*                                                                          */
/****************************************************************************/

void _fastcall FreeDynMem (WORD Size);



/****************************************************************************/
/* Belegen von statischem Speicher.                                         */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des Speicherbereichs.                              */
/*                                                                          */
/* Ergebnis:                                                                */
/*   BYTE *        Zeiger auf angeforderten Bereich.                        */
/*                                                                          */
/****************************************************************************/

BYTE * _fastcall GetStatMem (WORD Size);



/****************************************************************************/
/* Initialisierung des Heaps. Mu� durch eine eigene Funktion durchgef�hrt   */
/* werden, da keine statischen Variablen benutzt werden k�nnen (geht schief */
/* wenn der Treiber als OBJ-Datei eingebunden wird und mehrmals             */
/* initialisiert wird).                                                     */
/*                                                                          */
/* Parameter:                                                               */
/*   (keine)                                                                */
/*                                                                          */
/* Ergebnis:                                                                */
/*   (keins)                                                                */
/*                                                                          */
/****************************************************************************/

void pascal InitHeap ();



#endif

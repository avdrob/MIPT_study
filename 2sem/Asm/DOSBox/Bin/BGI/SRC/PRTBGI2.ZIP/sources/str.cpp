/******************************************************************************/
/*                                                                            */
/*                                 STR.CPP                                    */
/*                                                                            */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// (C) 1994 Ullrich von Bassewitz
//
// $Id: str.cpp 1.3 1995/04/28 16:21:21 Uz Exp $
//
// $Log: str.cpp $
// Revision 1.3  1995/04/28 16:21:21  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 1.2  95/04/22  17:35:31  Uz
// Neue Funktion memcpy.
//
// Revision 1.1  94/03/29  18:32:35  Uz
// Initial revision
//
//



#include "const.h"



char far * pascal strcpy (char far * Dest, char far * Src)
// Kopiert Src nach Dest, liefert Dest zur�ck
{
    asm push    ds
    asm les     bx, [Dest]
    asm mov     ax, bx
    asm lds     si, [Src]
L1: asm mov     cl, [si]
    asm mov     es:[bx], cl
    asm inc     si
    asm inc     bx
    asm cmp     cl, 0
    asm jne     L1
    asm pop     ds
    asm mov     dx, es
    return (char far *) MK_FP (_DX, _AX);
}




char far * pascal strcat (char far *Dest, char far *Src)
// Kopiert Src an das Ende von Dest, liefert Dest zur�ck
{
    asm les     bx, [Dest]
    asm mov     ax, bx
    asm dec     bx
L1: asm inc     bx
    asm cmp     byte ptr es:[bx], 0
    asm jne     L1
    asm push    ds
    asm lds     si, [Src]
L2: asm mov     cl, [si]
    asm mov     es:[bx], cl
    asm inc     si
    asm inc     bx
    asm cmp     cl, 0
    asm jne     L2
    asm pop     ds
    asm mov     dx, es
    return (char far *) MK_FP (_DX, _AX);
}



unsigned pascal strlen (char far *S)
// Liefert die L�nge des Strings S zur�ck
{
    asm sub     ax, ax
    asm les     bx, [S]
L1: asm cmp     byte ptr es:[bx], 0
    asm je      L2
    asm inc     bx
    asm inc     ax
    asm jmp     L1
L2: return _AX;
}



void pascal memcpy (void far * Dest, void far * Src, unsigned Count)
// Kopiert Count Bytes von Src nach Dest, liefert Dest zur�ck
{
    asm push    ds
    asm les     di, [Dest]
    asm lds     si, [Src]
    asm mov     cx, [Count]
    asm cld
    asm rep     movsb
    asm pop     ds
}




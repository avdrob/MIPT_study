/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Enth�lt alle BGI-Funktionen, die nur auf PutPixel/GetPixel beruhen und   */
/* deshalb immer gleich bleiben.                                            */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: bgifunc.cpp 2.14 1995/04/28 16:21:27 Uz Exp $
//
// $Log: bgifunc.cpp $
// Revision 2.14  1995/04/28 16:21:27  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.13  95/04/22  17:36:59  Uz
// Neue Funktion palette. Anpassungen f�r DeskJet 1200C.
//
// Revision 2.12  95/03/29  15:35:08  Uz
// 0xFFFF fest als Wert f�r XInch/YInch in den Status-Record eingetragen
//
// Revision 2.11  94/09/08  14:14:16  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.10  94/09/08  09:31:35  Uz
// Anpassung an extra modedata Modul. �nderung bei Linien: Das Linienmuster
// wird (�hnlich wie bisher bereits bei F�llmustern) skaliert, damit es
// auch bei hohen Aufl�sungen noch erkennbar ist.
//
// Revision 2.9  94/03/29  20:56:01  Uz
// Kleinere �nderungen zur Erzeugung von kompakterem Code.
//
// Revision 2.8  94/03/28  13:02:10  Uz
// Bei der Initialisierung zus�tzlich den Statuscode gel�scht.
//
// Revision 2.7  94/03/19  16:26:47  Uz
// Kosmetik und Cleanup.
//
// Revision 2.6  94/02/25  14:30:59  Uz
// Farb-Auswertung ge�ndert. Wird versucht ein Farbwert gr��er als der
// maximal zul�ssige zu setzen, so nimmt der Treiber stattdessen den
// h�chsten zul�ssigen Farbwert. Zuvor wurde der Farbwert unver�ndert
// �bernommen, was dazu gef�hrt hat, da� die tats�chlich verwendete
// Farbe bei Farbnummern die gr��er als der Grenzwert sind, nicht
// definiert war.
//
// Revision 2.5  94/02/25  14:15:06  Uz
// Fehler aus DrawEllipse entfernt. Bei Ellipsen (d.h. auch Kreisen) mit
// Radius 0 wurde der zuerst belegte Linienpuffer nicht mehr freigegeben,
// was zu �berl�ufen auf dem Treiber internen Heap f�hrte.
//
// Revision 2.4  94/02/01  08:51:36  Uz
// Fehler aus textstyle () entfernt. Anstelle der tatsaechlichen Gr��e
// wurde der Multiplikationsfaktor zur�ckgeliefert, was dazu gef�hrt
// hat, das SetTextJustify nicht korrekt funktionierte.
//
// Revision 2.3  93/08/01  20:52:55  Uz
// Neues Format mit DPMI-Support
//
//
//


#include <stddef.h>
#include "const.h"
#include "util.h"
#include "str.h"
#include "memory.h"
#include "sincos.h"
#include "bgifunc.h"




/****************************************************************************/
/*                                Prototypen                                */
/****************************************************************************/




// Hier stehen alle Funktionen deren Namen nicht "gemangelt" werden sollen,
// weil sie im Assembler-Teil verwendet werden.

extern "C" {

    void cdecl init          ();
    void cdecl clear         ();
    void cdecl post          ();
    void cdecl move          ();
    void cdecl draw          ();
    void cdecl vect          ();
    void cdecl polygon       ();
    void cdecl patbar        ();
    void cdecl arc           ();
    void cdecl sector        ();
    void cdecl ellipse       ();
    void cdecl palette       ();
    void cdecl color         ();
    void cdecl fillstyle     ();
    void cdecl linestyle     ();
    void cdecl textstyle     ();
    void cdecl outtext       ();
    void cdecl textsiz       ();
    void cdecl getpixel      ();
    void cdecl setpixel      ();
    void cdecl bitmaputil    ();
    void cdecl savebitmap    ();
    void cdecl restorebitmap ();
    void cdecl setclip       ();
    void cdecl color_query   ();

    // Der Emulate-Vektor als externe Funktion
    void pascal near Emulate ();
}




/****************************************************************************/
/*                      Extern deklarierte Variable                         */
/****************************************************************************/

// Die Farbtabelle wird (da nicht verwendet) als M�glichkeit zur Einstellung
// von diversen Daten von au�en benutzt. Sie hei�t daher nicht ColorTable
// (wie im SVGA-Treiber), sondern Settings (f�r die aktuelle Tabelle) und
// DefaultSettings (f�r die Default-Einstellungen).

BYTE DefaultSettings [9] = {
    8,                          // Anzahl folgender Bytes
    0,                          // Reserved
    0,                          // Output quality, 0 --> keypad setting
                                //                 1 --> draft
                                //                 2 --> high
    0,                          // Shingling,      0 --> normal
                                //                 1 --> 25% (2 pass)
                                //                 2 --> 50% (4 pass)
    1,                          // Depletion       0 --> none
                                //                 1 --> 25%
                                //                 2 --> 50%
    0,                          // Media type,     0 --> Plain paper
                                //                 1 --> Bond paper
                                //                 2 --> Special paper
                                //                 3 --> Glossy film
                                //                 4 --> Transparency film
    0, 0, 0                     // Reserved
};



// Die folgenden Farbtabelle wird als Einstellungstabelle "mi�braucht"
BYTE Settings [9] = {
    8,                          // Anzahl folgender Bytes
    0,                          // Reserved
    0,                          // Output quality, 0 --> keypad setting
                                //                 1 --> draft
                                //                 2 --> high
    0,                          // Shingling,      0 --> normal
                                //                 1 --> 25% (2 pass)
                                //                 2 --> 50% (4 pass)
    1,                          // Depletion       0 --> none
                                //                 1 --> 25%
                                //                 2 --> 50%
    0,                          // Media type,     0 --> Plain paper
                                //                 1 --> Bond paper
                                //                 2 --> Special paper
                                //                 3 --> Glossy film
                                //                 4 --> Transparency film
    0, 0, 0                     // Reserved
};


// RGB-Palette
RGBEntry RGBPal [256];

// Der Zeiger auf die aktuelle DST
_DST near* DSTPtr = NULL;



/****************************************************************************/
/*                                                                          */
/*                             Interne Variablen                            */
/*                                                                          */
/****************************************************************************/



// Der Status-Record der an das Kernel geht
struct _stat Status = {
    0,                            // Current device status.
    1,                            // Device Type Identifier.
    0,                            // Device Full Resolution in X
    0,                            // Device Full Resolution in Y
    0,                            // Device Effective X Resolution
    0,                            // Device Effective Y Resolution
    0xFFFF,                       // Device X Size in inches*1000
    0xFFFF,                       // Device Y Size in inches*1000
    10000,                        // Aspect Ratio * 10000
    8 + 0x80,                     // Standard char size X
    8 + 0x80,                     // Standard char size Y
    1 + 0x80,                     // Number of foreground colors
    1 + 0x80                      // Number of background colors
};




// Default-Palette f�r die ersten Eintr�ge
static RGBEntry RGBDefPal [8] = {
    {    0,   0,   0 },         // Black
    {  255,   0,   0 },         // Red
    {    0, 255,   0 },         // Green
    {  255, 255,   0 },         // Yellow
    {    0,   0, 255 },         // Blue
    {  255,   0, 255 },         // Magenta
    {  255, 255,   0 },         // Cyan
    {  255, 255, 255 }          // White
};



static BYTE FillPatternTable [12][8] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     // Empty Fill
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,     // Solid Fill
    0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,     // Line Fill
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,     // Lt Slash Fill
    0xE0, 0xC1, 0x83, 0x07, 0x0E, 0x1C, 0x38, 0x70,     // Slash Fill
    0xF0, 0x78, 0x3C, 0x1E, 0x0F, 0x87, 0xC3, 0xE1,     // Backslash Fill
    0xA5, 0xD2, 0x69, 0xB4, 0x5A, 0x2D, 0x96, 0x4B,     // Lt Bkslash Fill
    0xFF, 0x88, 0x88, 0x88, 0xFF, 0x88, 0x88, 0x88,     // Hatch Fill
    0x81, 0x42, 0x24, 0x18, 0x18, 0x24, 0x42, 0x81,     // XHatch Fill
    0xCC, 0x33, 0xCC, 0x33, 0xCC, 0x33, 0xCC, 0x33,     // Interleave Fill
    0x80, 0x00, 0x08, 0x00, 0x80, 0x00, 0x08, 0x00,     // Wide Dot Fill
    0x88, 0x00, 0x22, 0x00, 0x88, 0x00, 0x22, 0x00      // Close Dot Fill
};


static WORD LineStyleTable [4] = {
    0xFFFF, 0xCCCC, 0xFC78, 0xF8F8
};



// Current Drawing Pointer
int             CursorX = 0;
int             CursorY = 0;

// Clip-Fenster
int             ClipX1 = 0;
int             ClipY1 = 0;
int             ClipX2 = 0;
int             ClipY2 = 0;

// Aufl�sung
WORD            MaxX = 0;
WORD            MaxY = 0;

// Farben
BYTE            BackColor = 0;
BYTE            DrawColor = 1;
BYTE            FillColor = 1;

// Variable f�r FloodFill.
// BYTE            BorderColor;                    // Begrenzungsfarbe
// WORD _ss *      StackBot = (WORD _ss *) 512;    // Unterer Teil des Stacks
// WORD _ss *      StackTop;                       // Oberes Ende
// WORD _ss *      StackPtr;                       // Zeiger in Stack
// int             PrevXR;
// int             CurrXR;
// int             FillDir;                        // F�llrichtung

// Aktuelles FillPattern
static BYTE FillPattern [8] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

// Defaultfont
static BYTE     CharBuf [8];            // Zeichenpuffer
static WORD     TextSizeX   = 8;        // Gr��e X
static WORD     TextSizeY   = 8;        // Gr��e Y
static BYTE     TextNum     = 0;        // Immer 0
static BYTE     TextOrient  = 0;        // 0 = horizontal
static WORD     TextMultX   = 1;        // Multiplikator X
static WORD     TextMultY   = 1;        // Multiplikator Y


// LineStyle, WriteMode und Liniedicke
BYTE          LineWidth = 1;
BYTE          WriteMode = 0;
WORD          CurLineStyle = 0xFFFF;



/****************************************************************************/
/*                                                                          */
/*     Multiplikationsfaktoren entsprechend der X/Y-Aufl�sung errechnen     */
/*                                                                          */
/****************************************************************************/

static unsigned MultX ()
{
    // MultX = (DSTPtr->XDPI + 179) / 180;
    asm     mov     bx, [DSTPtr]
    asm     mov     cl, 180
    asm     mov     ax, [bx]. (_DST) XDPI
    asm     add     ax, 179
    asm     div     cl
    asm     cbw
    return _AX;
}



static unsigned MultY ()
{
    // YMult = (DSTPtr->YDPI + 179) / 180;
    asm     mov     bx, [DSTPtr]
    asm     mov     ax, [bx]. (_DST) YDPI
    asm     add     ax, 179
    asm     div     cl
    asm     cbw
    return _AX;
}



/****************************************************************************/
/*                                                                          */
/* Clip pr�ft eine Koordinate gegen das Clip-Fenster und liefert TRUE       */
/* wenn der Punkt au�erhalb liegt, FALSE wenn er ok ist.                    */
/*                                                                          */
/****************************************************************************/

BOOLEAN _fastcall Clip (int X, int Y)
{
    return (X < ClipX1 || X > ClipX2 || Y < ClipY1 || Y > ClipY2);
}



/****************************************************************************/
/*                                                                          */
/* Zeichnen einer horizontalen Linie im aktuellen F�llmuster von X1 nach X2 */
/* wobei rechts und links sowie oben und unten anhand des eingestellten     */
/* Clip-Fensters geclippt wird.                                             */
/* Verwendet wird das aktuelle FillPattern.                                 */
/*                                                                          */
/****************************************************************************/


static void pascal DrawFillLine (WORD X1, WORD X2, WORD Y)
{
    WORD XMult, YMult;
    register WORD Mult;
    BYTE Pattern, Color;


    if ((Y < ClipY1) || (Y > ClipY2)) {
        // Linie liegt au�erhalb
        return;
    }

    // X-Koordinaten so ordnen, da� X1 <= X2, dann gleich noch clippen bzw.
    // testen ob die Linie links oder rechts komplett au�erhalb liegt.
    asm     mov     ax, [X1]
    asm     mov     bx, [X2]
    asm     mov     cx, [ClipX1]        // In Register wg. Speed
    asm     mov     dx, [ClipX2]
    asm     cmp     ax, bx              // wenn X1 > X2
    asm     jl      A1
    asm     xchg    ax, bx              // tauschen....
A1: asm     cmp     ax, dx
    asm     jg      A2
    asm     cmp     bx, cx
    asm     jge     A3
A2: return;                             // Liegt au�erhalb !
A3: asm     cmp     ax, cx
    asm     jge     A4
    asm     mov     ax, cx
A4: asm     cmp     bx, dx
    asm     jle     A5
    asm     mov     bx, dx
A5: asm     mov     [X1], ax
    asm     mov     [X2], bx

    // Die Multiplikatoren f�r das Pattern aus der X- und Y-Aufl�sung
    // berechnen
    XMult = MultX ();
    YMult = MultY ();

    // Sodele, ab geht's
    Pattern = FillPattern [(Y / YMult) % 8];
    asm     mov     ax, [X1]
    asm     xor     dx, dx
    asm     div     [XMult]             // X1 / XMult
    asm     xchg    ax, cx              // in cx
    asm     and     cl, 7               // Modulo 8
    asm     rol     [Pattern], cl       // Patternstart passend setzen

    while (X1 <= X2) {

        // Farbe festlegen und Pattern rotieren
        asm     mov     al, [FillColor]
        asm     rol     [Pattern], 1
        asm     jc      L1
        asm     mov     al, [BackColor]
L1:     asm     mov     [Color], al

        // Pixel setzen
        for (Mult = X1 % XMult; X1 <= X2, Mult < XMult; Mult++, X1++) {
            DSTPtr->PutPixel (X1, Y, Color, COPY_PUT);
        }

    }
}



/****************************************************************************/
/*                                                                          */
/* Zeichnen einer beliebigen Linie im �bergebenen Linienmuster. Ein         */
/* Clippen erfolgt nicht, dies geschieht sowieso in PutPixel.               */
/*                                                                          */
/****************************************************************************/


static void pascal LinePixel (int X, int Y, WORD Color, BYTE Width, BYTE WriteMode)
{
    // Zeiger auf PutPixel in ein Register
    register void pascal (near *PutPixel) (WORD, WORD, BYTE, BYTE);
    PutPixel = DSTPtr->PutPixel;

    PutPixel (X, Y, Color, WriteMode);
    if (Width != 1) {
        PutPixel (X+1, Y, Color, WriteMode);
        PutPixel (X-1, Y, Color, WriteMode);
        PutPixel (X, Y+1, Color, WriteMode);
        PutPixel (X, Y-1, Color, WriteMode);
        PutPixel (X+1, Y+1, Color, WriteMode);
        PutPixel (X-1, Y+1, Color, WriteMode);
        PutPixel (X+1, Y-1, Color, WriteMode);
        PutPixel (X-1, Y-1, Color, WriteMode);
    }
}





static unsigned pascal RotatePattern (unsigned _ss* Pattern)
// Rotiert ein Pattern (das auf dem Stack liegt!) und liefert 1 wenn das letzte
// Pixel gesetzt ist, ansonsten 0
{
    asm sub     ax, ax
    asm mov     bx, [Pattern]
    asm shr     WORD PTR ss:[bx], 1
    asm rcr     WORD PTR ss:[bx+2], 1
    asm rcr     WORD PTR ss:[bx+4], 1
    asm rcr     WORD PTR ss:[bx+6], 1
    asm jnc     L1
    asm inc     ax
    asm or      WORD PTR ss:[bx], 8000h
L1: return _AX;
}



static void pascal CreatePattern (unsigned _ss* Pattern, unsigned Style)
{
    // Bei hohen Aufl�sungen den verwendeten LineStyle "vergr�ssern"
    unsigned XMult = MultX ();
    unsigned YMult = MultY ();
    unsigned Mult = XMult > YMult ? XMult : YMult;
    if (Mult == 1) {
        Pattern [0] = Style;
        Pattern [1] = Style;
        Pattern [2] = Style;
        Pattern [3] = Style;
    } else if (Mult == 2) {
        asm sub     ax, ax
        asm sub     dx, dx
        asm mov     bx, [Style]
        asm mov     di, 16
L1:     asm shl     ax, 1
        asm rcl     dx, 1
        asm shl     ax, 1
        asm rcl     dx, 1
        asm ror     bx, 1
        asm jnc     L2
        asm or      ax, 0003h
L2:     asm dec     di
        asm jnz     L1
        asm mov     bx, [Pattern]
        asm mov     WORD PTR ss:[bx], ax
        asm mov     WORD PTR ss:[bx+2], dx
        asm mov     WORD PTR ss:[bx+4], ax
        asm mov     WORD PTR ss:[bx+6], dx
    } else {
        asm sub     ax, ax
        asm sub     bx, bx
        asm sub     cx, cx
        asm sub     dx, dx
        asm mov     di, 16
L3:     asm mov     si, 4
L4:     asm shl     ax, 1
        asm rcl     bx, 1
        asm rcl     cx, 1
        asm rcl     dx, 1
        asm dec     si
        asm jnz     L4
        asm ror     [Style], 1
        asm jnc     L5
        asm or      ax, 000Fh
L5:     asm dec     di
        asm jnz     L3
        asm mov     di, [Pattern]
        asm mov     WORD PTR ss:[di], ax
        asm mov     WORD PTR ss:[di+2], bx
        asm mov     WORD PTR ss:[di+4], cx
        asm mov     WORD PTR ss:[di+6], dx
    }
}



static void pascal DrawLine (int X1, int Y1, int X2, int Y2,
                             WORD Style, BYTE Width, BYTE WriteMode)
{
    int Step, Delta, DirX, DirY, DeltaX, DeltaY;
    unsigned Pattern [4];

    // Bei hohen Aufl�sungen den verwendeten LineStyle "vergr�ssern"
    CreatePattern (Pattern, Style);

    // Steigung festlegen
    if (X1 > X2)
        DirX = -1;
    else
        DirX = 1;

    if (Y1 > Y2)
        DirY = -1;
    else
        DirY = 1;

    if ((DeltaX = (X1 - X2)) < 0)
        DeltaX = -DeltaX;

    if ((DeltaY = (Y1 - Y2)) < 0)
        DeltaY = -DeltaY;

    // Der etwas modifizierte Midpoint Algorithmus

    // Anfangspunkt zeichnen
    if (RotatePattern (Pattern)) {
        LinePixel (X1, Y1, DrawColor, Width, WriteMode);
    }

    // Steigung der Linie unterscheiden
    if (DeltaX >= DeltaY) {
        DeltaY = 2 * DeltaY;
        Delta  = DeltaY - DeltaX;
        Step   = DeltaX;
        DeltaX = 2 * DeltaX;

        while (Step--) {

            // Neuen Punkt berechnen
            if (Delta > 0) {
                Y1    += DirY;
                Delta -= DeltaX;
            }
            Delta += DeltaY;
            X1    += DirX;

            // Punkt setzen
            if (RotatePattern (Pattern)) {
                LinePixel (X1, Y1, DrawColor, Width, WriteMode);
            }
        }

    } else {
        DeltaX = 2 * DeltaX;
        Delta  = DeltaX - DeltaY;
        Step   = DeltaY;
        DeltaY = 2 * DeltaY;

        while (Step--) {

            // Neuen Punkt berechnen
            if (Delta > 0) {
                X1    += DirX;
                Delta -= DeltaY;
            }
            Delta += DeltaX;
            Y1    += DirY;

            // Punkt setzen
            if (RotatePattern (Pattern)) {
                LinePixel (X1, Y1, DrawColor, Width, WriteMode);
            }
        }
    }
}





static void pascal FillPoly (int far *PolyBuf, int Count)
// F�llt ein �bergebenes (geschlossenes) Polygon. PolyBuf enth�lt die
// Punkteliste, Count die Anzahl der Punkte. Am Ende des Puffers mu� noch
// Platz f�r den Linienpuffer sein.

{
    int far *Line;                      // Zeiger auf Linienpuffer
    int far *P1, far *P2;
    int LineCount;                      // Anzahl Punkte im Linienpuffer
    int MinY, MaxY;                     // Minimaler/Maximaler Y-Wert
    int X1, Y1, X2, Y2;                 // Aktuelle Linie des Polygons
    int DeltaY;                         // Steigung der Linie
    int I;



    // Die Liste durchsuchen und die maximalen und minimalen Y-Werte
    // feststellen. Der Performance halber in Assembler.
    // Die Werte werden zum Schlu� noch geclippt und nach MinY/MaxY
    // geschrieben
    asm     les     di, [PolyBuf]
    asm     mov     cx, [Count]
    asm     mov     bx, 7FFFh           // bx = MinY
    asm     mov     dx, 8000h           // dx = MaxY

L0: asm     mov     ax, WORD PTR es:[di+2]      // Y-Wert
    asm     cmp     bx, ax
    asm     jl      L1
    asm     mov     bx, ax
L1: asm     cmp     dx, ax
    asm     jg      L2
    asm     mov     dx, ax
L2: asm     add     di, 4
    asm     loop    L0

    asm     cmp     bx, [ClipY1]
    asm     jge     L3
    asm     mov     bx, [ClipY1]
L3: asm     cmp     dx, [ClipY2]
    asm     jle     L4
    asm     mov     dx, [ClipY2]
L4: asm     mov     [MinY], bx
    asm     mov     [MaxY], dx

    // Den Start der Linienliste berechnen
    Line = PolyBuf + (2 * Count);

    // Es wird eine Schleife von MinY bis MaxY durchlaufen, und die waagrechte
    // Linie die durch die Y-Koordinate gekennzeichnet ist, mit dem Polygon
    // geschnitten. Die entstehenden Schnittpunkte (es m�ssen nur deren X-Werte
    // festgehalten werden) werden gemerkt und dann aufsteigend sortiert.
    // Jeweils 2 dieser Punkte geben dann eine zu ziehende Linie an.
    // Die Linienliste wird mit P1 adressiert, die Polygonliste mit P2.

    // Los geht's
    while (MinY <= MaxY) {

        // Schneiden mit jeder Polygonlinie, es gibt eine Linie weniger als
        // Punkte, daher die 1 in der for-Schleife
        P2 = PolyBuf;                   // Zeiger auf Polygonliste
        P1 = Line;                      // Zeiger auf Linienpuffer
        LineCount = 0;                  // Anzahl Linienpunkte
        for (I = 1; I < Count; I++) {

            // Beide Punkte der zu untersuchenden Linie holen
            X1 = *(P2 + 0);
            Y1 = *(P2 + 1);
            X2 = *(P2 + 2);
            Y2 = *(P2 + 3);

            // Zeiger um einen Punkt weitersetzen
            P2 += 2;

            // Die Koordinaten so drehen, da� in Y1 der kleinere Y-Wert steht
            if (Y1 > Y2) {
                asm     mov     ax, [Y1]
                asm     xchg    ax, [Y2]
                asm     mov     [Y1], ax
                asm     mov     ax, [X1]
                asm     xchg    ax, [X2]
                asm     mov     [X1], ax
            }

            // Pr�fen ob die Linie geschnitten wird. Um zu vermeiden, da�
            // f�r den Schnittpunkt zweier Linien zweimal Punkte erzeugt
            // werden, erfolgt einer der folgenden Vergleiche mit =
            if ((MinY > Y1) && (MinY <= Y2)) {

                // Die Linie wird geschnitten - den Schnittpunkt berechnen. Hier
                // kann als Spezialfall auftreten, da� die Linie waagrecht ist, es
                // also keinen Schnittpunkt gibt. In diesem Fall gibt es eine
                // Schnittlinie. Deren Enden als Punkte eintragen.
                if ((DeltaY = (Y2 - Y1)) == 0) {

                    // Linie ist waagrecht
                    *P1++ = X1;
                    *P1++ = X2;
                    LineCount += 2;

                } else {

                    // Die Linie hat eine echte Steigung. X-Wert des
                    // Schnittpunktes rechnen. Das geht nach der Formel:
                    //
                    //                 X2 - X1                   X2 - X1
                    //  X =  (Y-Y1) * --------- + X1 = (Y-Y1) * --------- + X1
                    //                 Y2 - Y1                   DeltaY
                    //
                    // Das Ergebnis wird der Einfachheit halber in X1
                    // gespeichert.

                    asm     mov     ax, [X2]
                    asm     sub     ax, [X1]            // X2 - X1 in ax
                    asm     mov     dx, [MinY]
                    asm     sub     dx, [Y1]            // YMin - Y2 in dx
                    asm     imul    dx
                    asm     idiv    [DeltaY]
                    asm     add     [X1], ax

                    *P1++ = X1;
                    LineCount++;

                }

            }

        }

        // Alle Linien sind durchsucht und die X-Werte der Schnittpunkte
        // mit den Polygonlinien liegen im Puffer Line. LineCount gibt die
        // Anzahl der vorhandenen X-Werte an und ist immer gerade (aufgrund
        // der Tatsache das das Polygon geschlossen ist).

        // Die X-Werte werden jetzt aufsteigen sortiert. Dazu wird ein Quicksort
        // verwendet wenn es mehr als zwei Werte sind. Ansonsten wird der
        // zus�tzliche Overhead vermieden und direkt sortiert.
        if (LineCount) {

            if (LineCount == 2) {
                asm     les     bx, [Line]
                asm     mov     ax, WORD PTR es:[bx]
                asm     cmp     ax, WORD PTR es:[bx+2]
                asm     jl      L8
                asm     xchg    ax, WORD PTR es:[bx+2]
                asm     mov     WORD PTR es:[bx], ax
L8:
            } else {
                QuickSort (Line, LineCount);
            }


            // Jetzt immer zwei Werte nehmen und eine Linie ziehen
            P1 = Line;
            while (LineCount) {
                DrawFillLine (*P1, *(P1+1), MinY);
                P1 += 2;
                LineCount -= 2;
            }

        }

        // Sodele, n�chsten Y-Wert nehmen und weiter
        MinY++;

    }
}





static int pascal EllipseArc (int _ss *PolyBuf,
                              int StartAngle, int EndAngle,
                              WORD XRad, WORD YRad,
                              BOOLEAN CloseArc)
// Legt alle Punkte zur Erzeugung eines elliptischen Bogens mit den
// �bergebenen Werten in einem �bergebenen Puffer (PolyBuf) ab und liefert
// die Anzahl der Punkte im Puffer zur�ck. Wenn CloseArc TRUE ist und der
// Bogen nicht geschlossen ist (360� umfa�t), wird er durch Anfahren des
// Mittelpunktes an Anfang und Ende geschlossen. Dies dient dazu, ein
// geschlossenes Polygon f�r die Verwendung von FillPoly zu erzeugen und
// ist f�r die normalen B�gen via Arc oder Ellipse nicht notwendig.

{
    // Wenn beide Winkel gleich sind oder einer der Radien 0 --> tsch�� ...
    if ((EndAngle == StartAngle) || (XRad == 0) || (YRad == 0)) {
        return 0;
    }

    // Beide �bergebenen Winkel in den Bereich 0..359 bringen
    NormAngle (StartAngle);
    NormAngle (EndAngle);

    // Wenn der Endwinkel kleiner ist, diesen um 360 erh�hen
    if (EndAngle <= StartAngle) {
        EndAngle += 360;
    }

    // Falls der Bogen geschlossen werden soll, mu� gept�ft werden, ob
    // der Bogen volle 360� umfa�t oder nicht. Umfa�t er keine vollen
    // 360� und soll er geschlossen werden, so werden noch zwei Linien
    // (vom und zum Mittelpunkt) hinzugef�gt.
    BOOLEAN DoClose;
    if (CloseArc == TRUE) {
        if ((EndAngle - StartAngle) == 360) {
            DoClose = FALSE;
        } else {
            DoClose = TRUE;
        }
    } else {
        DoClose = FALSE;                // Als geschlossen ansehen
    }

    // Zeiger auf Puffer holen
    register int _ss *Buf = PolyBuf;

    // Falls nicht geschlossen, mit Mittelpunkt starten
    if (DoClose == TRUE) {
        *Buf++ = CursorX;
        *Buf++ = CursorY;
    }

    // Ellipse als Polygon nachbilden
    while (StartAngle <= EndAngle) {
        *Buf++ = CursorX + CosMul (StartAngle, XRad);
        *Buf++ = CursorY - SinMul (StartAngle, YRad);
        if (StartAngle != EndAngle) {
            if ((StartAngle += 3) > EndAngle) {
                StartAngle = EndAngle;
            }
        } else {
            // Beenden
            break;
        }
    }

    // Falls nicht geschlossen, mit Mittelpunkt enden
    if (DoClose == TRUE) {
        *Buf++ = CursorX;
        *Buf++ = CursorY;
    }

    // Anzahl der Punkte r�ckliefern (eigene Arithmetik, siehe qsort)
    return (Buf - PolyBuf) / 2;
}





static void pascal FillEllipse (int StartAngle, int EndAngle,
                                WORD XRad, WORD YRad)
// Erzeugt eine gef�lltes Ellipsenst�ck mit dem Mittelpunkt CursorX/CursorY,
// den Radien XRad und YRad.
{
    // Speicher belegen. F�llwinkel sind 3�, d.h. 360/3 + 2 Punkte maximal
    // zus�tzlich Linienpuffer, also 120*4+Reserve = 500 Bytes.
    int PolyBuf [250];

    // Ellipse erzeugen und f�llen
    FillPoly (PolyBuf, EllipseArc (PolyBuf, StartAngle, EndAngle, XRad, YRad, TRUE));
}




static void pascal DrawEllipse (int StartAngle, int EndAngle,
                                WORD XRad, WORD YRad, BOOLEAN Closed)
// Erzeugt einen elliptischen Kreisbogen mit dem Mittelpunkt CursorX/CursorY,
// den Radien XRad und YRad. Der Bogen wird zum Tortenst�ck gemacht, wenn der
// Parameter Closed TRUE ist.
{
    // Zuerst pr�fen ob beide Radien 0 sind. Wenn das der fall ist degeneriert
    // der Bogen zu einem Punkt.
    if (XRad == 0 && YRad == 0) {

        // Es handelt sich um einen Punkt
        LinePixel (CursorX, CursorY, DrawColor, LineWidth, COPY_PUT);

        // Und Ende danach
        return;

    }

    // Speicher belegen. F�llwinkel sind 3�, d.h. 360/3 + 2 Punkte maximal
    // zus�tzlich Linienpuffer, also 120*4+Reserve = 500 Bytes.
    int PolyBuf [250];

    // Ellipsenbogen erzeugen, kommt nach PolyBuf. Befehl nur Ausf�hren wenn
    // Punkte vorhanden
    int Count = EllipseArc (PolyBuf, StartAngle, EndAngle, XRad, YRad, Closed);
    if (Count > 0) {

        // Polygon zeichnen. Es ist eine Linie weniger als Punkte da sind,
        // daher die Abfrage --Count
        int _ss *Buf = PolyBuf;
        while (--Count) {
            DrawLine (*(Buf+0), *(Buf+1), *(Buf+2), *(Buf+3), 0xFFFF, LineWidth, COPY_PUT);
            Buf += 2;
        }

    }
}



/* ----------------------------- INITIALIZE ---------------------------- */
/*                                                                       */
/*      The initialize function is uset to enter the graphics mode.      */
/*      Once the kernal has established the mode, the Initialize         */
/*      call is used to execute the entry to graphics mode.              */
/*                                                                       */
/* ACHTUNG: INITIALIZE wird vom Kernel auch dann aufgerufen, wenn durch  */
/*          INIT ein Fehlercode gesetzt wurde. In diesem Fall sind die   */
/*          Vektoren nicht g�ltig belegt --> Nirwana.                    */
/*          Also unbedingt Fehlercode pr�fen                             */



void cdecl init ()
{
    // Durch Setzen des DIT-Flags dem Kernel mitteilen, da� der Bildschirm
    // nicht gel�scht werden darf.
    // Dieses Flag wird aufgrund eines (der vielen) Bugs im Grafik-Kernel
    // _vor_ Aufruf dieser Funktion ausgewertet, so da� das Setzen hier nicht
    // viel Sinn macht - ich mache es trotzdem, vielleicht gibt es ja mal eine
    // fehlerfreie Version...

    asm     mov     BYTE PTR [es:bx+1], 0A5h

    // Falls Fehlercode nicht OK --> direkt Ende
    if (Status.Stat != grOK) {
        return;
    }

    // Speicher belegen, Fehler pr�fen. In Install wurde bereits gekl�rt, ob
    // genug Speicher da ist.
    AllocateMemory ();
    if (Result != 0) {
        Status.Stat = grIOError;
        return;
    }

    // Palette initialisieren, erste 8 Eintr�ge wie beim DeskJet
    memcpy (RGBPal, RGBDefPal, sizeof (RGBDefPal));

    // Rest der Palette mit Graut�nen vorbesetzen
    register unsigned I = sizeof (RGBDefPal) / sizeof (RGBEntry);
    register RGBEntry near *P = &RGBPal [I];
    while (I < sizeof (RGBPal) / sizeof (RGBEntry)) {
        P->R = P->G = P->B = I;
        P++;
        I++;
    }

    // Sonstige Variable initialisieren
    ClipX1 = 0;
    ClipY1 = 0;
    ClipX2 = Status.XEfRes;
    MaxX   = Status.XEfRes + 1;
    ClipY2 = Status.YEfRes;
    MaxY   = Status.YEfRes + 1;

    // Speicher l�schen
    ClearMemory ();

    // Als letzte Rettung wird hier nochmals der Fehlerstatus getestet. Dies
    // kann unter Umst�nden bei File-I/O notwendig sein, falls zwischen der
    // Abfrage auf genug Speicher und dem L�schen (bei File-I/O = belegen)
    // der restliche Plattenplatz durch ein anderes Programm (z.B. unter
    // Windows) belegt wurde. In diesem Fall schl�gt die L�sch-Routine fehl,
    // weil Schreibfehler auftreten. Wichtig ist es dann aber, den allozierten
    // Speicher wieder freizugeben.
    if (Result != 0) {

        // Speicher freigeben
        DeallocateMemory;

        // Fehler setzen
        Status.Stat = grIOError;
    }

}

/* ----------------------------- CLEAR DEVICE -------------------------- */
/*                                                                       */
/*      The Clear Device call is used to ready the device for new        */
/*      output. This would be a clear screen on graphics hardware,       */
/*      formfeed on a printer or plotter, and a flush for file I/O.      */
/*                                                                       */

void cdecl clear ()
{
    /* Bild ausgeben */
    DSTPtr->Print ();

    /* Speicher l�schen */
    ClearMemory ();
}

/* ----------------------------- POST DEVICE --------------------------- */
/*                                                                       */
/*      The Post Device function is used to end the graphics output.     */
/*      This would be used to begin printing a page on a printer,        */
/*      set a graphics screen to visable, etc.                           */
/*                                                                       */

void cdecl post ()
{
    /* Bild ausgeben */
    DSTPtr->Print ();

    /* Speicher freigeben */
    DeallocateMemory ();

}

/* ----------------------------- MOVE TO ------------------------------- */
/*                                                                       */
/*      This function is used to move the current pointer (CP). The      */
/*      Current pointer is the system graphics cursor.                   */
/*                                                                       */

void cdecl move ()
{
    CursorX = _AX;
    CursorY = _BX;
}

/* ----------------------------- DRAW TO ------------------------------- */
/*                                                                       */
/*      Draw To is used to draw a line vector from the CP to the         */
/*      specified coordinate.                                            */
/*                                                                       */

void cdecl draw ()
{
    // Korrekte Parameter f�r vect aufsetzen
    asm     mov     cx, ax
    asm     mov     dx, bx
    asm     xchg    ax, [CursorX]
    asm     xchg    bx, [CursorY]

    // Interne Prozedur aufrufen, ACHTUNG: Funktioniert nur wenn DrawLine
    // als pascal deklariert ist !
    DrawLine (_AX, _BX, _CX, _DX, CurLineStyle, 1, WriteMode);
}

/* ----------------------------- VECT ---------------------------------- */
/*                                                                       */
/*      Vector is used to draw lines when the beginning and ending       */
/*      point are know. The parameters specify two vertices for          */
/*      drawing the desire line.                                         */
/*                                                                       */

void cdecl vect ()
{
    // Interne Prozedur aufrufen, ACHTUNG: Funktioniert nur wenn DrawLine
    // als pascal deklariert ist !
    DrawLine (_AX, _BX, _CX, _DX, CurLineStyle, 1, WriteMode);
}



/* ----------------------------- POLYGON ------------------------------ */
/*                                                                      */
/*  Wird aufgerufen mit:                                                */
/*        es:bx   Zeiger auf Punkteliste, wobei Teilpolygone mit        */
/*                Punktepaaren $8001/$8001 abgeschlossen werden und das */
/*                gesamte Polygon nochmals mit $8000/$8000.             */
/*                es:bx ist gleichzeitig der Zeiger auf den von GRAPH   */
/*                reservierten Speicherbereich (GraphBuf oder so), der  */
/*                auch f�r FloodFill benutzt wird. Am Ende der Liste    */
/*                ist daher Platz f�r eigene Variablen wenn auch nicht  */
/*                klar ist wieviel (im Normalfall aber 4KB, was bei dem */
/*                verwendeten Verfahren mehr als genug ist).            */
/*        ax      Anzahl der Punkte, wobei die Trenn- und Abschlu�punkte*/
/*                mitgez�hlt werden.                                    */
/*                                                                      */
/*  Die �bergebene Liste ist geschlossen, d.h. erster und letzter Punkt */
/*  eines Teilpolygons sind gleich.                                     */
/*                                                                      */


void cdecl polygon ()

{
    WORD Count;
    int far *ListPtr1, far *ListPtr2;
    register int far *P1;
    register int far *P2;
    int X1, Y1, X2, Y2;

    // Anzahl der Punkte merken (Bit 15 ist irgendein Flag in BP 7.0)
    asm    and     ax, 7FFFh
    asm    mov     [Count], ax

    // Zeiger auf die orginale Liste holen
    ListPtr1 = (int far *) MK_FP (_ES, _BX);

    // Die Liste der Punkte wird durchsucht und hinter die �bergebene
    // Liste nochmals ohne die von Graph eingef�gten Trennpunkte geschrieben.
    // ListPtr2 zeigt dann auf diese zweite Liste ohne Trennpunkte.
    // Bei dieser Gelegenheit wird auch direkt der kleinste und der gr��te
    // Y-Wert festgestellt
    P1 = ListPtr1;
    ListPtr2 = P2 = ListPtr1 + 2 * Count;
    Count    = 0;                       // Z�hler f�r Anzahl auf 0
    X2 = Y2 = (int) 0x8000;

    while (*P1 != (int) 0x8000) {

        // Punkt holen
        X1 = *P1++;
        Y1 = *P1++;

        // Pr�fen ob es sich nicht um eine Trennung zwischen zwei Teilpolygonen
        // handelt, und ob es sich nicht um denselben Punkt handelt wie den
        // zuvor (eine Spezialit�t von GRAPH ist es, zweimal denselben Punkt
        // einzuf�gen).

        if ((X1 == (int) 0x8001) || ((X1 == X2) && (Y1 == Y2))) {
            // Irgendein Kruscht: Punkt ignorieren
            continue;
        }

        // Punkt �bernehmen und als letzten verwendeten Punkte merken
        *P2++ = X2 = X1;
        *P2++ = Y2 = Y1;

        // es ist ein Punkt mehr
        Count++;

    }

    // Im Bereich, auf den ListPtr2 jetzt zeigt, liegt die korrigierte Liste
    // ohne die eingef�gten Trennpunkte. Count gibt die Anzahl der Punkte in
    // dieser Liste an. Das durch die Liste angegebene Polygon ist immer
    // geschlossen.
    // Zum F�llen des jetzt korrigierten Polygons wird jetzt eine eigene
    // Routine aufgerufen.
    FillPoly (ListPtr2, Count);

}



// =========================================================================
//
//         DW      FLOODFILL       ; Fill a bounded region using a flood fill
//
//   Input:
//      AX         The x coordinate for the seed point
//      BX         The y coordinate for the seed point
//      CL         The boundary color for the Flood Fill
//
//   Return:
//      Nothing      (Errors are returned in Device Status STAT field).
//
// This function is called to fill a bounded region on bitmap devices. The
// (X,Y) input coordinate is used as the seed point for the flood fill. (CP)
// becomes the seed point. The current FILLPATTERN is used to flood the
// region.
//

#if 0

int pascal ScanLeft (int X, int Y)
// Sucht nach links, bis entweder ein Pixel in Randfarbe oder die
// Grenze des Clip-Fensters erreicht ist. R�ckgabe ist das letzte zum
// Bereich geh�rige Pixel.
{
    while ((X >= ClipX1) && (DSTPtr->GetPixel (X, Y) != BorderColor)) {
        X--;
    }
    return X+1;
}



int pascal ScanRight (int X, int Y)
// Sucht nach rechts, bis entweder ein Pixel in Randfarbe oder die
// Grenze des Clip-Fensters erreicht ist. R�ckgabe ist das letzte zum
// Bereich geh�rige Pixel.
{
    while ((X <= ClipX2) && (DSTPtr->GetPixel (X, Y) != BorderColor)) {
        X++;
    }
    return X-1;
}





int pascal ScanDist (int X1, int X2, int Y)
// Sucht eine Linie zwischen zwei X-Werten ab, bis ein Punkt
// erreicht ist, der nicht der Randfarbe entspricht. Wird ein solcher
// Punkt gefunden, so kommt der X-Wert als Ergebnis zur�ck, sonst -1
// als X-Wert.
{
    while ((X1 <= X2) && (DSTPtr->GetPixel (X1, Y) == BorderColor)) {
        X1++;
    }
    return (X1 > X2) ? -1 : X1;
}





void pascal FillHoriz (int X, int Y)
// F�llen einer horizontalen Linie. Die Linie endet wenn ein Punkt der Randfarbe
// oder die Grenze des Clipfensters erreicht ist.
{
    DrawFillLine (X, ScanRight (X, Y), Y);
}





int ScanLine (int X1, int X2, int Y, int Dir)
// ScanLine. Bekommt einen Y-Wert und zwei X-Werte �bergeben. Sucht zwischen
// den beiden X-Werten und tr�gt alle Punkte, die nicht die Randfarbe enthalten
// in den Stack ein (bzw. den linken Punkte einer Linie).
// Ergebnis:     0 Stack�berlauf
//               1 alles ok
{
    while (X1 <= X2) {

        // Punkt != Randfarbe ?
        if (DSTPtr->GetPixel (X1, Y) != BorderColor) {

            // Pixel in den Stack eintragen
            if (StackPtr >= StackTop) {
                // Stack-�berlauf !
                Status.Stat = grNoFloodMem;
                return 0;
            }
            *StackPtr++ = (Dir >= 0) ? X1 : ~X1;
            *StackPtr++ = Y;

            // Und jetzt das Ende der Linie suchen (Erh�ht wird gleich..)
            X1 = ScanRight (X1, Y);

        }

        // Erh�ht auch das Ergebnis von ScanRight ...
        X1++;

    }

    // Ende wenn ok
    return 1;
}




int pascal CheckStack (int X, int Y, int Dir)
// Erh�lt eine Koordinate �bergeben und pr�ft, ob diese im Stack enthalten ist.
// Wenn ja wird sie gel�scht und das Ergebnis ist 1, wenn Nein passiert
// nichts und eine 0 kommt zur�ck.
{
    register WORD _ss * P = StackBot;

    if (Dir < 0) {
        X = ~X;
    }

    // Suchen
    while (P < StackPtr) {
        if ((*P == X) && (*(P+1) == Y)) {
            // Gefunden, l�schen durch verschieben
            StackPtr -= 2;
            while (P < StackPtr) {
                *(P+0) = *(P+2);
                *(P+1) = *(P+3);
                P += 2;
            }
            return 1;
        }
        P += 2;
    }

    // Nicht gefunden
    return 0;
}





int pascal Scan (int X, int Y)
{
    return 1;
}

/*************************************************************

;---------------------------------------------------------------------------
; Scan

PROC    Scan NEAR
ARG     X: WORD, Y: WORD        = ArgSize
LOCAL   CurY: WORD, CurXL: WORD, PrevXL: WORD, Dir: WORD, \
        NewXL: WORD, T: WORD = LocalSize


; Stackframe aufbauen

        EnterProc LocalSize
        push    di
        push    si

;

@@L0:   mov     ax, [Y]
        add     ax, [FillDir]
        mov     [CurY], ax
        cmp     ax, [Clip_Y1]
        jl      @@L1
        cmp     ax, [Clip_Y2]
        jg      @@L1
        mov     bx, [X]
        mov     [PrevXL], bx

        mul     [MaxX]                          ; dx:ax = CurY * MaxX
        add     bx, ax
        adc     dl, 0
        cmp     [Seg64], dl
        je      @@M1
        mov     [Seg64], dl
        call    [SegSelect]
@@M1:   mov     al, [BorderColor]
        cmp     al, [es:bx]
        je      @@L3

        mov     ax, [CurY]
        mov     bx, [X]
        call    ScanLeft
        jmp     @@L4
@@L3:   mov     ax, [CurY]
        mov     bx, [X]
        mov     cx, [CurrXR]
        call    ScanDist
        jc      @@L1

@@L4:   mov     [CurXL], bx
        mov     ax, [CurY]
        call    FillHoriz
        mov     ax, [CurXL]
        cmp     ax, [PrevXL]
        jge     @@L10
        xchg    si, ax                  ; si = CurXL
        mov     ax, [Y]
        mov     bx, si                  ; bx = CurXL
        call    ScanLeft
        cmp     bx, si
        jge     @@L8
        jmp     @@L6
@@L5:   mov     si, bx
        mov     ax, [Y]
        call    ScanLeft
@@L6:   cmp     bx, si
        jge     @@L7
        mov     si, bx
        mov     ax, [CurY]
        call    ScanLeft
        cmp     bx, si
        jl      @@L5
@@L7:   mov     dx, [FillDir]
        mov     ax, [CurY]
        mov     cx, [CurXL]
        dec     cx
        mov     bx, si
        call    ScanLine
        jc      @@L9
@@L8:   mov     dx, [FillDir]
        neg     dx
        mov     ax, [Y]
        mov     cx, [PrevXL]
        dec     cx
        mov     bx, si
        call    ScanLine
        jc      @@L9

@@L10:  mov     ax, [CurrXR]
        cmp     [PrevXR], ax
        je      @@L17
@@L11:  mov     ax, [FillDir]
        mov     [Dir], ax
        mov     bx, [PrevXR]
        mov     [NewXL], bx
        mov     ax, [CurrXR]
        mov     [PrevXL], ax
        cmp     [PrevXR], ax
        jle     @@L12
        xchg    bx, ax                  ; ax = PrevXL, bx = NewXL
        mov     [NewXL], bx
        mov     [PrevXL], ax
        mov     cx, [CurY]
        mov     [Y], cx
        neg     [Dir]
@@L12:  xchg    si, ax                  ; ax = PrevXL
        mov     ax, [Y]
        mov     bx, si
        call    ScanRight
        cmp     bx, si
        jle     @@L16
        mov     ax, [Y]
        add     ax, [Dir]
        mov     [T], ax

@@L13:  mov     si, bx
        mov     ax, [T]
        call    ScanRight
        cmp     bx, si
        jg      @@L15
@@L14:  mov     dx, [Dir]
        mov     ax, [Y]
        add     ax, dx                  ; ax += FillD
        mov     cx, si
        mov     bx, [PrevXL]
        inc     bx
        call    ScanLine
        jc      @@L9
        jmp     @@L16
@@L15:  mov     si, bx
        mov     ax, [Y]
        call    ScanRight
        cmp     bx, si
        jle     @@L14
        jmp     @@L13

@@L16:  mov     dx, [Dir]
        neg     dx
        mov     ax, [Y]
        mov     cx, si
        mov     bx, [NewXL]
        inc     bx
        call    ScanLine
        jc      @@L9
@@L17:  mov     bx, [CurXL]
        mov     [X], bx
        mov     ax, [CurY]
        mov     [Y], ax

        mov     cx, [FillDir]
        neg     cx
        call    CheckStack              ; ax = Y, bx = X
        jnc     @@L0                    ; N�chste Runde

; Ende mit Carry Clear

@@L1:   clc

; Einsprung mit gesetztem Carry

@@L9:   pop     si
        pop     di
        LeaveProc
        ret     ArgSize

ENDP    Scan


**********************************************************/


void cdecl floodfill ()
// Eigentliche FloodFill-Routine
//
// Der Eintritt erfolgt mit dem FloodFill-Stack, d.h. dem Puffer, der
// von GRAPH f�r FloodFill, FillPoly etc. reserviert ist und der vom
// Benutzer nach Bedarf vergr��ert werden kann. Der Linien-Stack wird
// auf diesen Stack gelegt, indem der Stackpointer nach StackTop kopiert
// wird. Der SP wird auf den Wert StackBot gesetzt (das sollte ein f�r
// das System einigerma�en hinreichender Wert sein, hier werden 512 Bytes
// gew�hlt. ACHTUNG: StackBot mu� durch 4 teilbar sein !!! (sonst Gefahr
// des unkontrollierten �berlaufs, da nicht f�r jedes Byte sondern nur alle
// viere der �berlauf getestet wird).
{
    register int X = _AX;
    register int Y = _BX;
    WORD OldStack;

    // Randfarbe direkt global merken
    BorderColor = _CL;

    // Pr�fen ob mindestens 100 Bytes an Puffer auf dem Stack
    // zur Verf�gung stehen
    if (_SP < ((WORD) StackBot + 100)) {
        Status.Stat = grNoFloodMem;      // Fehler setzen
        return;                          // Und Ende
    }

    // Puffer im Stackbereich korrekt setzen
    OldStack = _SP;                     // Aktuellen SP merken
    _SP = (WORD) StackBot;              // SP neu setzen
    StackPtr = (WORD _ss *) StackBot;   // Und als untere Stackgrenze nehmen
    StackTop = (WORD _ss *) (OldStack & 0xFFFC);// Oberes Ende des Stacks setzen

    // Variable initialisieren
    FillDir = -1;

    // Farbe am Startpunkt pr�fen. Wenn es direkt die Randfarbe ist --> Ende
    if (DSTPtr->GetPixel (X, Y) == BorderColor) {
        _SP = OldStack;
        return;
    }

    // So weit wie m�glich nach links gehen und diesen Punkt als Startpunkt
    // auf den Stack. Dann soweit wie m�glich (ohne auf den Rand zu sto�en)
    // nach rechts und diesen Punkt als rechtesten Punkt merken.
    CurrXR = ScanRight (X, Y);
    X  = ScanLeft (X, Y);
    *StackPtr++ = X;
    *StackPtr++ = Y;

    // F�ll-Schleife, Linien auf den Stack bis keine mehr da
    while (Scan (X, Y) == 0) {

        // Linien vom Stack und ziehen
        do {

            // Einen Wert vom Stack. Ende wenn Stack leer
            if (StackPtr == StackBot) {
                // Ende
                _SP = OldStack;
                return;
            }

            // Wert vom Stack holen, Direction extrahieren
            X = *--StackPtr;
            Y = *--StackPtr;
            if (X >= 0) {
                FillDir = 1;
            } else {
                X = ~X;
                FillDir = -1;
            }

            // Die Linie die auf dem Stack lag ziehen
            FillHoriz (X, Y);

            // Schleife so lange ausf�hren bis Punkt nicht mehr auf dem Stack
            // liegt
        } while (CheckStack (X, Y, -FillDir) != 0);

    }

    // Ende mit Stack-�berlauf
    _SP = OldStack;

}

#endif

void cdecl floodfill ()
{
}

/* ----------------------------- PATBAR -------------------------------- */
/*                                                                       */
/*      The patbar function is used to draw rectangles which are filled  */
/*      with the current drawing pattern. The parameters of PATBAR       */
/*      at the coordinates of the opposing corners of the bar.           */
/*                                                                       */

void cdecl patbar ()
{
    WORD X1, X2;

    // Ecken so tauschen, da� X1 <= X2 und Y1 <= Y2
    // Registerzuordnung ist ax=X1, bx=Y1, cx=X2, dx=Y2

    asm    cmp     ax, cx                 // X1 > X2 ?
    asm    jl      L1                     // Springe wenn Nein
    asm    xchg    ax, cx                 // Sonst tauschen
L1:
    asm    cmp     bx, dx                 // Y1 > Y2 ?
    asm    jl      L2                     // Springe wenn Nein
    asm    xchg    bx, dx                 // Sonst tauschen
L2:

    // Variable jetzt abspeichern
    asm    mov     [X1], ax
    asm    mov     di, bx                 // di ist Y1
    asm    mov     [X2], cx
    asm    mov     si, dx                 // si ist Y2

    // Rechteck f�llen
    while (_DI <= _SI) {
        DrawFillLine (X1, X2, _DI);
        _DI++;
    }

}

/* ------------------------------- ARC --------------------------------- */
/*                                                                       */
/*  Zeichnet einen umrandeten aber nicht gef�llten Ellipsen-Ausschnitt.  */

void cdecl arc ()
{
    // Variablen aus den Registern �bernehmen
    int StAngle  = _AX;
    int EndAngle = _BX;
    WORD XRad = _CX;
    WORD YRad = _DX;

    // High-Level Funktion verwenden, Bogen nicht schlie�en (kein Tortenst�ck)
    DrawEllipse (StAngle, EndAngle, XRad, YRad, FALSE);

}

/* ------------------------------ SECTOR ------------------------------- */
/*                                                                       */

// Zeichnet einen umrandeten, gef�llten Ellipsen-Ausschnitt.

void cdecl sector ()
{

    // Variablen aus den Registern �bernehmen
    int StAngle  = _AX;
    int EndAngle = _BX;
    WORD XRad = _CX;
    WORD YRad = _DX;

    // F�llen
    FillEllipse (StAngle, EndAngle, XRad, YRad);

    // Umranden, Bogen schlie�en
    DrawEllipse (StAngle, EndAngle, XRad, YRad, TRUE);

}

/* ---------------------------- ELLIPSE -------------------------------- */
/*                                                                       */

// Zeichnet eine ausgef�llte Ellipse mit den angegebenen Radien. Der Befehl
// kann nur ausgef�hrt werden, wenn die beiden Radien gleich sind, es sich
// also um einen gef�llten Kreis handelt, da der Plotter keinen Befehl
// f�r Ellipsen besitzt und die F�llung nur sehr schwer emuliert werden
// kann.
// Da die Register erhalten werden m�ssen, ist etwas Sorgfalt geboten...
//
// Input        ax = X-Radius
//              bx = Y-Radius
//

void cdecl ellipse ()
{
    // Variablen aus den Registern �bernehmen
    WORD XRad = _AX;
    WORD YRad = _BX;

    // High-Level Funktion verwenden
    FillEllipse (0, 360, XRad, YRad);

}

// ----------------------------- PALETTE -------------------------------
//
//         DW      PALETTE         ; Load a color entry into the Palette
//
//   Input:
//      ax         The index number and function code for load
//      bx         The color value to load into the palette
//
//   Return:
//      Nothing
//
// The PALETTE vector is used to load single entries into the palette. The
// register ax contains the function code for the load action and the index
// of the color table entry to be loaded. The upper two bits of ax determine
// the action to be taken. The table below tabulates the actions. If the
// control bits are 00, the color table index in (ax and 03FFFh) is loaded
// with the value in bx. If the control bits are 10, the color table index in
// (ax and 03FFFh) is loaded with the RGB value in (Red=bx, Green=cx, and
// Blue=dx). If the control bits are 11, the color table entry for the
// background is loaded with the value in bx.
//
//  Control Bits           Color Value and Index
//
//       00                Register bx contains color, ax is index
//       01                not used
//       10                Red=bx  Green=cx  Blue=dx, ax is index
//       11                Register bx contains color for background
//

void cdecl palette ()
// RGB Palette setzen, alles andere ignorieren
{
    asm and     ah, 0C0h
    asm cmp     ah, 080h                // Kommando 10?
    asm jnz     L9

    // Eintrag setzen
    asm lea     si, [RGBPal]
    asm mov     ah, 0
    asm add     si, ax
    asm add     si, ax                  // * 2
    asm add     si, ax                  // Index * 3
    asm mov     [si], bl                // Red
    asm mov     [si+1], cl              // Green
    asm mov     [si+2], dl              // Blue

L9: return;
}

// ----------------------------- COLOR ---------------------------------
// Kommt rein mit
//
//      al = Zeichenfarbe
//      ah = Hintergrundfarbe
//

void cdecl color ()
{

    asm mov     bx, [DSTPtr]
    asm mov     bx, [bx]. (_DST) ColorCount     // Anzahl Farben
    asm dec     bx                              // H�chste Farbnummer
    asm cmp     al, bl                          // Farbwert zu gro�?
    asm jbe     L1                              // Springe wenn Nein
    asm mov     al, bl                          // Sonst h�chste Farbnummer
L1: asm mov     [DrawColor], al
    asm cmp     ah, bl                          // Farbwert zu gro�?
    asm jbe     L2                              // Springe wenn Nein
    asm mov     ah, bl                          // Sonst h�chste Farbnummer
L2: asm mov     [FillColor], ah

}

/* ----------------------------- FILLSTYLE ----------------------------- */
/*                                                                       */
/*      The fill style function is used to set the interior style of     */
/*      the filled primatives.  The input to the function is the         */
/*      filled pattern style number, or a flag and a pointer to load     */
/*      an 8x8 bit pattern tile.                                         */
/*                                                                       */

void cdecl fillstyle ()
{
    asm cmp     al, 0FFh                // user-defined ?
    asm jz      L1                      // Springe wenn ja
    asm cbw                             // Nummer in ax
    asm xchg    ax, bx
    asm shl     bx, 1                   // * 8 (8 Bytes pro Eintrag)
    asm shl     bx, 1
    asm shl     bx, 1
    asm lea     bx, [FillPatternTable+bx]
    asm push    ds
    asm pop     es

L1: memcpy (FillPattern, MK_FP (_ES, _BX), sizeof (FillPattern));
}

/* ----------------------------- LINESTYLE ----------------------------- */
/*                                                                       */
/*      The line style command is used to set the style of the lines     */
/*      and borders of objects. The input to the fucntion is the line    */
/*      style number, of a flag and a 16 bit pattern for user defined    */
/*      line drawing styles.                                             */
/*                                                                       */

void cdecl linestyle ()
{
    // Linienbreite ist in cx
    LineWidth = _CX;

    // Linienpattern setzen
    if (_AL == 4) {
        CurLineStyle = _BX;
    } else {
        CurLineStyle = LineStyleTable [_AL];
    }
}

/* ----------------------------- TEXTSTYLE ----------------------------- */
/*                                                                       */
/*      The text style command is used to define the output font,        */
/*      text path, and text direction for font rendering.                */
/*                                                                       */

void cdecl textstyle ()
{
    TextNum    = _AL;
    TextOrient = _AH;

    // X und Y auf je 8 Pixel abrunden und daf�r sorgen, da� die Gr��e
    // mindestens 8 betr�gt. Das Ergebnis als Pixelgr��e merken.
    //
    // Alter C-Code:
    //
    //   if ((X &= 0x00F8) == 0) {
    //       X = 8;
    //   }
    //   TextSizeX = X;
    //
    //   if ((Y &= 0x00F8) == 0) {
    //       Y = 8;
    //   }
    //   TextSizeY = Y;
    //
    //   /* Jetzt die entsprechenden Multiplikatoren setzen (eigentlich redundant) */
    //   TextMultX = X >> 3;
    //   TextMultY = Y >> 3;

    asm     and     bx, 00F8h
    asm     jnz     L1
    asm     mov     bx, 8
L1: asm     mov     [TextSizeX], bx
    asm     shr     bx, 1
    asm     shr     bx, 1
    asm     shr     bx, 1
    asm     mov     [TextMultX], bx

    asm     and     cx, 00F8h
    asm     jnz     L2
    asm     mov     cx, 8
L2: asm     mov     [TextSizeY], cx
    asm     shr     cx, 1
    asm     shr     cx, 1
    asm     shr     cx, 1
    asm     mov     [TextMultY], cx

    // Ergebnis (d.h. tats�chliche Gr��e) in bx/cx zur�ckliefern
    _BX = TextSizeX;
    _CX = TextSizeY;

}

/* ------------------------------ TEXT --------------------------------- */
/*                                                                       */
/*      The text output command takes a string and renders the string    */
/*      on the output device. The input to the function is the text      */
/*      and the string length.                                           */
/*                                                                       */

static void pascal GetCharShape (unsigned char c)
/* Holt die zum Zeichen c passende Pixeldarstellung nach CharBuf */
{
  WORD Ofs, I;
  BYTE far *Vec;

  Ofs = ((WORD) c) << 3;       /* 8 Byte pro Zeichen */

  if (c >= 128) {
      /* ASCII >= 128, nachsehen ob der erweiterte Zeichensatz geladen ist */
#ifdef Ver3
      asm les     ax, [Int1F]
#else
      asm xor     ax, ax
      asm mov     es, ax
      asm les     ax, DWORD PTR [es:7Ch]
#endif
      asm mov     WORD PTR [Vec], ax
      asm mov     WORD PTR [Vec+2], es     /* Zeiger auf Zeichensatz speichern */

      if (Vec == NULL) {
        /* Der Zeiger ist ein NULL-Zeiger, kein erweiterter Zeichensatz da */
        Ofs = ((WORD) 0x20) << 3;                   // Leerzeichen nehmen
#ifdef Ver3
        Vec = (BYTE far *) MK_FP (SegF000, 0xFA6E); // Aus dem ROM-Zeichensatz
#else
        Vec = (BYTE far *) MK_FP (0xF000, 0xFA6E);  // Aus dem ROM-Zeichensatz
#endif
      } else {
          // Den Offset um 128 Zeichen erniedrigen, da Vec nur auf die hohen
          // 128 Chars zeigt
          Ofs -= (128 * 8);
      }
  } else {
      /* Zeichen ist normales ASCII, ROM-Zeichensatz nehmen */
#ifdef Ver3
      Vec = (BYTE far *) MK_FP (SegF000, 0xFA6E);
#else
      Vec = (BYTE far *) MK_FP (0xF000, 0xFA6E);
#endif
  }

  /* Den Zeichen-Offset addieren */
  Vec += Ofs;

  /* Die Pixeldarstellung holen */
  for (I = 0; I < 8; I++)
    CharBuf [I] = *Vec++;

  /* Falls notwendig mu� das Zeichen um 90� gedreht werden */
  if (TextOrient == 1) {
    /* Das Zeichen mu� gedreht werden */
    asm {
      mov     ax, WORD PTR [CharBuf+0]
      mov     bx, WORD PTR [CharBuf+2]
      mov     cx, WORD PTR [CharBuf+4]
      mov     dx, WORD PTR [CharBuf+6]          /* Zeichen holen */
      push    ds
      pop     es                                /* es = ds */
      mov     di, offset CharBuf                /* Dorthin wieder speichern */
      mov     [I], 8                            /* 8 Bits jeweils */
      cld                                       /* Direction Flag setzen */
    }
    L1: ;
    asm {
      /* Rotationsschleife */
      shr     al,1
      rcl     si,1
      shr     ah,1
      rcl     si,1
      shr     bl,1
      rcl     si,1
      shr     bh,1
      rcl     si,1
      shr     cl,1
      rcl     si,1
      shr     ch,1
      rcl     si,1
      shr     dl,1
      rcl     si,1
      shr     dh,1
      rcl     si,1
      xchg    ax,si
      stosb
      xchg    ax,si
      dec     WORD PTR [I]
      jnz     L1
    }
  }

}




static void pascal OutChar (unsigned char c)
// Gibt ein Zeichen an der aktuellen Cursorposition aus
{
    WORD XMult, YMult, XPixel, YPixel, X, Y;

    /* Zeichenposition gegen das Clip-Fenster pr�fen */
    if ((CursorX < ClipX1) || (CursorX > (ClipX2 - TextSizeX))) {
        return;
    }
    if ((CursorY < ClipY1) || (CursorY > (ClipY2 - TextSizeY))) {
        return;
    }

    /* Pixel-Darstellung des Zeichens nach CharBuf holen */
    GetCharShape (c);

    /* Y-Schleife */
    for (YPixel = 0, Y = CursorY; YPixel < 8; YPixel++) {

        for (YMult = 0; YMult < TextMultY; YMult++) {

            /* X-Schleife */
            for (XPixel = 0, X = CursorX; XPixel < 8; XPixel++) {

                if ((CharBuf [YPixel] & (0x80 >> XPixel)) != 0) {
                    /* Der Punkt mu� gesetzt werden */
                    for (XMult = 0; XMult < TextMultX; XMult++) {
                        DSTPtr->PutPixel (X++, Y, DrawColor, COPY_PUT);
                    }
                } else {
                    /* Punkt wird nicht gesetzt, einfach X erh�hen */
                    X += TextMultX;
                }

            }

            /* N�chste Y-Position */
            Y++;
        }
    }
}





void cdecl outtext ()
{
    WORD StrSeg, StrOfs, StrLen;
    unsigned char far *StringPtr;

    // Registerwerte speichern
    StrSeg = _ES;
    StrOfs = _BX;
    StrLen = _CX;

    /* Anfangsposition je nach Rotation unterscheiden */
    if (TextOrient == 1) {
        /* 90� gedreht, hinten am String anfangen */
        StringPtr = (char far *) MK_FP (StrSeg, StrOfs + StrLen - 1);
    } else {
        /* Normale Darstellung, vorne anfangen */
        StringPtr = (char far *) MK_FP (StrSeg, StrOfs);
    }


    while (StrLen--) {
        /* Zeichen ausgeben */
        OutChar (*StringPtr);

        /* Neue Cursorposition berechnen */
        if (TextOrient == 1) {
            /* 90� gedreht */
            CursorY += TextSizeY;
            StringPtr--;
        } else {
            CursorX += TextSizeX;
            StringPtr++;
        }
    }

}

/* ---------------------------- GETPIXEL  ------------------------------ */
/*                                                                       */
/*      This function is used to read a pixel from the screen.           */
/*      The function input is the coordinates of the pixel to be         */
/*      read.  The output from the function is the color of the          */
/*      pixel that was read.                                             */
/*                                                                       */

void cdecl getpixel ()
{
    _DL = DSTPtr->GetPixel (_AX, _BX);
}

/* ---------------------------- SETPIXEL  ------------------------------ */
/*                                                                       */
/*      This function is used to plot a pixel on the screen.             */
/*      the function input is the coordinates of the pixel to be         */
/*      plotted and the color value of the pixel.                        */
/*                                                                       */

void cdecl setpixel ()
{
    // Vorsicht: Tut nur wenn PutPixel als pascal deklariert ist !
    DSTPtr->PutPixel (_AX, _BX, _DX, COPY_PUT);
}


/* -------------------------------------------------------------------- */
/*                                                                      */
/*      The following defines the bit map utilities.                    */
/*                                                                      */
/*      These functions are accessed directly from the calling code,    */
/*      and are not process via the normal BGI Interface. Therefore,    */
/*      these routines must preserve the input data, and must be FAR    */
/*      functions.                                                      */
/*                                                                      */


static void far FarNopFunc ()
{
}



static void far putpix ()
// Write a pixel function
{
    // Erstmal Datensegment retten und auf das eigene setzen
    asm    push    ds
#ifdef Ver3
    asm    mov     ds, cs:[DataSeg]
#else
    asm    push    cs
    asm    pop     ds
#endif

    // PutPixel-Routine mit CopyPut als WriteMode aufrufen
    // VORSICHT: Tut nur wenn PutPixel als Pascal deklariert ist.
    DSTPtr->PutPixel (_AX, _BX, _DX, COPY_PUT);

    // Datensegment wiederherstellen
    asm    pop     ds                  /* Altes ds */
}


static void far getpix ()
// Read a pixel function
{
    // Erstmal Datensegment retten und auf das eigene setzen
    asm    push    ds
#ifdef Ver3
    asm    mov     ds, cs:[DataSeg]
#else
    asm    push    cs
    asm    pop     ds
#endif

    // GetPixel-Routine liefert Ergebnis in ax zur�ck
    _DL = DSTPtr->GetPixel (_AX, _BX);

    // Altes Datensegment und Ende
    asm    pop    ds
}




static void far bits_per_pixel ()
// returns the bits per pixel
{
    // Erstmal Datensegment retten und auf das eigene setzen
    asm push    ds
#ifdef Ver3
    asm mov     ds, cs:[DataSeg]
#else
    asm push    cs
    asm pop     ds
#endif

    // Wert nach ax holen
    asm mov     bx, [DSTPtr]
    asm mov     al, [bx]. (_DST) ColorBits
    asm mov     ah, 0

    // Altes Datensegment und Ende
    asm pop     ds
}



static void far set_write_mode ()
// Set the current write mode
{
    // Erstmal Datensegment retten und auf das eigene setzen
    asm push    ds
#ifdef Ver3
    asm mov     ds, cs:[DataSeg]
#else
    asm push    cs
    asm pop     ds
#endif

    // Wert merken
    asm and     al, 1
    asm mov     [WriteMode], al

    // Altes Datensegment und Ende
    asm pop     ds
}



/* ----------------------------- BITMAPUTIL --------------------------- */
/*                                                                      */
/*      This function returns the base of the bit manipulation utility  */
/*      table. The entry does not perform any function.                 */
/*                                                                      */

/*                                                                      */
/*      The following structure defines a utility function table.       */
/*                                                                      */

typedef void     (*NRFPTR)( void );     /* Pointer to Void/Void Funct   */

struct {
    NRFPTR  goto_graph;                   /* Enter graphics mode function */
    NRFPTR  exit_graph;                   /* Leave graphics mode function */
    NRFPTR  putpix;                       /* Write a pixel function       */
    NRFPTR  getpix;                       /* Read a pixel function        */
    NRFPTR  bits_per_pixel;               /* Bits per pixel value         */
    NRFPTR  set_page;                     /* Set the active drawing page  */
    NRFPTR  set_visual;                   /* Set the active display page  */
    NRFPTR  write_mode;                   /* Set the current write mode   */
} UtilityTable = {                      /* Bit Utilities Function Table */
    (NRFPTR) FarNopFunc,                  /* Enter graphics mode function */
    (NRFPTR) FarNopFunc,                  /* Leave graphics mode function */
    (NRFPTR) putpix,                      /* Write a pixel function       */
    (NRFPTR) getpix,                      /* Read a pixel function        */
    (NRFPTR) bits_per_pixel,              /* Bits per pixel function      */
    (NRFPTR) FarNopFunc,                  /* Set the active drawing page  */
    (NRFPTR) FarNopFunc,                  /* Set the active display page  */
    (NRFPTR) set_write_mode               /* Set the current write mode   */
};


void cdecl bitmaputil ()
{
    asm     push    ds
    asm     pop     es
    asm     mov     bx, OFFSET UtilityTable     // Zeiger in es:bx liefern

}

/* ---------------------------- RESTOREBITMAP -------------------------- */
/*                                                                       */
/*      The restore bit map function is used to load a retangular        */
/*      region from the host memory into the graphics memory. The        */
/*      input to the routine is the region to write, a pointer to        */
/*      the source in the host's memory, and the mode to use when        */
/*      writing the region.                                              */
/*                                                                       */

void cdecl restorebitmap ()
{

    BYTE far *BufPtr;        /* Zeiger auf Puffer */
    WORD X, Y;               /* Pixel-Z�hler */
    WORD X1, Y1, X2, Y2;
    BYTE Mode, BitMask, Color, ColorMask;

    // Werte aus den Registern merken
    Mode = _AL;
    X1   = _CX;
    Y1   = _DX;

    // Zeiger setzen
    asm     mov     WORD PTR [BufPtr], bx
    asm     mov     WORD PTR [BufPtr+2], es

    /* Erstes Wort (!) im Puffer ist Breite-1, zweites ist H�he-1 */
    X2      = X1 + *((WORD far *) BufPtr);
    BufPtr += 2;
    Y2      = Y1 + *((WORD far *) BufPtr);
    BufPtr += 2;

    BitMask = 0x80;                     /* Maske f�r gespeicherte Bits */

    for (Y = Y1; Y <= Y2; Y++) {
        for (X = X1; X <= X2; X++) {

            // N�chsten Punkt extrahieren
            Color = 0;
            for (ColorMask = (0x01 << (DSTPtr->ColorBits-1)); ColorMask != 0; ColorMask >>= 1) {
                if (*BufPtr & BitMask) {
                    Color |= ColorMask;
                }
                BitMask >>= 1;
                if (BitMask == 0) {
                    // N�chstes Byte
                    BufPtr++;
                    BitMask = 0x80;
                }
            }

            // Punkt ausgeben
            DSTPtr->PutPixel (X, Y, Color, Mode);
        }
    }
}

/* ---------------------------- SAVEBITMAP ----------------------------- */
/*                                                                       */
/*      The save bit map function is used to write a rectangular         */
/*      region from the graphics memory to the host memory. The input    */
/*      to the function is the region to be read, and a pointer to       */
/*      a save buffer in the host memory.                                */
/*                                                                       */

void cdecl savebitmap ()
{
    BYTE far *BufPtr;        /* Zeiger auf Puffer */
    WORD X, Y;               /* Pixel-Z�hler */
    WORD X1, Y1, X2, Y2;
    BYTE Bits, Color, ColorMask;

    // Werte aus den Registern merken
    X1   = _CX;
    Y1   = _DX;

    // Zeiger setzen
    asm     mov     WORD PTR [BufPtr], bx
    asm     mov     WORD PTR [BufPtr+2], es

    /* Erstes Wort (!) im Puffer ist Breite-1, zweites ist H�he-1 */
    X2      = X1 + *((WORD far *) BufPtr);
    BufPtr += 2;
    Y2      = Y1 + *((WORD far *) BufPtr);
    BufPtr += 2;

    Bits = 0;                /* gespeicherte Bits */

    for (Y = Y1; Y <= Y2; Y++) {

        for (X = X1; X <= X2; X++) {

            // Pixel holen
            Color = DSTPtr->GetPixel (X, Y);

            for (ColorMask = (0x01 << (DSTPtr->ColorBits-1)); ColorMask != 0; ColorMask >>= 1) {
                *BufPtr <<= 1;
                if (Color & ColorMask) {
                    *BufPtr |= 0x01;
                }
                if ((++Bits) == 8) {
                    /* Byte ist voll, n�chstes */
                    BufPtr++;
                    Bits = 0;
                }
            }
        }
    }
}

/* ---------------------------- SETCLIP -------------------------------- */
/*                                                                       */
/*      The setclip function defines a clipping rectangle on the         */
/*      output device.  The input to the function defines the            */
/*      coordinated of the opposing corners of the clipping rectangle.   */
/*                                                                       */
/*                                                                       */

void cdecl setclip ()
{
    ClipX1 = _AX;
    ClipY1 = _BX;
    ClipX2 = _CX;
    ClipY2 = _DX;
}

/* ---------------------------- TEXTSIZE ------------------------------- */
/*                                                                       */
/*      The textsize function allows the kernal to inquire the size      */
/*      of text strings. The input to the function is a pointer to       */
/*      text and the length of the string. The output is the horz        */
/*      and vert dimensions of the string in pixels.                     */
/*                                                                       */

void cdecl textsiz ()
{
    asm     mov     ax, [TextSizeX]
    asm     mul     cx                  // Gr��e eines Zeichens * L�nge
    asm     xchg    bx, ax              // ... nach bx
    asm     mov     cx, [TextSizeY]     // H�he nach cx
}



/* ---------------------------- COLOR_QUERY --------------------------- */
/*                                                                      */
/*      This function allows the kernal to inquire the size and base    */
/*      colors for the current device.                                  */
/*                                                                      */

void cdecl color_query ()
{
    asm     cmp     al, 0
    asm     jnz     L1
    asm     mov     bx, [DSTPtr]                // Zeiger auf aktuelle DST
    asm     mov     bx, [bx]. (_DST) ColorCount // Anzahl Farben in bx
    asm     mov     cx, bx
    asm     dec     cx                          // H�chste Farbnummer in cx
    asm     jmp     L2

L1: asm     cmp     al, 1
    asm     jnz     L2
    asm     push    ds
    asm     pop     es
    asm     lea     bx, [DefaultSettings]
L2:
}



/*****************************************************************************/
/* Initialisierungsfunktion, ruft die Initialisierungen der Module der Reihe */
/* nach auf.                                                                 */
/*****************************************************************************/

void InitBGI ()
{
    // Eigene Initialisierungen des Moduls
    Status.Stat = 0;            // Status r�cksetzen
}

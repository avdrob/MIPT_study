/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Enth�lt alle File-Funktionen. Wurden neu geschrieben, da die orginalen   */
/* C++-Funktionen zu viel Speicher ben�tigen, bzw. zu viel Hilfsfunktionen  */
/* eingebunden werden.                                                      */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: file.h 2.6 1995/04/28 16:20:22 Uz Exp $
//
// $Log: file.h $
// Revision 2.6  1995/04/28 16:20:22  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.5  95/04/22  17:28:32  Uz
// Variable errno rausgeschmissen, da bei Fehlern der genaue Fehlercode
// sowieso nicht ausgewertet wird.
//
// Revision 2.4  94/03/19  16:14:44  Uz
// Deklaration aller Funktionen als pascal zur Speicherersparnis
//
// Revision 2.3  93/08/01  20:53:19  Uz
// Neues Format mit DPMI-Support
//
//
//



#ifndef _FILE_H
#define _FILE_H



/****************************************************************************/
/*                           Konstanten f�r open()                          */
/****************************************************************************/



const BYTE fmRead       = 0;
const BYTE fmWrite      = 1;
const BYTE fmReadWrite  = 2;



/****************************************************************************/
/*                                   Code                                   */
/****************************************************************************/



int pascal open (char far *Name, BYTE Mode);
// �ffnet eine Datei. Zur�ckgegeben wird das Handle oder -1 bei Fehlern.

long int pascal filelength (int Handle);
// Gibt die L�nge einer Datei bzw. -1 bei Fehlern zur�ck

unsigned pascal read (int Handle, void far *Buffer, unsigned Count);
// Liest aus einer Datei. Liefert 0 zur�ck wenn ok, -1 bei Fehlern.

unsigned pascal write (int Handle, void far *Buffer, unsigned Count);
// Schreibt in eine Datei. Liefert 0 zur�ck, wenn ok, -1 bei Fehlern.

void pascal close (int Handle);
// Schliesst eine Datei



// Ende von FILE.H

#endif

/****************************************************************************/
/*                                                                          */
/*         LaserJet/DeskJet-Ausgaberoutinen f�r BGI-Druckertreiber          */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: lj.cpp 2.10 1995/04/28 16:20:46 Uz Exp $
//
// $Log: lj.cpp $
// Revision 2.10  1995/04/28 16:20:46  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.9  95/04/22  17:32:48  Uz
// Diverse �nderungen, Funktionen LaserPrint und LJPrint zusammengefasst,
// Anpassungen an ge�nderte Struktur von _DST und Support f�r DeskJet 1200C
// mit einstellbarer Palette.
//
// Revision 2.8  94/09/08  14:14:38  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.7  94/09/08  09:32:52  Uz
// Anpassung an extra modedata Modul.
//
// Revision 2.6  94/03/29  20:44:54  Uz
// str.h anstelle von string.h verwendet
//
// Revision 2.5  94/03/19  16:16:51  Uz
// Cleanup und Kosmetik.
//
// Revision 2.4  94/01/13  11:32:50  Uz
// Ausdruck erweitert um schaltbare Schwarzabtrennung
// f�r DeskJet 550C.
//
// Revision 2.3  93/08/01  20:53:05  Uz
// Neues Format mit DPMI-Support
//
//
//



#include "str.h"                // String-Funktionen
#include "const.h"
#include "util.h"               // Allgemeine Hilfsroutinen
#include "memory.h"             // Speicherverwaltung
#include "print.h"              // Ausgabe auf Drucker
#include "lj.h"                 // Eigene Deklarationen
#include "bgifunc.h"            // Grundlegende BGI-Funktionen
#include "jump.h"               // SetJump/LongJump
#include "alloca.h"



/****************************************************************************/
/*                   Controlstrings zur Ansteuerung des LJ                  */
/****************************************************************************/



// Drucker-Kontrollstrings
static char InitString [] =
    "\x1B""E"                           // Reset Printer
    "\x1B*rbC"                          // End Raster Graphics
    "\x1B&l26A"                         // Format: DIN A4
    "\x1B&l0o"                          // Portrait orientation
    "0L";                               // perf.-skip off

static char ColorString1 [] =
    "\x1B*r-3U";                        // 3 planes, CMY palette

static char ColorString2 [] =
    "\x1B*r-4U";                        // 4 planes, KCMY palette

static char ColorString3 [12] =
    "\x0B"                              // Stringl�nge
    "\x1B*v6W"                          // CID Command
    "\x00"                              // Device RGB
    "\x00"                              // Indexed by plane
    "\x00"                              // Bits/Index (wird sp�ter gesetzt)
    "\x08\x08\x08";                     // 8 Bits per Primary

static char Quality [3][6] = {
    "\x1B*r0Q",                         // Use keypad setting
    "\x1B*r1Q",                         // draft
    "\x1B*r2Q"                          // high
};

static char Shingling [3][6] = {
    "\x1B*o0Q",                         // None
    "\x1B*o1Q",                         // 25% (2 pass)
    "\x1B*o2Q"                          // 50% (4 pass)
};

static char Depletion [3][6] = {
    "\x1B*o1D",                         // None
    "\x1B*o2D",                         // 25% (default)
    "\x1B*o3D"                          // 50%
};

static char MediaType [5][6] = {
    "\x1B&l0M",                         // Plain paper
    "\x1B&l1M",                         // Bond paper
    "\x1B&l2M",                         // Special paper
    "\x1B&l3M",                         // Glossy film
    "\x1B&l4M"                          // Transparency film
};

static char StartGraphics [] =
    "\x1B*r0A";                         // Start graphics
//      "\x1B&a1N";                     // No negative motion (DeskJet 1200C)


// Steuerstring zur Einstellung der Palette.
static char RGBCompStr [] =
    "\x03"                              // Stringl�nge
    "\x1B*v";

// String der nach der Grafik geschickt wird.
static char EndGraphics [] =
    "\x1B*rbC"                          // Grafik-Ende
    "\x0C";                             // Papier-Auswurf

// Steuerstring f�r TIFF-Pacbits Kompression
static char Compression [] =
    "\x1B*b2M";

// Steuerstring f�r keine Kompression
static char NoCompression [] =
    "\x1B*b0M";

// Hier werden die Steuercodes f�r eine Zeile zusammengebaut.
static char PreBytes [25] =
    "\x1B*b";



/****************************************************************************/
/*                                                                          */
/*                 Kompressionspuffer und dessen Verwaltung                 */
/*                                                                          */
/****************************************************************************/

#define CompBufSize 600                 // 600 Bytes Puffer
static BYTE _ss *CompBuf;               // Zeiger auf Kompressionspuffer
static WORD CompBufFill = 0;            // Anzahl Zeichen im Puffer



static void inline ToBuf (BYTE B)
// Speichert das �bergebene Byte im Puffer wenn noch Platz ist. Der Z�hler
// wird auf jeden Fall hochgez�hlt, so da� sich sp�ter die theoretische Anzahl
// an Bytes im Puffer auf jeden Fall feststellen l��t.
{
    if (CompBufFill < (CompBufSize-1)) {
        // Platz ist da, speichern
        CompBuf [CompBufFill++] = B;
    }
}




static void _fastcall RepeatByte (register WORD Count, BYTE B)
// Speichert ein wiederholtes Byte im Kompressionspuffer, wobei Count die
// echte Anzahl ist und B das Byte. Der Z�hler wird auf Maximum �berpr�ft
// und eventuell auf zwei oder drei verteilt.
{
    register WORD RepeatCount;

    while (Count) {
        // Maximal k�nnen 128 Bytes am St�ck geschrieben werden, wobei
        // der Wert 0 einem Byte entspricht usw. 127 entsprechen 128 Byte
        RepeatCount = (Count > 128) ? 128 : Count;
        Count -= RepeatCount;

        // Byte schreiben
        ToBuf (-(RepeatCount-1));
        ToBuf (B);
    }
}




static void _fastcall MultiByte (WORD Count, char _ss *S)
// Speichert eine Folge von ungleichen Bytes im Kompressionspuffer, wobei
// Count die echte Anzahl ist und S ein Zeiger auf das erste Byte. Der
// Z�hler wird auf Maximum �berpr�ft und die komplette Anzahl wird
// evtl. auf mehrere Male rausgeschrieben.
{
    register WORD ByteCount;

    while (Count) {
        // Maximal k�nnen 128 Bytes am St�ck geschrieben werden, wobei der
        // Wert 0 einem Byte entspricht usw. 127 entsprechen 128 Byte
        ByteCount = (Count > 128) ? 128 : Count;
        Count -= ByteCount;

        // Bytefolge schreiben
        ToBuf (ByteCount-1);
        while (ByteCount--) {
            ToBuf (*S++);
        }
    }
}



static void _fastcall PrintNum (WORD W)
// Gibt das Wort W vorzeichenlos in ASCII auf den Drucker aus. Zur Wandlung
// wird der Kompressionspuffer verwendet!
{
    Num (W, CompBuf);
    PrintZString (CompBuf);
}



/****************************************************************************/
/*                                                                          */
/* Universelle Ausgaberoutine f�r den LaserJet/DeskJet/Color-DeskJet. Die   */
/* Routine f�hrt die Drucker-Initialisierung �ber den �bergebenen String    */
/* in Buf aus (der das passende Format haben mu�, also mit f�hrendem        */
/* L�ngenbyte) und druckt dann den Inhalt des Speichers. Es ist Farbe       */
/* m�glich (im DeskJet-Format), die passende Initialisierung mu� aber in    */
/* Buf stehen. Die Routine behandelt nur (falls vorhanden) die Planes       */
/* korrekt.                                                                 */
/* Da Buf sp�ter als Komprimierungs-Puffer verwendet wird, mu� er im Daten- */
/* segment liegen (sowieso weil Zeiger) und mindestens 600 Bytes gro� sein. */
/*                                                                          */
/* Die Routine wurde sp�ter noch erweitert um eine M�glichkeit, die Daten   */
/* auch gezwungenerma�en ohne Kompression rauszuschicken. Dabei wird der    */
/* Einfachheit halber die Zeile auch komprimiert, dann aber bei der         */
/* Abfrage, welcher Puffer k�rzer ist, gleichzeitig das Flag ausgewertet.   */
/* Die zus�tzliche Laufzeit wird hier in Kauf genommen, da diese Modi ja    */
/* wohl nur eine Notl�sung f�r Uralt-Drucker sein k�nnen.                   */
/*                                                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   Buf       wie oben beschrieben                                         */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  (keine)    bzw. hoffentlich ein Ausdruck...                             */
/*                                                                          */
/****************************************************************************/




void pascal LaserPrint ()
{

    WORD     X, Count, FullCount, Len, Plane, A, PlaneCount;
    BYTE     C, Y, M, B;
    BOOLEAN  SeparateBlack;


    // Handle auf "raw data" umstellen. Direkt Ende wenn Handle nicht Ok.
    // ACHTUNG: Ab hier Ausstieg mit return nicht mehr zul�ssig, es mu�
    // goto Exit verwendet werden.
    BYTE _ss *OutputBuf = alloca (PrintBufSize);
    if (InitPrinter (OutputBuf, PRNHandle) == FALSE) {
        return;
    }

    // Bytes pro (Plane-) Zeile berechnen
    WORD RowBytes = MaxY / 8;

    // Variablen-Init
    DWORD Abs = 0L;
    enum {Unknown, Compressed, NotCompressed} CompStatus = Unknown;

    // Dynamischen Speicher f�r die Puffer belegen
    BYTE _ss *Buf = alloca (600);
    CompBuf = alloca (CompBufSize);

    // Variable aus DST zwischenspeichern
    SeparateBlack = DSTPtr->SeparateBlack ();

    // Anzahl der Farb-Ebenen rechnen. Diese entspricht der Anzahl der
    // Farb-Bits mit Ausnahme der Modi mit Schwarz-Abtrennung, hier
    // kommt eine Plane dazu.
    PlaneCount = DSTPtr->ColorBits;
    if (SeparateBlack) {
        PlaneCount++;
    }

    // Vor Beginn der Druck-Ausgabe jetzt das Sprunglabel f�r Druckerfehler
    // setzen.
    if (SetJump (PrintAbortLabel) != 0) {
        // Fehler!
        goto ExitPoint;
    }

    // Ausgabe der Initialisierungs-Sequenzen
    PrintZString (InitString);
    if (DSTPtr->ColorCount == 8) {
        // DeskJet Farbe, Schwarz-Abtrennung hat 4 Ebenen, sonst 3
        PrintZString (DSTPtr->SeparateBlack () ? ColorString2 : ColorString1);
    } else if (DSTPtr->ColorCount > 8) {
        // Deskjet 1200C, Farbmodell und Palette setzen
        ColorString3 [8] = DSTPtr->ColorBits;
        PrintString (ColorString3);

        // Zeiger auf die Palette
        RGBEntry near *P = RGBPal;

        // Alle Eintr�ge setzen
        for (unsigned I = 0; I < DSTPtr->ColorCount; I++) {

            // Steuerstring zum Setzen des Eintrags
            PrintString (RGBCompStr);
            PrintNum (P->R);
            PrintByte ('a');
            PrintNum (P->G);
            PrintByte ('b');
            PrintNum (P->B);
            PrintByte ('c');
            PrintNum (I);
            PrintByte ('I');

            // N�chster Eintrag
            P++;
        }
    }

    PrintZString (((LJDST *) DSTPtr)->GraphicsOn);
    PrintZString (Quality [djQuality]);
    if (DSTPtr->ColorCount >= 8) {
        // Farb-Deskjets
        PrintZString (Shingling [djShingling]);
        PrintZString (Depletion [djDepletion]);
    }
    if (DSTPtr->ColorCount > 8) {
        // Nur Deskjet 1200C
        PrintZString (MediaType [djMediaType]);
    }
    PrintZString (StartGraphics);

    // Ausgabe beginnt
    for (X = 0; X < MaxX; X++) {

      // Daten f�r alle Ebenen ausgeben
      for (Plane = 1; Plane <= PlaneCount; Plane++) {

        // Bytes in den Kompressionspuffer lesen. Wenn es sich um einen Modus
        // mit Schwarz-Abtrennung handelt, wird die erste Plane aus den drei
        // anderen zusammengestellt, die Schwarz-Bits werden in den anderen
        // Planes gel�scht und zwar direkt im Bildschirmspeicher (problemlos,
        // weil nach dem Ausdruck die Zeichenfl�che leer ist).
        if (SeparateBlack && Plane == 1) {

            // Schwarz-Ebene zusammenstellen.
            for (Count = 0; Count < RowBytes; Count++, Abs++) {

                // Je ein Byte aus den drei Ebenen holen
                Y = *Map (Abs);
                C = *Map (Abs + RowBytes);
                M = *Map (Abs + 2 * RowBytes);

                // Wenn ein Bit in allen 3 Ebenen gesetzt ist, ist es schwarz
                asm     mov     al, [Y]
                asm     and     al, [C]
                asm     and     al, [M]
                asm     mov     [B], al               // Schwarz-Bits

                // Die Scharz-Bits in den drei Farb-Ebenen l�schen
                asm     not     al
                asm     and     [Y], al
                asm     and     [C], al
                asm     and     [M], al

                // Fertige 4 Ebenen speichern
                *Map (Abs + 2 * RowBytes) = M;
                *Map (Abs + RowBytes)     = C;
                *Map (Abs)                = Y;
                Buf [Count]               = B;

            }

            // Abs wieder zur�ckstellen
            Abs -= RowBytes;

        } else {

            // Es handelt sich um eine ganz normale Farb-Ebene...
            for (Count = 0; Count < RowBytes; Count++) {
                Buf [Count] = *Map (Abs++);
            }

        }

        // Pr�fen, wieviele Bytes am Ende des Puffers Null-Bytes sind
        asm    mov     cx, [RowBytes]
        asm    push    ss
        asm    pop     es
        asm    mov     di, [Buf]
        asm    dec     di
        asm    add     di, cx             // Zeigt hinter Pufferende
        asm    mov     al, 0
        asm    std
        asm    repe    scasb
        asm    je      L2                 // Springe wenn alles leer
        asm    inc     cx                 // Sonst Anzahl korrigieren
L2:     asm    mov     [FullCount], cx    // Restzahl merken


        // Versuchen die Zeile nach Algorithmus 2 (TIFF Pacbits) zu
        // komprimieren. Abgeschickt wird dann der k�rzere der beiden
        // Puffer.

        BYTE _ss *S = Buf;
        Count = FullCount;                // Anzahl zu pr�fender Bytes
        CompBufFill = 0;                  // Puffer ist leer
        while (Count) {
            // Erstes Byte holen
            B = *S++;
            Count--;
            A = 1;

            if (Count) {
                // Es kommen noch Bytes
                if (*S == B) {
                    // Das n�chste ist gleich, z�hlen wieviele gleiche kommen
                    while ((Count) && (*S == B)) {
                        A++;
                        Count--;
                        S++;
                    }
                    // Abschicken
                    RepeatByte (A, B);
                } else {
                    // Das n�chste ist ungleich, z�hlen wieviele ungleiche
                    // kommen
                    while ((Count) && (*S != B)) {
                        A++;
                        Count--;
                        B = *(S++);
                    }
                    // Wenn Count nicht 0 ist, dann sind die Bytes an Position
                    // S und S-1 gleich, k�nnen also beim n�chsten Durchgang
                    // mit einer RepeatByte-Sequenz dargestellt werden. In
                    // diesem Fall wird der letzte Durchgang wieder r�ckg�ngig
                    // gemacht.
                    if (Count) {
                        S--;
                        A--;
                        Count++;
                    }

                    // Abschicken
                    MultiByte (A, S-A);
                }

            } else {
                // Es kommen keine Bytes mehr, das letzte Byte als Einzelbyte
                // schicken
                MultiByte (1, S-1);
            }

        }


        // Sodele, den k�rzeren der beiden Puffer abschicken. Hier auch pr�fen
        // ob eine Kompression �berhaupt gew�nscht ist...
        if (CompBufFill < FullCount && DSTPtr->DoCompression ()) {
            // Der komprimierte Puffer ist k�rzer, Kontrollstring zur
            // Festlegung der Kompression senden, falls diese nicht
            // schon eingestellt ist.
            if (CompStatus != Compressed) {
                CompStatus = Compressed;
                PrintZString (Compression);
            }

            FullCount = CompBufFill;
            S         = CompBuf;
        } else {
            // Der unkomprimierte Puffer ist k�rzer, Kontrollstring zur
            // Festlegung der Kompression schicken, falls diese nicht
            // schon eingestellt ist.
            if (CompStatus != NotCompressed) {
                CompStatus = NotCompressed;
                PrintZString (NoCompression);
            }

            S = Buf;
        }

        // Die Steuersequenz f�r die nicht leeren Zeichen zusammenbauen. Beachten,
        // da� sich die letzte Plane in Code von den vorigen unterscheidet.
        Num (FullCount, &PreBytes [3]);
        Len = strlen (PreBytes);
        PreBytes [Len]   = (Plane == PlaneCount) ? 'W' : 'V';
        PreBytes [Len+1] = '\0';

        // Steuersequenz und dann die Zeichen senden
        PrintZString (PreBytes);

        // Puffer folgt
        PrintData (S, FullCount);

      }
    }

    // Das war's, Grafik beenden und Puffer leeren
    PrintZString (EndGraphics);
    Flush ();

    // Bei Fehlern geht's hier raus
ExitPoint:

    // Handle wieder in den Orginalzustand versetzen
    ResetPrinter ();
}




/****************************************************************************/
/*                                                                          */
/* Setzen eines Pixels an den �bergebenen X/Y-Koordinaten, in der           */
/* �bergebenen Farbe und im gew�nschten Schreib-Modus.                      */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*   Color      Farbe                                                       */
/*   WriteMode  Schreibmodus wie in const.h definiert                       */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  (keine)                                                                 */
/*                                                                          */
/****************************************************************************/




void pascal LJPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode)
// Eigene Funktion PutPixel f�r LaserJet, die XORMode ber�cksichtigt

{

    BYTE  far *BytePtr;
    BYTE  PixelMask;
    DWORD Abs;
    WORD  ColorBits;


    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return;
    }

    // Pixel-Adresse berechnen
    //
    // Alter C-Code:
    //
    // Abs = (LongMul ( (MaxX - X - 1) * (WORD) ColorBits, MaxY) + Y) / 8;
    // PixelMask = 0x80 >> (Y % 8);

    asm     mov     cx, [Y]                 // Merken im Register

    asm     mov     ax, [MaxX]
    asm     sub     ax, [X]
    asm     dec     ax                      // (MaxX - X - 1) in ax
    asm     mov     bx, [DSTPtr]            // Zeiger auf DST laden
    asm     mov     dl, [bx]. (_DST) ColorBits
    asm     mov     dh, 0
    asm     mov     [ColorBits], dx         // F�r sp�ter merken
    asm     mul     dx
    asm     mul     [MaxY]
    asm     add     ax, cx                  // + Y
    asm     adc     dx, 0
    asm     shr     dx, 1                   // / 8
    asm     rcr     ax, 1
    asm     shr     dx, 1
    asm     rcr     ax, 1
    asm     shr     dx, 1
    asm     rcr     ax, 1
    asm     mov     WORD PTR [Abs], ax
    asm     mov     WORD PTR [Abs+2], dx

    asm     mov     al, 80h
    asm     and     cl, 7
    asm     shr     al, cl
    asm     mov     [PixelMask], al

    // Die Bits f�r das Pixel liegen untereinander, jeweils durch MaxY Bytes
    // getrennt im Speicher. Nacheinander die Bits setzen
    while (ColorBits--) {

        // Speicher passend einblenden
        BytePtr = Map (Abs);

        // Bit setzen/l�schen
        switch (WriteMode) {

            case COPY_PUT:
                if (Color & 0x01) {
                    /* Pixel setzen */
                    *BytePtr |= PixelMask;
                } else {
                    /* L�schen */
                    *BytePtr &= ~PixelMask;
                }
                break;

            case XOR_PUT:
                /* XOR ist angesagt */
                if (Color & 0x01) {
                    /* Nur wenn Farbe = 1, sonst ist XOR wirkungslos */
                    *BytePtr ^= PixelMask;
                }
                break;

            case OR_PUT:
                /* OR-Operation, nur wirksam wenn Farbe */
                if (Color & 0x01) {
                    *BytePtr |= PixelMask;
                }
                break;

            case AND_PUT:
                /* AND-Operation, keine Wirkung wenn Farbe 1, L�schen wenn Farbe 0 */
                if ((Color & 0x01) == 0) {
                    *BytePtr &= ~PixelMask;
                }
                break;

            case NOT_PUT:
                /* Farbe invertieren */
                if (Color & 0x01) {
                    /* L�schen */
                    *BytePtr &= ~PixelMask;
                } else {
                    /* Pixel setzen */
                    *BytePtr |= PixelMask;
                }
                break;

            default:
                break;
        }

        // Puffer als Dirty markieren
        Dirty = TRUE;

        // Absolute Adresse auf die n�chste Plane weitersetzen
        Abs += (MaxY / 8);

        // N�chstes Farbbit verwenden
        Color >>= 1;

    }


}



/****************************************************************************/
/*                                                                          */
/* Holen eines Pixels von einer �bergebenen X/Y-Koordinate. Zur�ckgegeben   */
/* wird die Farbe.                                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  BYTE        Farbe                                                       */
/*                                                                          */
/****************************************************************************/




BYTE pascal LJGetPixel (WORD X, WORD Y)
/* Liefert die Farbe f�r den �bergebenen Punkt zur�ck */
{
    BYTE  PixelMask, Color, ColorMask;
    WORD ColorBits;
    DWORD Abs;

    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return (0);
    }

    // Pixel-Adresse berechnen
    //
    // Alter C-Code:
    //
    // Abs = (LongMul ( (MaxX - X - 1) * (WORD) ColorBits, MaxY) + Y) / 8;
    // PixelMask = 0x80 >> (Y % 8);

    asm     mov     cx, [Y]                 // Merken im Register

    asm     mov     ax, [MaxX]
    asm     sub     ax, [X]
    asm     dec     ax                      // (MaxX - X - 1) in ax
    asm     mov     bx, [DSTPtr]            // Zeiger auf DST holen
    asm     mov     dl, [bx]. (_DST) ColorBits
    asm     mov     dh, 0
    asm     mov     [ColorBits], dx         // F�r sp�ter speichern
    asm     mul     dx
    asm     mul     [MaxY]
    asm     add     ax, cx                  // + Y
    asm     adc     dx, 0
    asm     shr     dx, 1                   // / 8
    asm     rcr     ax, 1
    asm     shr     dx, 1
    asm     rcr     ax, 1
    asm     shr     dx, 1
    asm     rcr     ax, 1
    asm     mov     WORD PTR [Abs], ax
    asm     mov     WORD PTR [Abs+2], dx

    asm     mov     al, 80h
    asm     and     cl, 7
    asm     shr     al, cl
    asm     mov     [PixelMask], al

    // Die Bits f�r das Pixel liegen untereinander, jeweils durch MaxY Bytes
    // getrennt im Speicher. Nacheinander die Bits holen
    Color = 0;
    for (ColorMask = 0x01; ColorMask != (0x01 << ColorBits); ColorMask <<= 1) {

        // Speicher passend einblenden und direkt Bit testen
        if (*Map (Abs) & PixelMask) {
            Color |= ColorMask;               // Bit in Farbe �bertragen
        }

        // N�chste Plane adressieren
        Abs += (MaxY / 8);

    }

    return Color;

}






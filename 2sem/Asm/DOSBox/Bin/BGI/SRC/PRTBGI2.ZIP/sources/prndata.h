/******************************************************************************/
/*                                                                            */
/*                                 PRNDATA.H                                  */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// (C) 1994 Ullrich von Bassewitz
//
// $Id: prndata.h 1.3 1995/04/28 16:20:32 Uz Exp $
//
// $Log: prndata.h $
// Revision 1.3  1995/04/28 16:20:32  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 1.2  95/04/22  17:36:42  Uz
// Neuer Modus 41 f�r DeskJet 1200C.
//
// Revision 1.1  94/09/08  09:34:19  Uz
// Initial revision
//
//
//


#ifndef __PRNDATA_H
#define __PRNDATA_H



#include "bgifunc.h"



// Anzahl Druckermodi
const unsigned MaxModes = 42;

// Die Tabelle mit den Zeigern auf die Modi
extern _DST near *DSTTable [MaxModes];



// End of PRNDATA.H

#endif

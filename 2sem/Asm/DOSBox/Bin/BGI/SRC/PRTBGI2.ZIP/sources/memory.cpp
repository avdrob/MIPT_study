/****************************************************************************/
/*                                                                          */
/*            Virtuelle Speicherverwaltung f�r BGI-Druckertreiber           */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: memory.cpp 2.10 1994/03/30 00:19:32 Uz Exp $
//
// $Log: memory.cpp $
// Revision 2.10  1994/03/30 00:19:32  Uz
// Anpassung DPMI-Modus.
//
// Revision 2.9  94/03/29  20:44:28  Uz
// str.h anstelle von string.h verwendet
//
// Revision 2.8  94/03/29  13:31:03  Uz
// Nicht nach aussen sichtbare Funktionen als static markiert.
//
// Revision 2.7  94/03/28  12:59:06  Uz
// Fehler aus der Speicherbelegung entfernt: Aufgrund nicht korrekter
// Aufrundung traten sporadisch �berschreiber beim L�schen auf.
//
// Revision 2.6  94/03/19  16:24:05  Uz
// Fehlerhafte Log-Message bei r2.5, korrekt Log-Message w�re:
// Cleanup und Kosmetik.
//
// Revision 2.5  94/03/19  16:18:06  Uz
// Neues Modul, enth�lt alle Funktionen f�r Ausgabe auf Nadeldrucker.
//
// Revision 2.4  93/12/16  21:04:31  Uz
// Fehler in den XMS Kopier-Routinen behoben (CS-Override tut
// im Protected Mode nicht).
//
// Revision 2.3.1.1  93/08/01  20:57:51  Uz
// Versuchsweise neue Version, Cleanup gegen�ber 2.3 und etwas
// konsistenterer Aufbau
//
// Revision 2.3  93/08/01  20:53:11  Uz
// Neues Format mit DPMI-Support
//
//
//



#include <dir.h>
#include "const.h"
#include "str.h"
#include "util.h"
#include "heap.h"
#include "bgifunc.h"


/****************************************************************************/
/*                                                                          */
/*                               Variable                                   */
/*                                                                          */
/****************************************************************************/



#define BufBlockSize  2048              // 2 KB Puffer pro St�ck


// Verwaltungsdaten f�r EM, XM und F

BYTE          Result;                   // Ergebnis der letzten Operation, 0 = OK
BOOLEAN       Dirty;                    // TRUE wenn Puffer beschrieben wurde
WORD          Handle;                   // Handle f�r EMS, XMS, File
WORD          PageCount;                // Anzahl belegter Seiten
DWORD         Mem;                      // Ben�tigter Speicher
WORD          BufSize;                  // verwendete Puffergr��e

WORD          emFrame;                  // Segment des EMS-Frames
DWORD         dpmiHandle;               // Handle f�r DPMI-Speicher
WORD          SelectorInc;              // Additionskonstante f�r Selektoren
WORD          FirstSelector;            // Erster allozierter Selektor
BOOLEAN       UseDPMI;                  // TRUE wenn DPMI genutzt wird.
void far *    xmDispatch;               // Adresse des XMM-Dispatchers
char *        FileName;                 // Name der tempor�ren Datei


// Zeiger auf die Service-Routinen f�r EMS, XMS, File
void    pascal (*Allocate) (DWORD Mem); // Reserviert den Speicher
void    pascal (*CopyTo) (WORD Page, BYTE far *Buffer);
void    pascal (*CopyFrom) (WORD Page, BYTE far *Buffer);
void    pascal (*Deallocate) (void);    // Gibt den Speicher wieder frei


// Verwaltung von bis zu 4 Speicherbl�cken. Die Bl�cke
// werden nach einem LRU-Algorithmus verwaltet, wobei der erste Deskriptor
// jeweils auch den zuletzt referenzierten Speicherblock beschreibt. Die
// Alternative w�re eine doppelt verkettete Liste gewesen, aber bei wenigen
// Bl�cken d�rfte kopieren fast schneller (und vor allem �bersichtlicher)
// sein.

int MemBlockCount = 8;          // Anzahl der verwalteten Speicherbl�cke

struct MemBlock {
    BYTE far *  mb_BufPtr;      // Zeiger auf den Speicher
    WORD        mb_Page;        // Seite die der Block enth�lt
    BOOLEAN     mb_Dirty;       // TRUE wenn der Block Dirty ist
};

struct MemBlock _Block0 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block1 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block2 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block3 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block4 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block5 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block6 = { NULL, 0xFFFF, FALSE };
struct MemBlock _Block7 = { NULL, 0xFFFF, FALSE };

struct MemBlock near *MemDesc [8] = {
    &_Block0, &_Block1, &_Block2, &_Block3,
    &_Block4, &_Block5, &_Block6, &_Block7
};


/****************************************************************************/
/*                                Allgemeines                               */
/****************************************************************************/



static void pascal ClearBuffer (BYTE far *Buffer)
// L�scht den Puffer. Puffergr��e mu� gerade sein
{
    asm    les     di, Buffer
    asm    cld
    asm    mov     cx, [BufSize]
    asm    shr     cx, 1                // / 2
    asm    xor     ax, ax
    asm    rep     stosw
}




static void pascal SetBuffers ()
// Setzt die Zeiger auf die internen Puffer. Das mu� zur Laufzeit geschehen,
// weil erstens die Puffer vom Heap alloziert werden, zweitens die Information
// �ber den Inhalt von DS sowieso nicht verf�gbar w�re.
{
    register WORD I;

    MemBlockCount = 8;

    for (I = 0; I < 8; I++) {
        MemDesc [I]->mb_BufPtr = (BYTE _ds *) GetStatMem (BufBlockSize);
    }

}



/****************************************************************************/
/*                                EMM-Routinen                              */
/****************************************************************************/



static BOOLEAN pascal emAvail ()
{
    static char EMMCode [] = "EMMXXXX0";// Kennung des EMM

    asm    xor     ax, ax
    asm    mov     es, ax
    asm    les     di, es:[67h*4]       // Int-Vektor 67h holen
    asm    mov     ax, es
    asm    or      ax, di
    asm    jz      L1                   // Kein EMM

    // Kennung testen

    asm    mov     di, 10               // Offset ist 10h
    asm    lea     si, [EMMCode]
    asm    mov     cx, 8                // 8 Bytes vergleichen
    asm    cld
    asm    repe    cmpsb
    asm    jnz     L1                   // Code stimmt nicht

    // Kennung ist da, Version �berpr�fen (mindestens 3.2)

    asm    mov     ah, 46h              // Get Version
    asm    int     67h
    asm    cmp     al, 32h              // mindestens 3.2 ?
    asm    jb      L1                   // Nein, sorry

    // Segmentadresse holen

    asm    mov     ah, 41h
    asm    int     67h
    asm    mov     [Result], ah
    asm    mov     [emFrame], bx
    asm    or      ah, ah               // Fehler ?
    asm    mov     ax, 1                // Annehmen da� kein Fehler
    asm    jz      L2                   // Nein --> verf�gbar

    // Ende

L1: asm     xor     ax, ax
L2: return _AL;
}




static DWORD pascal emMemory ()
// Liefert das freie E-Memory in Bytes zur�ck
{
    asm    mov     ah, 42h
    asm    int     67h
    asm    mov     [Result], ah
    asm    mov     ax, 4000h            // Seitengr��e
    asm    mul     bx                   // * Anzahl Seiten
    return MK_DWORD (_DX, _AX);
}





static void pascal emAllocate (DWORD Mem)
// Alloziert die �bergebene Anzahl Bytes im EM

{
    // Bytes nach Seiten umrechnen
    asm    mov     bx, WORD PTR [Mem+2]
    asm    mov     ax, WORD PTR [Mem]
    asm    add     ax, 3FFFh
    asm    adc     bx, 0
    asm    shl     ax, 1
    asm    rcl     bx, 1
    asm    shl     ax, 1
    asm    rcl     bx, 1                // Anzahl 16KB-Bl�cke in bx

    asm    mov     ah, 43h
    asm    int     67h
    asm    mov     [Result], ah
    asm    mov     [Handle], dx         // Handle merken

    // Anstelle der internen Puffer die EMM-Seiten eintragen
    _Block0.mb_BufPtr = (BYTE far *) MK_FP (emFrame, 0x0000);
    _Block1.mb_BufPtr = (BYTE far *) MK_FP (emFrame, 0x4000);
    _Block2.mb_BufPtr = (BYTE far *) MK_FP (emFrame, 0x8000);
    _Block3.mb_BufPtr = (BYTE far *) MK_FP (emFrame, 0xC000);

    // Und 4 St�ck sind es
    MemBlockCount = 4;

}



static void pascal emDeallocate ()
{
    asm    mov     ah, 45h
    asm    mov     dx, [Handle]
    asm    cmp     dx, 0FFFFh                   // Handle ung�ltig ?
    asm    jne     L1                           // Springe wenn nein
    asm    mov     ah, 0                        // Ergebnis == ok
    asm    jmp     L2
L1: asm    int     67h
L2: asm    mov     [Result], ah
}



static void pascal emCopyTo (WORD Page, BYTE far *Buffer)
// Hat bei EMS keine Funktion, da die Daten bereits im EMS stehen
{
}




static void pascal emCopyFrom (WORD Page, BYTE far *Buffer)
// Blendet die passende EMS-Seite ein. Die physikalische Seite (0..3)
// steht dabei in den obersten 2 Bits des Buffer-Offsets.
{
    // Die physikalische Seite berechnen

L1: asm    mov     ax, WORD PTR [Buffer]
    asm    rol     ax, 1
    asm    rol     ax, 1
    asm    and     ax, 3

    // Seite einblenden

    asm    mov    ah, 44h
    asm    mov    bx, [Page]
    asm    mov    dx, [Handle]
    asm    int    67h

}



/******************** Zusammengefa�te EMS-Routinen *************************/

static BOOLEAN pascal emMemAvail (DWORD Mem)
/* Pr�ft ob ein EMM sowie die n�tige Menge Speicher vorhanden ist */
{
    return ((emAvail () && (emMemory () >= Mem)) ? TRUE : FALSE);
}



/****************************************************************************/
/*                                XMM-Prozeduren                            */
/****************************************************************************/


static BOOLEAN pascal xmAvail ()
// Testet auf die Pr�senz eines XMM. Ist einer vorhanden, so wird TRUE
// geliefert und die Aufrufadresse des XMM steht in XMM.
{
    asm    mov     ax, 4300h
    asm    int     2Fh
    asm    cmp     al, 80h                // XMM vorhanden ?
    asm    mov     ax, FALSE              // FALSE holen
    asm    jnz     L1                     // Springe wenn nicht vorhanden

    // Adresse des Funktionsdispatchers holen

    asm    mov     ax, 4310h
    asm    int     2Fh
    asm    mov     WORD PTR [xmDispatch], bx
    asm    mov     WORD PTR [xmDispatch+2], es

    // Version des Treibers holen. 2.0 ist Minimum

    asm    mov     ah, 00h
    asm    call    DWORD PTR [xmDispatch]
    asm    cmp     ah, 2
    asm    mov     ax, FALSE
    asm    jb      L1                     // Springe wenn Version < 2.00

    // Fertig, ax = TRUE

    asm    mov     ax, TRUE
L1: return _AL;
}




static DWORD pascal xmMemory ()
// Gibt die L�nge des gr��ten freien Blocks zur�ck
{
    asm    mov     ah, 08h
    asm    call    DWORD PTR [xmDispatch]  // Ergebnis ist in ax
    asm    mov     dx, 1024
    asm    mul     dx                      // Umrechnen KB --> Bytes
    return MK_DWORD (_DX, _AX);
}






static void pascal xmAllocate (DWORD Mem)
// Reserviert die �bergebene Anzahl Kilobytes im X-Memory.
{
    // Speicher aufrunden und nach KB umrechnen
    asm    mov     ax, WORD PTR [Mem]
    asm    mov     dx, WORD PTR [Mem+2]
    asm    add     ax, 1023
    asm    adc     dx, 0
    asm    mov     bx, 1024
    asm    div     bx                   // KB --> Bytes
    asm    xchg    ax, dx               // KB-Wert nach dx

    asm    mov     ah, 09h
    asm    call    DWORD PTR [xmDispatch]
    asm    or      ax, ax
    asm    jz      L1
    asm    mov     bl, 0                  // Kein Fehler, Code = 0
L1: asm    mov     [Result], bl
    asm    mov     [Handle], dx

    // Die internen Puffer eintragen.
    SetBuffers ();

}





static void pascal xmDeallocate ()
// Gibt den belegten Speicher wieder frei
{
    asm    mov     ah, 0Ah
    asm    mov     dx, [Handle]
    asm    cmp     dx, 0FFFFh                   // Handle g�ltig ?
    asm    je      L1                           // Springe wenn nein
    asm    call    DWORD PTR [xmDispatch]
    asm    or      ax, ax                       // XMM-Fehler ?
    asm    jz      L2                           // Springe wenn ja
L1: asm    mov     bl, 0                        // Fehlercode l�schen
L2: asm    mov     [Result], bl                 // Fehler eintragen

}



static void pascal xmCopyTo (WORD Page, BYTE far *Buffer)
// Kopiert den Puffer in das XMS zur�ck
{
    struct {
        DWORD       Len;                   // Blockl�nge
        WORD        SHandle;               // Handle Quelle (hier 0)
        BYTE  far * Source;                // Zeiger auf Puffer
        WORD        THandle;               // Handle Ziel
        DWORD       TOffset;               // Offset im XM
    } CopyStruc;

    // Die Request-Struktur ausf�llen
    CopyStruc.Len      = BufSize;
    CopyStruc.SHandle  = 0;
    CopyStruc.Source   = Buffer;
    CopyStruc.THandle  = Handle;
    CopyStruc.TOffset  = LongMul (Page, BufSize);

    // Den Block ins XM kopieren
    asm    push    ds                         // ds retten
    asm    push    ds
    asm    pop     es                         // es = ds
    asm    push    ss                         // CopyStruc liegt in ss
    asm    pop     ds                         // ds = ss
    asm    lea     si, [CopyStruc]            // Adresse jetzt in ds:si
    asm    mov     ah, 0Bh                    // Code f�r move block
    asm    call    DWORD PTR es:[xmDispatch]  // ds nicht verf�gbar
    asm    pop     ds                         // Datensegment wiederherstellen
    asm    or      ax, ax
    asm    jz      L1
    asm    mov     bl, 0                      // Fehlercode l�schen
L1: asm    mov     [Result], bl

}




static void pascal xmCopyFrom (WORD Page, BYTE far *Buffer)
// Kopiert die Seite vom XMS in den Puffer
{
    struct {
        DWORD       Len;                   // Blockl�nge
        WORD        SHandle;               // Handle Quelle
        DWORD       SOffset;               // Offset im XM
        WORD        THandle;               // Handle Ziel (hier 0)
        BYTE far *  Target;                // Zeiger auf Puffer
    } CopyStruc;

    // Die Request-Struktur ausf�llen
    CopyStruc.Len      = BufSize;
    CopyStruc.SHandle  = Handle;
    CopyStruc.SOffset  = LongMul (Page, BufSize);
    CopyStruc.THandle  = 0;
    CopyStruc.Target   = Buffer;

    // Den Block in den Puffer kopieren
    asm    push    ds                         // ds retten
    asm    push    ds
    asm    pop     es                         // es = ds
    asm    push    ss                         // CopyStruc liegt in ss
    asm    pop     ds                         // ds = ss
    asm    lea     si, [CopyStruc]            // Adresse jetzt in ds:si
    asm    mov     ah, 0Bh                    // Code f�r move block
    asm    call    DWORD PTR es:[xmDispatch]  // ds nicht verf�gbar
    asm    pop     ds                         // Datensegment wieder ok
    asm    or      ax, ax
    asm    jz      L1
    asm    mov     bl, 0                      // Fehlercode l�schen
L1: asm    mov     [Result], bl

}


/******************** Zusammengefa�te XMS-Routinen *************************/

static BOOLEAN pascal xmMemAvail (DWORD Mem)
/* Pr�ft ob ein XMM sowie die n�tige Menge Speicher vorhanden ist */
{
    return ((xmAvail () && (xmMemory () >= Mem)) ? TRUE : FALSE);
}



/****************************************************************************/
/*                             File-Prozeduren                              */
/****************************************************************************/


static void pascal SetResult ()
// Wird von den Maschinensprachen-Teilen aufgerufen nach einem Int21h und
// setzt Result auf 0 falls kein Fehler, ansonsten auf den Fehlercode.
// Kommt mit Carry Zur�ck wenn Fehler und ohne wenn keiner.
{
    asm    jc      L1                   // Springe wenn Fehler
    asm    mov     [Result], 0          // Fehlercode l�schen, Carry bleibt
    asm    jmp     L2                   // Ende ohne Carry
L1: asm    mov     [Result], al         // Ergebnis setzen
L2:
}




static DWORD pascal fMemory ()
// Gibt die Gr��e des freien Plattenplatzes zur�ck

{
    asm    mov     dl, 0                // Aktuelles Laufwerk
    asm    mov     ah, 36h              // Get disk free space
    asm    int     21h
    asm    cmp     ax, 0FFFFh           // Ung�ltiges Laufwerk ?
    asm    je      L1                   // Nein, g�ltig
    asm    mul     cx                   // Sectors/Cluster * Bytes/Sector
    asm    mul     bx                   // * available clusters
    asm    jmp     L2
L1: asm    xor     ax, ax               // ax = 0
    asm    cwd                          // dx:ax = 0
L2: return MK_DWORD (_DX, _AX);
}




static void pascal fAllocate (DWORD Mem)
//
// �ffnet ein tempor�res File auf Platte, wobei als Verzeichnis das
// aktuelle Verzeichnis verwendet wird. Mem wird ignoriert.
//
{
    WORD Len;

    // Speicher f�r den Filenamen belegen
    FileName = GetStatMem (MAXPATH + 1);


    // Das aktuelle Laufwerk holen und nach FileName schreiben,
    // Doppelpunkt und Backslash dahinter
    asm    mov     ah, 19h
    asm    int     21h
    asm    add     al, 'A'
    FileName [0] = _AL;
    FileName [1] = ':';
    FileName [2] = '\\';

    // Dann das aktuelle Verzeichnis holen und von MSDOS direkt hinter
    // dem Laufwerk eintragen lassen.
    asm    mov     si, [FileName]
    asm    add     si, 3
    asm    mov     dl, 0                  // Pfad f�r aktuelles Laufwerk
    asm    mov     ah, 47h
    asm    int     21h

    // An das Verzeichnis einen BackSlash anh�ngen, falls keiner da
    Len = strlen (FileName);
    if (FileName [Len-1] != '\\') {
        FileName [Len]   = '\\';
        FileName [Len+1] = '\0';
    }

    // Tempor�res File im aktuellen Verzeichnis erzeugen
    asm    mov     ah, 5Ah                  /* Create temporary file */
    asm    mov     cx, 2                    /* Read/Write */
    asm    mov     dx, [FileName]           /* Name dort speichern */
    asm    int     21h
    SetResult ();                           /* Fehler auswerten */
    asm    jc      L1                       /* Springe wenn Fehler */
    asm    mov     [Handle], ax             /* Handle speichern */
L1: ;

    // Die internen Puffer eintragen.
    SetBuffers ();

}




static void pascal fDeallocate ()
// Schlie�t und l�scht die Datei
{
    asm    mov     ah, 3Eh              // Close handle
    asm    mov     bx, [Handle]
    asm    cmp     bx, 0FFFFh           // Handle g�ltig ?
    asm    jz      L1                   // Springe wenn nein (C == 0)
    asm    int     21h                  // Fehler ignorieren
    asm    mov     ah, 41h              // Delete Directory Entry
    asm    mov     dx, [FileName]       // FileName in ds:dx
    asm    int     21h                  // Datei l�schen, Fehler ignorieren
L1: SetResult ();                       // Fehler auswerten

}




static void pascal fCopyTo (WORD Page, BYTE far *Buffer)
// Kopiert die Seite ins File
{
    asm    mov     ax, [BufSize]
    asm    mul     WORD PTR [Page]           // Position der Seite im File
    asm    xchg    ax, cx                    // Low Word nach cx
    asm    xchg    dx, cx                    // Position in cx:dx
    asm    mov     ax, 4200h                 // Move file pointer relativ to begin
    asm    mov     bx, WORD PTR [Handle]
    asm    int     21h                       // Seek
    SetResult ();                            // Fehler auswerten
    asm    jc      L1                        // Ende wenn Fehler

    asm    mov     cx, [BufSize]             // Anzahl zu schreibende Bytes
    asm    push    ds                        // Datensegment retten
    asm    lds     dx, DWORD PTR [Buffer]    // ds:dx zeigt auf Puffer
    asm    mov     ah, 40h                   // Write handle
    asm    int     21h                       // Handle ist noch in bx
    asm    pop     ds                        // Altes ds holen
    SetResult ();                            // Fehler auswerten
L1: ;
}



static void pascal fCopyFrom (WORD Page, BYTE far *Buffer)
// Kopiert eine Seite aus dem File in den Puffer
{
    asm    mov     ax, [BufSize]
    asm    mul     WORD PTR [Page]           // Position der Seite im File
    asm    xchg    ax, cx                    // Low Word nach cx
    asm    xchg    dx, cx                    // Position in cx:dx
    asm    mov     ax, 4200h                 // Move file pointer relativ to begin
    asm    mov     bx, WORD PTR [Handle]
    asm    int     21h                       // Seek
    SetResult ();                            // Fehler auswerten
    asm    jc      L1                        // Ende wenn Fehler

    asm    mov     cx, [BufSize]             // Anzahl zu lesende Bytes
    asm    push    ds                        // Datensegment retten
    asm    lds     dx, DWORD PTR [Buffer]    // ds:dx zeigt auf Puffer
    asm    mov     ah, 3Fh                   // Read handle
    asm    int     21h                       // Handle ist noch in bx
    asm    pop     ds                        // Altes ds auswerten
    SetResult ();                            // Fehler auswerten
L1: ;
}


/******************** Zusammengefa�te File-Routinen ************************/

static BOOLEAN pascal fMemAvail (DWORD Mem)
// Pr�ft ob genug Plattenplatz vorhanden ist
{
    return ((fMemory () >= Mem) ? TRUE : FALSE);
}




/****************************************************************************/
/*                              DPMI-Prozeduren                             */
/****************************************************************************/

#ifdef Ver3


inline BOOLEAN pascal dpmiAvail ()
{
    return (ProtMode);
}




static DWORD pascal dpmiMemory ()
// Liefert den verf�gbaren Speicher zur�ck.
{
    long Info [12];

    asm    push    ss
    asm    pop     es
    asm    lea     di, [Info]
    asm    mov     ax, 0500h
    asm    int     31h                  // Get Free Memory Information
    asm    jnc     L1
    asm    xor     ax, ax
    asm    cwd                          // Fehler: dx:ax = 0L
    asm    jmp     L2
L1: asm    mov     ax, WORD PTR [Info]
    asm    mov     dx, WORD PTR [Info+2]// dx:ax = verf�gbarer Speicher
L2: return MK_DWORD (_DX, _AX);

}





static void pascal dpmiAllocate (DWORD Mem)
// Alloziert die �bergebene Anzahl Bytes im DPMI
{
    unsigned long Base;

    asm    mov     bx, WORD PTR [Mem+2]
    asm    mov     cx, WORD PTR [Mem]
    asm    mov     ax, 0501h
    asm    int     31h                  // Allocate Memory Block
    asm    jnc     L1
    asm    mov     [Result], 1          // Fehler
    asm    jmp     L9                   // --> Ende

    // Handle speichern
L1: asm    mov     WORD PTR [dpmiHandle+2], si
    asm    mov     WORD PTR [dpmiHandle], di
    // Basisadresse speichern
    asm    mov     WORD PTR [Base+2], bx
    asm    mov     WORD PTR [Base], cx

    // Anzahl ben�tigter Selektoren rechnen und nach PageCount
    asm    mov     ax, WORD PTR [Mem+2]
    asm    cmp     WORD PTR [Mem], 0
    asm    je      L2
    asm    inc     ax
L2: asm    mov     [PageCount], ax

    // Den Wert f�r SelectorInc holen
    asm    mov     ax, 3
    asm    int     31h
    asm    mov     [SelectorInc], ax

    // Einen Rutsch Selektoren belegen und ersten Selektor nach bx
    asm    mov     ax, 0
    asm    mov     cx, [PageCount]
    asm    int     31h
    asm    mov     [FirstSelector], ax
    asm    xchg    ax, bx

    // Die Basisadressen und Limits der Selektoren setzen
    asm    mov     si, [PageCount]
L3: asm    mov     cx, WORD PTR [Base+2]
    asm    mov     dx, WORD PTR [Base]
    asm    mov     ax, 7
    asm    int     31h                  // Set Segment Base Address
    asm    xor     cx, cx
    asm    xor     dx, dx
    asm    cmp     si, 1                // Letzter Selektor ?
    asm    jnz     L4                   // Nein
    asm    mov     dx, WORD PTR [Mem]   // Ja, hat anderes Limit
L4: asm    dec     dx                   // Limit ist immer 1 Byte weniger
    asm    mov     ax, 8
    asm    int     31h                  // Set Segment Limit
    asm    add     bx, [SelectorInc]    // N�chster Selektor
    asm    inc     WORD PTR [Base+2]    // Basisadresse um 64KB h�her
    asm    dec     si                   // Fertig ?
    asm    jnz     L3

    // Fertig !
L9: return;

}



static void pascal dpmiDeallocate ()
{
    // Speicherblock freigeben
    asm    mov     si, WORD PTR [dpmiHandle+2]
    asm    mov     di, WORD PTR [dpmiHandle]
    asm    mov     ax, 0502h
    asm    int     31h

    // Selektoren wieder freigeben
    asm    mov     cx, [PageCount]
    asm    jcxz    L2
    asm    mov     bx, [FirstSelector]
    asm    mov     ax, 1
L1: asm    int     31h
    asm    add     bx, [SelectorInc]
    asm    loop    L1
L2: return;
}



/******************** Zusammengefa�te EMS-Routinen *************************/

static BOOLEAN pascal dpmiMemAvail (DWORD Mem)
/* Pr�ft ob DPMI sowie die n�tige Menge Speicher vorhanden ist */
{
    return ((dpmiAvail () && (dpmiMemory () >= Mem)) ? TRUE : FALSE);
}


#endif          /* Ver3 */




/****************************************************************************/
/*                                                                          */
/*             High-Level Routinen f�r die Speicherverwaltung.              */
/*                                                                          */
/****************************************************************************/



BYTE far * pascal Map (DWORD Abs)
// Blendet einen Speicherbereich f�r den Zugriff ein. Erh�lt eine absolute
// Adresse als Argument, zur�ck kommt ein Zeiger auf diese Adresse.
{
#ifdef Ver3
    // Bei DPMI gibt es eine Sonderbehandlung
    asm    cmp     [UseDPMI], FALSE
    asm    jz      L
    asm    mov     ax, WORD PTR [Abs+2]
    asm    mul     [SelectorInc]
    asm    add     ax, [FirstSelector]
    asm    xchg    ax, dx                       // Selektor nach dx
    asm    mov     ax, WORD PTR [Abs]           // Offset nach ax
    return (BYTE far *) MK_FP (_DX, _AX);
#endif

    // Aus der �bergebenen absoluten Adresse die Seite und den Offset in der
    // Seite rechnen
L:  asm     mov     ax, WORD PTR [Abs]
    asm     mov     dx, WORD PTR [Abs+2]
    asm     div     [BufSize]

    // Das globale Dirty-Flag in die aktuell benutzte Seite eintragen
    // Dirty-Flag r�cksetzen
    asm     lea     di, [MemDesc]
    asm     mov     bx, WORD PTR [di]           // bx = MemDesc [0];
    asm     mov     cl, FALSE
    asm     xchg    cl, [Dirty]                 // _CL = Dirty; Dirty = FALSE;
    asm     or      [bx].mb_Dirty, cl           // MemDesc [0]->Dirty |= Dirty;

    // Suchen ob die Seite schon eingeblendet ist.
    // Registerbelegung:
    //   ax =  Page
    //   bx =  MemDesc [0]
    //   dx =  Offset
    //   di -> MemDesc
    asm     mov     cx, [MemBlockCount]         // Anzahl nach cx

L0: asm     mov     bx, WORD PTR [di]           // bx = MemDesc [I]
    asm     cmp     ax, [bx].mb_Page            // Seite vorhanden ?
    asm     je      L2                          // Springe wenn ja

    // Seite nicht gefunden, n�chsten Block versuchen
    asm     inc     di
    asm     inc     di
    asm     loop    L0

    // Seite ist nicht eingeblendet. bx zeigt noch auf die letzte Seite.
    // Diese schmei�en. Dazu erst pr�fen, ob sie Dirty ist und zur�ck-
    // geschrieben werden mu�
    asm     cmp     BYTE PTR [bx].mb_Dirty, 00h // FALSE ?
    asm     je      L1

    // Block ist Dirty. R�ckschreiben
    asm     xchg    ax, si                      // Page retten
    asm     push    bx
    asm     push    dx
    CopyTo (((struct MemBlock near *) _BX)->mb_Page,
            ((struct MemBlock near *) _BX)->mb_BufPtr);
    asm     pop     dx
    asm     pop     bx
    asm     xchg    ax, si
    asm     mov     BYTE PTR [bx].mb_Dirty, 00h // Block->Dirty = FALSE;


    // Neue Seite in den Block eintragen
L1: asm     mov     [bx].mb_Page, ax

    // Block tats�chlich holen
    asm     push     bx                         // bx retten
    asm     xchg     dx, si                     // dx retten
    CopyFrom (_AX, ((struct MemBlock near *) _BX)->mb_BufPtr);
    asm     xchg     dx, si                     // dx holen
    asm     pop      bx                         // bx holen

    // Bl�cke aufrutschen und den letzten Block als ersten eintragen
    // Register:
    //   bx =  Block
    //   dx =  Offset
    //   di -> MemDesc [MemBlockCount]
    asm     dec     di
    asm     dec     di
    asm     mov     cx, [MemBlockCount]
    asm     dec     cx
    asm     jmp     L3                          // Aufrutschen, Zeiger holen

    // Seite gefunden. Seite an Position 0 vorr�cken. Pr�fen ob sich der
    // Block vielleicht schon an Position 0 befindet.
    // Registerbelegung beim Eintritt:
    //   bx -> gefundener Block
    //   cx =  Anzahl nicht gepr�fter Bl�cke - 1
    //   dx =  Offset
    //   di ->
L2: asm     sub     cx, [MemBlockCount]         // Noch voll ?
    asm     jz      L4                          // Steht schon an Pos. 0
    asm     neg     cx
L3: asm     mov     si, ds
    asm     mov     es, si                      // es = ds setzen
    asm     mov     si, di
    asm     dec     si
    asm     dec     si
    asm     std                                 // runterw�rts kopieren
    asm     rep     movsw
    asm     mov     WORD PTR [MemDesc], bx      // Block auf Pos 0 schreiben
    asm     cld                                 // Notwendig ??

    // einen Zeiger auf den Puffer r�ckliefern.
    // Register:
    //   bx -> Block
    //   dx =  Offset
L4: asm     add     dx, WORD PTR [bx.mb_BufPtr]
    asm     mov     ax, WORD PTR [bx.mb_BufPtr+2]
    asm     xchg    ax, dx

    return (BYTE far *) MK_FP (_DX, _AX);
}



/****************************************************************************/
/* L�schen des kompletten belegten Speichers.                               */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   keines.                                                                */
/*                                                                          */
/****************************************************************************/


void pascal ClearMemory ()
// L�scht den kompletten Speicher
{
    DWORD Abs;
    WORD Sel;
    register WORD  Page;

    if (UseDPMI) {

        // Sonderbehandlung f�r DPMI-Speicher. Anmerkung: Der DPMI-Speicher
        // besteht aus einer Folge von 64 KB Bl�cken, deren erster Selektor
        // in FirstSelector steht und deren weitere Selektoren durch Addition
        // von SelectorInc errechnet werden. Der letzte Block der Serie
        // ist evtl. keine 64 KB gro�.
        Abs = Mem;
        Sel = FirstSelector;
        // Volle 64 KB
        while (Abs >= 0x10000L) {
            asm cld
            asm mov     es, [Sel]
            asm xor     di, di
            asm mov     cx, 8000h
            asm xor     ax, ax
            asm rep     stosw
            asm mov     ax, es          // Selektor
            asm add     ax, [SelectorInc]
            asm mov     [Sel], ax
            asm dec     WORD PTR [Abs+2]
        }

        // Rest (wenn vorhanden)
        if (Abs) {
            asm mov     cx, WORD PTR [Abs]
            asm xor     di, di
            asm mov     es, [Sel]
            asm xor     ax, ax
            asm rep     stosb
        }

    } else {

        // Kein DPMI
        Abs = 0L;
        for (Page = 0; Page < PageCount; Page++, Abs += BufSize) {
            ClearBuffer (Map (Abs));
            Dirty = TRUE;
        }

    }

}



/****************************************************************************/
/* Initialisierung des Speichers. Pr�ft nach, ob eines der Speichermedien   */
/* gen�gend Speicher zur Verf�gung stellen kann, belegt aber den Speicher   */
/* nicht.                                                                   */
/*                                                                          */
/* Parameter:                                                               */
/*   MemSize            ben�tigte Speichergr��e in Bytes                    */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn gen�gend Speicher vorhanden ist.        */
/*   Au�erdem werden die Vektoren zum Ansprechen des Speichers korrekt      */
/*   gesetzt. Ist nicht ausreichend Speicher vorhanden, so wird Result auf  */
/*   -1 gesetzt.                                                            */
/*                                                                          */
/****************************************************************************/

void pascal InitMemory (DWORD MemSize)
{
    // Variable initialisieren
    Result = 0x00;            // Ergebnis der letzten Operation, 0 = OK
    Dirty = FALSE;            // TRUE wenn Puffer beschrieben wurde
    Handle = 0xFFFF;          // Handle f�r EMS, XMS, File
    PageCount = 0;            // Anzahl belegter Seiten
    BufSize = 0;              // verwendete Puffergr��e
    UseDPMI = FALSE;          // TRUE wenn DPMI genutzt wird.

    // Der Reihe nach die Speicherm�glichkeiten abpr�fen
#ifdef Ver3
    if ((ProtMode == FALSE) && (Mem = Round (MemSize, 0x4000), emMemAvail (Mem))) {
#else
    if (Mem = Round (MemSize, 0x4000), emMemAvail (Mem)) {
#endif
        // EMS verwenden
        Allocate    = emAllocate;
        CopyTo      = emCopyTo;
        CopyFrom    = emCopyFrom;
        Deallocate  = emDeallocate;
        BufSize     = 0x4000;           // 16 KB Seiten

#ifdef Ver3
    } else if ((ProtMode == FALSE) && (Mem = Round (MemSize, BufBlockSize), xmMemAvail (Mem))) {
#else
    } else if (Mem = Round (MemSize, BufBlockSize), xmMemAvail (Mem)) {
#endif
        // XMS verwenden
        Allocate    = xmAllocate;
        CopyTo      = xmCopyTo;
        CopyFrom    = xmCopyFrom;
        Deallocate  = xmDeallocate;
        BufSize     = BufBlockSize;     // Internen Puffer nehmen

#ifdef Ver3
    } else if ((ProtMode != FALSE) && (Mem = MemSize, dpmiMemAvail (Mem))) {

        // DPMI-Speicher verwenden
        Allocate    = dpmiAllocate;
        Deallocate  = dpmiDeallocate;
        BufSize     = 0;
        UseDPMI     = TRUE;
#endif

    } else if (Mem = Round (MemSize, BufBlockSize), fMemAvail (Mem)) {

        // Datei verwenden
        Allocate    = fAllocate;
        CopyTo      = fCopyTo;
        CopyFrom    = fCopyFrom;
        Deallocate  = fDeallocate;
        BufSize     = BufBlockSize;     // Internen Puffer nehmen

    } else {

        // Keine M�glichkeit zur Speicherung gefunden --> Fehler
        Result = 0xFF;

    }

    if (BufSize) {
        // Aus der Speichergr��e die ben�tigten Seiten berechnen. Durch die
        // oben jeweils durchgef�hrte Aufrundung geht der Wert genau durch
        // die Puffergr��e
        PageCount = LongDiv (Mem, BufSize);
    }

    // Ende

}






/****************************************************************************/
/* Belegen des Speichers. Kann nur aufgerufen werden, wenn zuvor            */
/* InitializeMem ohne Fehler durchgef�hrt wurde. Belegt den Speicher der    */
/* InitializeMem als Gr��e �bergeben wurde.                                 */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn der Speicher belegt werden konnte.      */
/*   Ansonsten wird Result auf einen Wert != 0 gesetzt.                     */
/*                                                                          */
/****************************************************************************/



void pascal AllocateMemory ()
{
    // Speicher belegen
    Allocate (Mem);
}



/****************************************************************************/
/* Freigeben des Speichers. Kann nur aufgerufen werden, wenn zuvor Speicher */
/* belegt wurde. Gibt den belegten Speicher komplett wieder frei.           */
/*                                                                          */
/* Parameter:                                                               */
/*   keine                                                                  */
/*                                                                          */
/* Ergebnis:                                                                */
/*   Result wird auf 0 gesetzt wenn der Speicher freigegeben werden konnte. */
/*   Ansonsten wird Result auf einen Wert != 0 gesetzt.                     */
/*                                                                          */
/****************************************************************************/


void pascal DeallocateMemory ()
{
    Deallocate ();
    Handle = 0xFFFF;
}





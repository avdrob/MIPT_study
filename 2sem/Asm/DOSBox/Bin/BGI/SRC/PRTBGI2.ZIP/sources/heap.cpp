/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Einfache Speicherverwaltung f�r BGI-Druckertreiber. Erlaubt das          */
/* tempor�re oder dauernde Belegen von Speicher bis hin zu einer bestimmten */
/* Maximalgrenze.                                                           */
/*                                                                          */
/* ACHTUNG: Die hier implementierte Speicherverwaltung ist _sehr_ einfach   */
/* gehalten. Das Ziel war mit wenig Overhead dynamisch Speicher belegen zu  */
/* k�nnen um die Gr��e des Treibers zu verkleinern. Da es um die Verwaltung */
/* von ca. 1KB an Speicher dreht, darf der Code zur Verwaltung nicht mehr   */
/* Overhead verursachen, als die paar Bytes, die eine dynamische Belegung   */
/* spart.                                                                   */
/*                                                                          */
/* Die "Verwaltung" besteht aus einem Block Speicher sowie zwei Zeigern,    */
/* von denen der eine die Spitze des dynamischen Bereichs markiert und der  */
/* zu Beginn auf den Start des Puffers zeigt, und der andere die Spitze     */
/* des statischen Bereichs, der Zeiger zeigt auf das Ende des Puffers.      */
/* Beide Zeiger wandern beim Belegen von Speicher aufeinander zu, es gibt   */
/* jedoch keine Vorkehrungen gegen Overflow etc., der Block Speicher mu�    */
/* gro� genug dimensioniert sein (was beim Treiber kein Probelm ist).       */
/* Der f�r die Verwaltung aufgewendete Code ist nahe 0, die Einsparung      */
/* (gegen�ber einer Deklaration aller Speicherbereiche als statisch wie     */
/* bisher) ist also deutlich.                                               */
/*                                                                          */
/* Die maximale Gr��e des ben�tigten Speichers betr�gt bisher:              */
/*                                                                          */
/* - Epson-Modi:                                                            */
/*   1 * Benutzermodus                  1 *  256  =   256                   */
/*                                                  ------                  */
/*                                                    256 Bytes             */
/*                                                                          */
/* - LaserJet-Modi:                                                         */
/*   RGB-Palette (DeskJet 1200C)        1 *  768  =   768                   */
/*                                                  ------                  */
/*                                                    768 Bytes             */
/*                                                                          */
/* - Allgemein:                                                             */
/*   Pfad f�r tempor�re Datei           1 *   80  =    80                   */
/*                                                 -------                  */
/*                                                     80 Bytes             */
/*                                                                          */
/*                                                                          */
/*   Summe (ohne tempor�r)                            848 Bytes             */
/*   -----                                                                  */
/*                                                                          */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: heap.cpp 2.7 1995/04/24 12:13:18 Uz Exp $
//
// $Log: heap.cpp $
// Revision 2.7  1995/04/24 12:13:18  Uz
// Gr��en�nderungen.
//
// Revision 2.6  95/04/22  17:30:56  Uz
// Funktion HeapAvail entfernt, GetStatMem ge�ndert, Heap vergr��ert.
//
// Revision 2.5  94/09/08  14:15:03  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.4  94/03/19  16:19:00  Uz
// Neue (bisher unbenutzte) Funktion HeapAvail.
//
// Revision 2.3  93/08/01  20:53:00  Uz
// Neues Format mit DPMI-Support
//
//
//



#include "const.h"




/****************************************************************************/
/*                                                                          */
/*                                   Variable                               */
/*                                                                          */
/****************************************************************************/

const HeapSize = 900;           // ANPASSEN !!! Siehe oben

static BYTE  Heap [HeapSize];   // Der zu vergebende Speicher

static BYTE *DynamicTop;        // Zeiger auf Spitze des dynamischen Bereichs
static BYTE *StaticTop;         // Zeiger auf Spitze des statischen Bereichs




/****************************************************************************/
/* Belegen von dynamischem Speicher. Die Bl�cke m�ssen in der umgekehrten   */
/* Reihenfolge der Belegung freigegeben werden (Stack-Anordnung).           */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des Speicherbereichs.                              */
/*                                                                          */
/* Ergebnis:                                                                */
/*   BYTE *        Zeiger auf angeforderten Bereich.                        */
/*                                                                          */
/****************************************************************************/

BYTE * _fastcall GetDynMem (WORD Size)
{
    register BYTE *P;

    P = DynamicTop;               // Aktuelle Spitze ist Zeiger
    DynamicTop += Size;           // Neue Spitze
    return P;
}



/****************************************************************************/
/* Freigeben von dynamischem Speicher. Die Bl�cke m�ssen in der umgekehrten */
/* Reihenfolge der Belegung freigegeben werden (Stack-Anordnung).           */
/* Es wird eine Gr��e anstatt eines Zeigers �bergeben, dann spielt die      */
/* Reihenfolge der Freigabe zweier (oder mehrerer) Bereiche keine Rolle,    */
/* solange nur immer alle zusammen belegt bzw. freigegeben werden.          */
/*                                                                          */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des freizugebenden Blocks.                         */
/*                                                                          */
/* Ergebnis:                                                                */
/*   (keins)                                                                */
/*                                                                          */
/****************************************************************************/

void _fastcall FreeDynMem (WORD Size)
{
    DynamicTop -= Size;
}



/****************************************************************************/
/* Belegen von statischem Speicher. Ist der gew�nschte Block gr��er als     */
/* 512 Bytes, so wird er auf einer Doppelwortgrenze aligned (zwecks 386-    */
/* Copy bei XMS und File unter Windows und OS/2).                           */
/*                                                                          */
/* ACHTUNG: Es erfolgen keinerlei �berpr�fungen auf Overflow usw. !         */
/*                                                                          */
/* Parameter:                                                               */
/*   Size          Gr��e des Speicherbereichs.                              */
/*                                                                          */
/* Ergebnis:                                                                */
/*   BYTE *        Zeiger auf angeforderten Bereich.                        */
/*                                                                          */
/****************************************************************************/

BYTE * _fastcall GetStatMem (WORD Size)
{
    StaticTop -= Size;
    if (Size > 512) {
        // Adresse auf 4-er Grenze nach unten runden
        return (BYTE *) ((WORD) StaticTop &= 0xFFFC);
    } else {
        // F�r kleinere Bl�cke tut's ein beliebiger Block
        return (StaticTop);
    }
}






/****************************************************************************/
/* Initialisierung des Heaps. Mu� durch eine eigene Funktion durchgef�hrt   */
/* werden, da keine statischen Variablen benutzt werden k�nnen (geht schief */
/* wenn der Treiber als OBJ-Datei eingebunden wird und mehrmals             */
/* initialisiert wird).                                                     */
/*                                                                          */
/* Parameter:                                                               */
/*   (keine)                                                                */
/*                                                                          */
/* Ergebnis:                                                                */
/*   (keins)                                                                */
/*                                                                          */
/****************************************************************************/

void pascal InitHeap ()
{
    DynamicTop = Heap;                // Zeiger auf Spitze des dynamischen Bereichs
    StaticTop  = &Heap [HeapSize];    // Zeiger auf Spitze des statischen Bereichs
}


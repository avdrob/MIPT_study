/******************************************************************************/
/*                                                                            */
/*                                 PCXDATA.H                                  */
/*                                                                            */
/*  (C) 1994 by Ullrich von Bassewitz                                         */
/*              Zwehrenb�hlstra�e 33                                          */
/*              72070 T�bingen                                                */
/*                                                                            */
/*  E-Mail:     uz@ibb.schwaben.de                                            */
/*                                                                            */
/******************************************************************************/



//
// (C) 1995 Ullrich von Bassewitz
//
// $Id: pcxdata.h 1.1 1995/04/28 16:20:37 Uz Exp $
//
// $Log: pcxdata.h $
// Revision 1.1  1995/04/28 16:20:37  Uz
// Initial revision
//
//
//


#ifndef __PCXDATA_H
#define __PCXDATA_H



#include "bgifunc.h"



// Anzahl Druckermodi
const unsigned MaxModes = 10;

// Nummer des benutzerdefinierten Modus
const unsigned UserMode = 9;

// Die Tabelle mit den Zeigern auf die Modi
extern _DST near *DSTTable [MaxModes];



// End of PCXDATA.H

#endif

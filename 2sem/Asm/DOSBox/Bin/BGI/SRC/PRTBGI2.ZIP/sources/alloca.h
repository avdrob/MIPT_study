/*****************************************************************************/
/*                                                                           */
/*                                 ALLOCA.H                                  */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: alloca.h 1.1 1995/04/28 16:20:08 Uz Exp $
//
// $Log: alloca.h $
// Revision 1.1  1995/04/28 16:20:08  Uz
// Initial revision
//
//
//



#ifndef _ALLOCA_H
#define _ALLOCA_H



#include "const.h"



/*****************************************************************************/
/*                                   Code                                    */
/*****************************************************************************/



BYTE _ss * pascal alloca (unsigned Size);
// Setzt ein Sprunglabel.



// Ende von ALLOCA.H

#endif

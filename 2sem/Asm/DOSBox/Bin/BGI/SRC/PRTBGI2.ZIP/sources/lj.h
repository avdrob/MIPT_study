/****************************************************************************/
/*                                                                          */
/*         LaserJet/DeskJet-Ausgaberoutinen f�r BGI-Druckertreiber          */
/*                                                                          */
/****************************************************************************/



//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: lj.h 2.6 1995/04/22 17:26:26 Uz Exp $
//
// $Log: lj.h $
// Revision 2.6  1995/04/22 17:26:26  Uz
// �nderungen an LJDST, diverse BOOLEANs gegen ein bitmapped Flag Byte
// getauscht.
//
// Revision 2.5  94/09/08  09:33:44  Uz
// Anpassung an extra modedata Modul.
//
// Revision 2.4  94/01/13  11:33:25  Uz
// Ausdruck erweitert um schaltbare Schwarzabtrennung
// f�r DeskJet 550C.
//
// Revision 2.3  93/08/01  20:53:17  Uz
// Neues Format mit DPMI-Support
//
//
//



#ifndef _LJ_H
#define _LJ_H

#include "bgifunc.h"


/****************************************************************************/
/*                                                                          */
/*  Die folgende Struktur enth�lt f�r den LaserJet angepassten Device-      */
/*  Status Block.                                                           */
/*                                                                          */
/****************************************************************************/


struct LJDST {

    _DST        DST;            // Orginal-DST
    char        *GraphicsOn;    // Grafik einschalten (mit Init)

};




/****************************************************************************/
/*                            Zeichen-Prozeduren                            */
/****************************************************************************/


void pascal LaserPrint ();
// Ausgaberoutine f�r LaserJet/DeskJet



/****************************************************************************/
/*                                                                          */
/* Setzen eines Pixels an den �bergebenen X/Y-Koordinaten, in der           */
/* �bergebenen Farbe und im gew�nschten Schreib-Modus.                      */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*   Color      Farbe                                                       */
/*   WriteMode  Schreibmodus wie in const.h definiert                       */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  (keine)                                                                 */
/*                                                                          */
/****************************************************************************/

void pascal LJPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode);



/****************************************************************************/
/*                                                                          */
/* Holen eines Pixels von einer �bergebenen X/Y-Koordinate. Zur�ckgegeben   */
/* wird die Farbe.                                                          */
/*                                                                          */
/* Parameter:                                                               */
/*   X, Y       Koordinaten                                                 */
/*                                                                          */
/* Ergebnisse:                                                              */
/*  BYTE        Farbe                                                       */
/*                                                                          */
/****************************************************************************/

BYTE pascal LJGetPixel (WORD X, WORD Y);



//
// Ende von LJ.H
//

#endif

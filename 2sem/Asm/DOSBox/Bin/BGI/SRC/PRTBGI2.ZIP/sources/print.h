/****************************************************************************/
/*                                                                          */
/*              Modul f�r BGI-Treiber zum Ansprechen des Druckers           */
/*                                                                          */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: print.h 2.5 1995/04/28 16:19:59 Uz Exp $
//
// $Log: print.h $
// Revision 2.5  1995/04/28 16:19:59  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.4  95/04/22  17:36:05  Uz
// Neue Funktionen zum Ausgeben von Daten, PrintZString, PrintData.
// Existierende Funktionen f�r die Benutzung der neuen angepasst.
//
// Revision 2.3  93/08/01  20:53:30  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _PRINT_H
#define _PRINT_H



#include "const.h"
#include "jump.h"



/*****************************************************************************/
/*                                   Data                                    */
/*****************************************************************************/



// Diverse Handles
const unsigned PCXHandle        = 3;
const unsigned PRNHandle        = 4;

// Gr��e des Ausgabepuffers
const unsigned PrintBufSize = 1024;

// Sprunglabel, das bei Fehlern bei der Ausgabe angesprungen wird.
extern JumpBuf PrintAbortLabel;



/*****************************************************************************/
/*                                   Code                                    */
/*****************************************************************************/



BOOLEAN pascal InitPrinter (BYTE _ss *Buf, int Handle);
// Stellt das Ausgabeger�t auf "binary" um und pr�ft gleichzeitig, ob das
// Handle 4 ok (offen) ist. Der aktuelle Zustand wird gemerkt und bei Post
// wiederhergestellt. Buf wird als Puffer f�r die Ausgabe verwendet und mu�
// PrintBufSize Bytes gro� sein, Handle ist das Handle auf das ausgegeben
// wird.

void pascal ResetPrinter ();
// Stellt den orginalen Zustand des Ausgabeger�ts wieder her.

void pascal Flush ();
// Schreibt den Ausgabepuffer leer. Mu� am Ende eines Ausdrucks aufgerufen
// werden. Springt PrintAbortLabel an bei Fehlern.

void pascal PrintByte (BYTE B);
// Gibt ein Byte auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.

void PrintData (BYTE far *Data, unsigned Size);
// Gibt Daten auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.

void pascal PrintString (char far *S);
// Gibt einen Pascal-String auf den Drucker (bzw. in den Ausgabepuffer) aus.
// Springt PrintAbortLabel an bei Fehlern.

void pascal PrintZString (char far *S);
// Gibt einen nullterminierten String auf den Drucker (bzw. in den
// Ausgabepuffer) aus. Springt PrintAbortLabel an bei Fehlern.





#endif

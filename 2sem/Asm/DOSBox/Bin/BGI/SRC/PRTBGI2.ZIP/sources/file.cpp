/****************************************************************************/
/*                                                                          */
/*                       Modul f�r Drucker-BGI-Treiber                      */
/*                                                                          */
/* Enth�lt alle File-Funktionen. Wurden neu geschrieben, da die orginalen   */
/* C++-Funktionen zu viel Speicher ben�tigen, bzw. zu viel Hilfsfunktionen  */
/* eingebunden werden.                                                      */
/****************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: file.cpp 2.6 1995/04/28 16:21:41 Uz Exp $
//
// $Log: file.cpp $
// Revision 2.6  1995/04/28 16:21:41  Uz
// Umstellung auf PCX-Treiber.
//
// Revision 2.5  95/04/22  17:34:56  Uz
// Benutzung der Variable errno rausgeschmissen, da der genaue Fehlercode
// sowieso nicht ausgewertet wird.
//
// Revision 2.4  94/03/19  16:18:31  Uz
// Cleanup und Kosmetik.
//
// Revision 2.3  93/08/01  20:52:59  Uz
// Neues Format mit DPMI-Support
//
//
//


#include "const.h"



/****************************************************************************/
/*                                   Code                                   */
/****************************************************************************/



int pascal open (char far *Name, BYTE Mode)
// �ffnet eine Datei. Zur�ckgegeben wird das Handle oder -1 bei Fehlern.
{
    asm push    ds
    asm mov     ds, WORD PTR [Name+2]
    asm mov     dx, WORD PTR [Name]     // Name in ds:dx
    asm mov     ah, 3Dh                 // Open file
    asm mov     al, [Mode]
    asm int     21h
    asm jnc     L1                      // Springe wenn fehlerfrei
    asm mov     ax, -1                  // Ergebnis bei Fehlern
L1: asm pop     ds
    return _AX;
}



long int pascal filelength (int Handle)
// Gibt die L�nge einer Datei bzw. -1 bei Fehlern zur�ck
{
    asm    mov     ax, 4202h                    // end of file + offset
    asm    mov     bx, [Handle]                 // Handle nach bx
    asm    xor     cx, cx
    asm    xor     dx, dx                       // Offset = 0
    asm    int     21h
    asm    jnc     L1                           // Springe wenn fehlerfrei
    asm    mov     ax, -1
    asm    cwd                                  // dx:ax = -1
L1: asm    push    dx                           // L�nge retten
    asm    push    ax
    asm    mov     ax, 4200h                    // start of file + offset
    asm    xor     cx, cx
    asm    xor     dx, dx                       // offset = 0
    asm    int     21h                          // Fehler ignorieren
    asm    pop     ax
    asm    pop     dx                           // L�nge holen und Ende
    return MK_DWORD (_DX, _AX);
}



unsigned pascal read (int Handle, void far *Buffer, unsigned Count)
// Liest aus einer Datei. Liefert 0 zur�ck wenn ok, -1 bei Fehlern.
{
    asm push    ds
    asm mov     ah, 3Fh
    asm mov     bx, [Handle]
    asm mov     cx, [Count]
    asm mov     dx, WORD PTR [Buffer]
    asm mov     ds, WORD PTR [Buffer+2]
    asm int     21h
    asm mov     bx, 0                   // Fehlerfrei annehmen
    asm jc      L1
    asm cmp     ax, [Count]             // Alle Daten gelesen?
    asm jz      L2
L1: asm dec     bx                      // Fehler
L2: asm xchg    ax, bx                  // Ergebnis nach ax
    asm pop     ds
    return _AX;
}



unsigned pascal write (int Handle, void far *Buffer, unsigned Count)
// Schreibt in eine Datei. Liefert 0 zur�ck, wenn ok, -1 bei Fehlern.
{
    asm push    ds
    asm mov     ah, 40h
    asm mov     bx, [Handle]
    asm mov     cx, [Count]
    asm mov     dx, WORD PTR [Buffer]
    asm mov     ds, WORD PTR [Buffer+2]
    asm int     21h
    asm mov     bx, 0                   // Fehlerfrei annehmen
    asm jc      L1
    asm cmp     ax, [Count]             // Alle Daten geschrieben?
    asm jz      L2
L1: asm dec     bx                      // Fehler
L2: asm xchg    ax, bx                  // Ergebnis nach ax
    asm pop     ds
    return _AX;
}



void pascal close (int Handle)
// Schliesst eine Datei
{
    asm    mov     ah, 3Eh
    asm    mov     bx, [Handle]
    asm    int     21h
}


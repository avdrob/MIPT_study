/************************************************************************/
/*                                                                      */
/*    Fixed-Point Sinus/Cosinus-Routinen f�r den Plotter-BGI-Treiber    */
/*                                                                      */
/*               Ullrich von Bassewitz am 21.10.1992                    */
/*                                                                      */
/************************************************************************/


//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: sincos.h 2.4 1994/09/08 14:15:24 Uz Exp $
//
// $Log: sincos.h $
// Revision 2.4  1994/09/08 14:15:24  Uz
// Kleinere �nderungen zur Einsprung von ein paar Bytes.
//
// Revision 2.3  93/08/01  20:53:22  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _SINCOS_H
#define _SINCOS_H


void pascal NormAngle (int _ss& Angle);
// Bringt den �bergebenen Winkel in den Bereich 0..359

int pascal SinMul (int Angle, int Mult);
// Liefert Sin (Angle) * Mult zur�ck.

int pascal CosMul (int Angle, int Mult);
// Liefert Cos (Angle) * Mult zur�ck


#endif

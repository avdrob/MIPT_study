/*****************************************************************************/
/*                                                                           */
/*                                  PCX.CPP                                  */
/*                                                                           */
/* (C) 1995     Ullrich von Bassewitz                                        */
/*              Zwehrenbuehlstrasse 33                                       */
/*              D-72070 Tuebingen                                            */
/* EMail:       uz@ibb.schwaben.de                                           */
/*                                                                           */
/*****************************************************************************/



// $Id: pcx.cpp 1.1 1995/04/28 16:20:43 Uz Exp $
//
// $Log: pcx.cpp $
// Revision 1.1  1995/04/28 16:20:43  Uz
// Initial revision
//
//
//



#include "const.h"
#include "util.h"
#include "str.h"
#include "memory.h"             // Speicherverwaltung
#include "print.h"              // Ausgabe auf Drucker
#include "bgifunc.h"            // Grundlegende BGI-Funktionen
#include "jump.h"               // SetJump/LongJump
#include "alloca.h"



/****************************************************************************/
/*                                  Structs                                 */
/****************************************************************************/

struct PCXHeader {

    BYTE        Manufacturer;
    BYTE        Version;
    BYTE        Encoding;
    BYTE        PixelDepth;
    WORD        WX1;
    WORD        WY1;
    WORD        WX2;
    WORD        WY2;
    WORD        HRes;
    WORD        VRes;
    RGBEntry    ColorMap [16];
    BYTE        Reserved;
    BYTE        PlaneCount;
    WORD        BytesPerLine;
    WORD        PaletteInfo;
    BYTE        Filler [58];
};



static PCXHeader Header = {

    0x0A,                                             // Manufacturer = ZSoft
    5,                                                // Version 3.0
    1,                                                // Encoding = RLE
    8,                                                // 8 Bits per Pixel
    0, 0, 0, 0,                                       // Bildr�nder
    100, 100,                                         // Aufl�sung (DPI)
    0x00, 0x00, 0x00, 0x00, 0x00, 0xAA, 0x00, 0xAA,   // 16-Farb Palette
    0x00, 0x00, 0xAA, 0xAA, 0xAA, 0x00, 0x00, 0xAA,   // (nicht benutzt)
    0x00, 0xAA, 0xAA, 0x55, 0x00, 0xAA, 0xAA, 0xAA,
    0x55, 0x55, 0x55, 0x55, 0x55, 0xFF, 0x55, 0xFF,
    0x55, 0x55, 0xFF, 0xFF, 0xFF, 0x55, 0x55, 0xFF,
    0x55, 0xFF, 0xFF, 0xFF, 0x55, 0xFF, 0xFF, 0xFF,
    0,                                                // Reserved
    1,                                                // PlaneCount
    0,                                                // BytesPerLine
    0                                                 // PaletteInfo: Farbbild
};



/****************************************************************************/
/*                            Ausgabe in PCX-File                           */
/****************************************************************************/



static void _pascal StoreByte (BYTE B, WORD Count)
// Speichert eine Folge von gleichen Bytes im Kompressionspuffer, wobei
// Count die echte Anzahl ist und B das zu wiederholende Byte.
{
    if (Count == 1 && (B & 0xC0) != 0xC0) {
        // Einzelnes Byte, nicht als Folge...
        PrintByte (B);
    } else {
        // Folge oder einzelnes Byte mit falschem Wertebereich
        while (Count) {
            BYTE Bytes = Count > 0x3F ? 0x3F : Count;
            Count -= Bytes;
            PrintByte (Bytes | 0xC0);
            PrintByte (B);
        }
    }
}



void pascal PCXPrint ()
// Ausdruck in das PCX-File
{
    // Ausgabeger�t auf binary umschalten, Puffer zuweisen
    BYTE _ss *OutputBuf = alloca (PrintBufSize);
    if (InitPrinter (OutputBuf, PCXHandle) == FALSE) {
        return;
    }

    // Vor Beginn der Druck-Ausgabe jetzt das Sprunglabel f�r Druckerfehler
    // setzen.
    if (SetJump (PrintAbortLabel) == 0) {

        // Header anpassen und schreiben
        Header.BytesPerLine = MaxX;
        Header.WX2 = MaxX - 1;
//      Header.HRes = MaxX - 1;
        Header.WY2 = MaxY - 1;
//      Header.VRes = MaxY - 1;
        memcpy (Header.ColorMap, RGBPal, sizeof (Header.ColorMap));
        PrintData ((BYTE*) &Header, sizeof (Header));

        // Bilddaten schreiben
        DWORD Abs = 0;
        for (unsigned Y = 0; Y < MaxY; Y++) {

            WORD ByteCount = 0;
            BYTE LastByte;

            for (unsigned X = 0; X < MaxX; X++) {

                // Byte holen
                BYTE B = *Map (Abs++);

                if (ByteCount == 0 || B == LastByte) {
                    // Puffer leer oder selbe Farbe wie zuvor
                    ByteCount++;
                    LastByte = B;
                } else {
                    // Neues Pixel, Puffer leeren
                    StoreByte (LastByte, ByteCount);
                    ByteCount = 1;
                    LastByte = B;
                }

            }

            // Rest ausgeben
            if (ByteCount) {
                StoreByte (LastByte, ByteCount);
            }

        }

        // Palette ausgeben
        PrintByte (0x0C);
        PrintData ((BYTE*) &RGBPal, sizeof (RGBPal));

        // Druckerpuffer leeren
        Flush ();

    }

ExitPoint:
    // Handle wieder in den Orginalzustand versetzen
    ResetPrinter ();
}



/****************************************************************************/
/*                        Holen und Setzen von Pixeln                       */
/****************************************************************************/



void pascal PCXPutPixel (WORD X, WORD Y, BYTE Color, BYTE WriteMode)
// Eigene Funktion PutPixel f�r PCX, die XORMode ber�cksichtigt
{
    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return;
    }

    // Pixel-Adresse berechnen
    BYTE far *BytePtr = Map (LongMul (Y, MaxX) + X);

    // Je nach WriteMode Pixel setzen
    switch (WriteMode) {

        case COPY_PUT:
            *BytePtr = Color;
            break;

        case XOR_PUT:
            *BytePtr ^= Color;
            break;

        case OR_PUT:
            *BytePtr |= Color;
            break;

        case AND_PUT:
            *BytePtr &= Color;
            break;

        case NOT_PUT:
            *BytePtr = ~Color;
            break;

        default:
            break;
    }

    // Puffer als Dirty markieren
    Dirty = TRUE;
}



BYTE pascal PCXGetPixel (WORD X, WORD Y)
// Liefert die Farbe f�r den �bergebenen Punkt zur�ck
{
    // Pr�fen ob der Punkt au�erhalb liegt
    if (Clip (X, Y) == TRUE) {
        // Punkt liegt au�erhalb
        return (0);
    }

    // Punkt adressieren und lesen
    return *Map (LongMul (Y, MaxX) + X);
}



/****************************************************************************/
/*                                                                          */
/*                Allgemeine Typen / Konstanten f�r BGI-Treiber             */
/*                                                                          */
/****************************************************************************/



//
// (C) 1990-1993 Ullrich von Bassewitz
//
// $Id: const.h 2.4 1994/03/29 20:38:53 Uz Exp $
//
// $Log: const.h $
// Revision 2.4  1994/03/29 20:38:53  Uz
// Erweitert um Definition von NULL
//
// Revision 2.3  93/08/01  20:53:32  Uz
// Neues Format mit DPMI-Support
//
//
//


#ifndef _CONST_H
#define _CONST_H


//
// Datentyp BOOLEAN
//
typedef unsigned char BOOLEAN;
#define TRUE     1
#define OK       TRUE
#define FALSE    0

//
// Diverse andere Datentypen mit festen Bit-Gr��en
//
typedef unsigned int  WORD;
typedef unsigned char BYTE;
typedef unsigned long DWORD;


/****************************************************************************/
/*                                                                          */
/*                                Macros                                    */
/*                                                                          */
/****************************************************************************/

// NULL Macro
#ifndef NULL
#define NULL    0
#endif


// Macros aus DOS.H

#define MK_FP( seg,ofs )( (void _seg * )( seg ) +( void near * )( ofs ))
#define FP_SEG( fp )( (unsigned )( void _seg * )( void far * )( fp ))
#define FP_OFF( fp )( (unsigned )( fp ))

// Sonstwas

#define MK_DWORD(high,low) ((DWORD) ((void _seg *) (high) + (void near *) (low)))
#define abs(X) (((X) >= 0) ? (X) : -(X))

/****************************************************************************/
/*                                                                          */
/*        Konstanten, die durch das Grafik-Kernel definiert sind.           */
/*                                                                          */
/****************************************************************************/


// Grafik-Fehlercodes
#define                 grOK                 0
#define                 grNoInitGraph       -1
#define                 grNotDetected       -2
#define                 grFileNotFound      -3
#define                 grInvalidDriver     -4
#define                 grNoLoadMem         -5
#define                 grNoScanMem         -6
#define                 grNoFloodMem        -7
#define                 grFontNotFound      -8
#define                 grNoFontMem         -9
#define                 grInvalidMode      -10
#define                 grError            -11
#define                 grIOError          -12
#define                 grInvalidFont      -13
#define                 grInvalidFontNum   -14
#define                 grInvalidDevNum    -15


// Codes f�r BitBlt
#define COPY_PUT         0x00   /* �berschreibend */
#define XOR_PUT          0x01   /* Exklusives Oder */
#define OR_PUT           0x02   /* Inclusives Oder */
#define AND_PUT          0x03   /* AND mit vorigem Inhalt */
#define NOT_PUT          0x04   /* Inverses Bitmuster schreiben */




//
// Ende von CONST.H
//

#endif
